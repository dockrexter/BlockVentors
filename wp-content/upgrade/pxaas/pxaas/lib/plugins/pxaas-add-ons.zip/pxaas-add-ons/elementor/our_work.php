<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Our_Work extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    
    */
    public function get_name() {
        return 'our_work';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Our Work', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_query',
            [
                'label' => __( 'Work Query', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'ids',
            [
                'label' => __( 'Enter Work IDs', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter Work ids to show, separated by a comma. Leave empty to show all.", 'pxaas-add-ons')
                
            ]
        );
        $this->add_control(
            'ids_not',
            [
                'label' => __( 'Or Work IDs to Exclude', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter Work ids to exclude, separated by a comma (,). Use if the field above is empty.", 'pxaas-add-ons')
                
            ]
        );

        $this->add_control(
            'order_by',
            [
                'label' => __( 'Order by', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'date' => esc_html__('Date', 'pxaas-add-ons'), 
                    'ID' => esc_html__('ID', 'pxaas-add-ons'), 
                    'author' => esc_html__('Author', 'pxaas-add-ons'), 
                    'title' => esc_html__('Title', 'pxaas-add-ons'), 
                    'modified' => esc_html__('Modified', 'pxaas-add-ons'),
                    'rand' => esc_html__('Random', 'pxaas-add-ons'),
                    'comment_count' => esc_html__('Comment Count', 'pxaas-add-ons'),
                    'menu_order' => esc_html__('Menu Order', 'pxaas-add-ons'),
                ],
                'default' => 'date',
                'separator' => 'before',
                'description' => esc_html__("Select how to sort retrieved posts. More at ", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __( 'Sort Order', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => esc_html__('Ascending', 'pxaas-add-ons'), 
                    'DESC' => esc_html__('Descending', 'pxaas-add-ons'), 
                ],
                'default' => 'DESC',
                'separator' => 'before',
                'description' => esc_html__("Select Ascending or Descending order. More at", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __( 'Work to show', 'pxaas-add-ons' ),
                'type' => Controls_Manager::NUMBER,
                'default' => '6',
                'description' => esc_html__("Number of work to show (-1 for all).", 'pxaas-add-ons'),
                'min' => 1,
            ]
        );
        $this->add_control(
            'columns_work',
            [
                'label' => __( 'Columns Work', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    ''            => __( 'Default', 'pxaas-add-ons' ),  
                    'col-md-12 '  => __( 'One Column', 'pxaas-add-ons' ),
                    'col-md-6 '   => __( 'Two Column', 'pxaas-add-ons' ),
                    'col-md-4 '   => __( 'Three Column', 'pxaas-add-ons' ),
                    'col-md-3 '   => __( 'Four Column', 'pxaas-add-ons' ),
                    'col-md-2 '   => __( 'Six Column', 'pxaas-add-ons' ),
                ],
                'default' => 'col-md-4 ',
            ]
        );
        $this->add_control(
            'style',
            [
                'label' => __( 'Style', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    ''    => __( 'Default', 'pxaas-add-ons' ),  
                    '1'   => __( 'Style 1', 'pxaas-add-ons' ),
                    '2'   => __( 'Style 2', 'pxaas-add-ons' ),
                ],
                'default' => '',
            ]
        );

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();

        if(is_front_page()) {
            $paged = (get_query_var('page')) ? get_query_var('page') : 1;
        } else {
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        }
        $args = array( 
            'hide_empty' => true,
            'taxonomy' => 'cth_project_cat',
        ); 
        $terms = get_terms( $args );
        $course_terms = 0;

        $css_classes = array(
            'items-grid-holder',
            'section-team',
        );
        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

        if($settings['style'] !== '') {
            $style = ' work-area-'.$settings['style'];
        }else {
            $style = '';
        }
        ?>
        <div class="filtering<?php echo $style; ?>">
            <div class="filter-item nav-center">
                <ul class="nav-pills cat" role="tablist" id="gallerytab">
                    <li><a class="active waves-effect waves-light waves-ripple background-f4f4f4 mb-10px mr-15px fw-400 radius-25px" href="javascript:void(0)" data-toggle="tab" data-filter="*" ><?php esc_html_e( 'All', 'pxaas-add-ons' ) ?></a></li>
                    <?php foreach ($terms as $term) { ?>
                        <li><a class="waves-effect waves-light waves-ripple background-f4f4f4 mb-10px mr-15px fw-400 radius-25px" href="javascript:void(0)" data-toggle="tab" data-filter="<?php echo '.cth_project_cat-'.$term->slug; ?>"><?php echo $term->name;?></a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <div class="our-galleries<?php echo $style; ?>">
            <div class="our-sizer <?php echo $settings['columns_work']; ?>"></div>
            <?php
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
            $args = array(
                'post_type' => 'cth_project',
                'paged' => $paged,
                'post_per_page' => 6,
                'showposts' => $settings['posts_per_page'],
            );
            $course = new \WP_Query($args);
            if ($course -> have_posts()) :
                while ($course -> have_posts()) : $course -> the_post();
            ?>
            <div <?php post_class($settings['columns_work'].'gallery-item mt-30px '); ?>>
                <div class="work-image">
                   <?php the_post_thumbnail('project-grid'); ?>
                    <div class="overlay-bg transition-5 flex-center">
                        <?php if($settings['style'] !== '2') { ?>
                            <div>
                                <a href="<?php the_post_thumbnail_url(); ?>" class="img-magnifying d-inline-block radius-50 project-popup-image">
                                    <i class="icon-magnifying-glass"></i>
                                </a>
                                <a href="<?php the_permalink(); ?>" class="attachment d-inline-block radius-50">
                                    <i class="icon-attachment"></i>
                                </a>
                                <a href="<?php the_permalink(); ?>"><h5 class="transition-5 mt-10px mb-0px"><?php the_title(); ?></h5></a>
                                <?php
                                $terms = get_the_terms( get_the_ID(), 'cth_project_cat' );
                                if ( $terms && ! is_wp_error( $terms ) ) : 
                                    foreach ( $terms as $term ) { ?>
                                    <p class="cat-prject"><?php echo $term->name; ?></p>
                                    <?php
                                    }
                                    ?>
                                <?php endif; ?>
                            </div>
                        <?php }else { ?>
                            <a href="<?php the_post_thumbnail_url(); ?>" class="img-magnifying d-inline-block radius-50 p-absolute project-popup-image">
                                <i class="fa fa-long-arrow-right"></i>
                            </a>
                            <div class="content p-15px">   
                                <?php
                                    $terms = get_the_terms( get_the_ID(), 'cth_project_cat' );
                                    if ( $terms && ! is_wp_error( $terms ) ) : 
                                        foreach ( $terms as $term ) { ?>
                                        <p class="cat-prject"><?php echo $term->name; ?></p>
                                        <?php
                                        }
                                        ?>
                                <?php endif; ?> 
                                <a href="<?php the_permalink(); ?>"><h5 class="transition-5 mt-10px mb-0px"><?php the_title(); ?></h5></a>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <?php  
                endwhile;
            endif;
            ?>   
        </div>

<?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

}


// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

