<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



/**
 * PXaas_Addons class
 *
 * @since 1.0
 */
if(!class_exists('PXaas_Addons')) {

    class PXaas_Addons {

        private $slug; // settings page slug
        private $page; // settings page slug
        private $options; // global options
        public $plugin_url;
        public $plugin_path;

        protected $menu_slug = 'pxaas-addons';

        protected $option_tabs = array();

        protected $option_options = array();

        protected $current_section = 'default-section-id';

        /** Constructor */
        function __construct() {
            
            // if(!get_option('pxaas_addons_slug')) update_option( 'pxaas_addons_slug', 'settings_page_pxaas-addons' );

            // $slug           = get_option('pxaas_addons_slug');
            // $this->option_name     = $slug;
            // $this->options  = get_option($slug);

            // $active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'general';

            // delete_option( 'settings_page_pxaas-addons' );

            $this->option_name     = $this->menu_slug.'-options';

            // If the theme options don't exist, create them.
            if( false == get_option( $this->option_name ) ) {  
                add_option( $this->option_name );
            }else{
                $this->option_options = get_option( $this->option_name );
            } 

            // end if

        }

        function init() {

            add_action('init', array(&$this, 'plugin_info'));

            //if(is_admin()) {
                add_action( 'admin_menu', array($this, 'register_settings') );
                add_action( 'admin_footer', array($this, 'price_templates') );
            //}

            // manually update option
            // add_action( 'admin_menu', array($this, 'manually_update_options') , 2 );

            // https://core.trac.wordpress.org/browser/tags/4.9/src/wp-includes/option.php#L323
            // $value = apply_filters( 'pre_update_option', $value, $option, $old_value );

            add_filter('pre_update_option', array($this, 'filter_pre_update_option'), 10, 3);

            

            // hide admin bar front-end
            // if(!is_admin()) {
            //     show_admin_bar(false);
            // }
            
            add_action( 'admin_enqueue_scripts', array(&$this, 'enqueue_admin_scripts') );

            add_action( 'wp_enqueue_scripts', array(&$this, 'enqueue_site_scripts') );




            add_filter( 'ajax_query_attachments_args', array($this, 'filter_media_frontend') );


        }

        function price_templates(){
            // socials template
            pxaas_addons_get_template_part('template-parts/tmpls','admin');
        }

        function enqueue_site_scripts(){
            global $wp_query;
            // global $post;

            wp_enqueue_style( 'select2' , $this->plugin_url ."assets/css/select2.min.css", false ); 
            // wp_enqueue_style( 'pxaas-icon' , $this->plugin_url ."assets/fonts/pxaas_icon/style.css", false ); 
            wp_enqueue_style( 'pxaas-icons' , $this->plugin_url ."assets/css/icon-fonts.css", false ); 
            wp_enqueue_style( 'venobox' , $this->plugin_url ."assets/css/venobox.css", false ); 
            wp_enqueue_style( 'pxaas-addons' , $this->plugin_url ."assets/css/pxaas-add-ons.css", false ); 

            
            // wp_enqueue_script( 'backbone.marionette', $this->plugin_url ."assets/js/backbone.marionette.min.js" , array('jquery','backbone','underscore'), null , true );
            wp_enqueue_script( 'jquery.selectbox', $this->plugin_url ."assets/js/jquery.selectbox.min.js" , array(), null , true );
            wp_enqueue_script( 'select2', $this->plugin_url ."assets/js/select2.min.js" , array('jquery'), null , true );
            wp_enqueue_script( 'venobox', $this->plugin_url ."assets/js/venobox.min.js" , array(), null , true );

            // if(pxaas_addons_get_option('use_osm_map') == 'yes'){
            //     wp_enqueue_style( 'openlayers' , $this->plugin_url ."assets/css/ol.css", false ); 
            //     wp_enqueue_script( 'openlayers', $this->plugin_url ."assets/js/ol.js" , array(), null , true );
            // }else{
            //     $gmap_api_key = pxaas_addons_get_option('gmap_api_key');
            //     wp_enqueue_script("googleapis", "https://maps.googleapis.com/maps/api/js?key=$gmap_api_key",array(),false,true);
            // }

                
            
                
            wp_enqueue_media();

            wp_enqueue_script( 'pxaas-addons', $this->plugin_url ."assets/js/pxaas-add-ons.min.js" , array('underscore','imagesloaded','jquery-masonry'), null , true );

            // AIzaSyChCXNJOoVajjJ1KvF3g0kq63yb5KQLPMA

            $gmap_marker = pxaas_addons_get_option('gmap_marker');

            // wp_enqueue_script( 'pxaas-app', $this->plugin_url ."assets/js/pxaas-app.js" , array('backbone.marionette','jquery.selectbox','pxaas-gmap'), null , true );

            $_pxaas_add_ons = array(
                'url'           => esc_url(admin_url( 'admin-ajax.php' ) ),
                'nonce'         => wp_create_nonce( 'pxaas-add-ons' ),
                'posted_on'     => __('Posted on ','pxaas-add-ons'),
                'reply'         => __('Reply','pxaas-add-ons'),
                'retweet'       => __('Retweet','pxaas-add-ons'),
                'favorite'      => __('Favorite','pxaas-add-ons'),
                'pl_w'          => __('Please wait...','pxaas-add-ons'),
                'like'          => esc_html__( 'Like', 'pxaas-add-ons' ),
                'unlike'        => esc_html__( 'Unlike', 'pxaas-add-ons' ),

                // for ajax search
                'is_search'     => is_search(),
                'is_tax_cat'    => is_tax('listing_cat'),
                'is_tax_loc'    => is_tax('listing_location'),
                'is_tax_fea'    => is_tax('listing_feature'),
                'query_vars'    =>  $wp_query->query_vars ,

                'marker'        => $gmap_marker['url']? $gmap_marker['url'] : $this->plugin_url ."assets/images/map-marker.png",
                'center_lat'    => floatval(pxaas_addons_get_option('gmap_default_lat')),
                'center_lng'    => floatval(pxaas_addons_get_option('gmap_default_long')),
                'map_zoom'      => pxaas_addons_get_option('gmap_default_zoom'),
                'free_map'      => pxaas_addons_get_option('use_osm_map'),

            );
            // if(is_singular('listing')){
            //     $_pxaas_add_ons['slid'] = 
            // }
            wp_localize_script( 'pxaas-addons', '_pxaas_add_ons', $_pxaas_add_ons );


            // for listing submit
            // wp_localize_script( 'pxaas-addons', 'POST_SUBMITTER', array(
            //         'root' => esc_url_raw( rest_url() ),
            //         'nonce' => wp_create_nonce( 'wp_rest' ),
            //         'success' => __( 'Thanks for your submission!', 'pxaas-add-ons' ),
            //         'failure' => __( 'Your submission could not be processed.', 'pxaas-add-ons' ),
            //         'current_user_id' => get_current_user_id()
            //     )
            // );

            // $listing_cats = get_terms( array(
            //     'taxonomy' => 'listing_cat',
            //     'hide_empty' => false
            // ) );

            // $listing_cats_arr = array();
            // $this->parse_listing_cats($listing_cats,$listing_cats_arr,0,-1,3);


            // wp_localize_script( 'pxaas-app', '_pxaas_submit', array(
            //         'ajaxurl' => esc_url(admin_url( 'admin-ajax.php' ) ),
            //         'nonce' => wp_create_nonce( 'pxaas-add-ons' ),
            //         'cats'=>$listing_cats_arr,
            //         // 'success' => __( 'Thanks for your submission!', 'pxaas-add-ons' ),
            //         // 'failure' => __( 'Your submission could not be processed.', 'pxaas-add-ons' ),
            //         'current_user_id' => get_current_user_id()
            //     )
            // );
        }

        function enqueue_admin_scripts($hook) {
            // Load only on ?page=mypluginname
            // var_dump($hook);
            wp_enqueue_style( 'pxaas-addons', PXAAS_ADD_ONS_DIR_URL .'assets/css/admin.css' );
            wp_enqueue_script('pxaas-addons-admin', PXAAS_ADD_ONS_DIR_URL . 'assets/js/addons-admin.min.js', array('jquery'), null, true);
            if($hook != 'settings_page_pxaas-addons') {
                return;
            }
            wp_enqueue_media();
            wp_enqueue_script('pxaas_addons_image', PXAAS_ADD_ONS_DIR_URL . 'inc/assets/upload_file.js', array('jquery'), null, true);
            // wp_enqueue_style( 'custom_wp_admin_css', plugins_url('admin-style.css', __FILE__) );
        }


        function filter_media_frontend( $query ) {
            // admins get to see everything
            if ( ! current_user_can( 'manage_options' ) ) $query['author'] = get_current_user_id();
            return $query;
        }


        function parse_listing_cats($cats = array(),&$return =array(),$parent_id = 0,$curlevel = -1,$maxlevel = 3){
            $return = $return? $return : array();
            if ( !empty($cats) ) :
                foreach( $cats as $cat ) {
                    if( $cat->parent == $parent_id ) {
                        // $return[$cat->term_id] = array('name'=>$cat->name,'level'=>$curlevel+1,'children'=>array());
                        $return[] = array('id'=>$cat->term_id,'name'=>$cat->name,'level'=>$curlevel+1);
                        // if($return[$cat->term_id]['level'] < $maxlevel ) $this->parse_listing_cats($cats,$return[$cat->term_id]['children'],$cat->term_id,$return[$cat->term_id]['level']);
                        if($curlevel+1 < $maxlevel ) $this->parse_listing_cats($cats,$return,$cat->term_id,$curlevel+1);

                        
                    }
                }
            endif;
            // return $return;
        }

        


        function get_setting_tab_options($tab = 'general'){
            if(isset($this->option_options[$tab])) 
                return $this->option_options[$tab];
            elseif($tab == '') 
                return $this->option_options;
            else 
                return array();
        }


        function register_setting_field($field = array(), $tab = ''){
            $default = array(
                'type' => 'section', // section or field
                'field_type' => 'text', // field type for register field only
                'id' => 'default-section-id', // section or field id
                'title' => __( 'Default title', 'pxaas-add-ons' ), // section or field title
                // 'callback' => '__return_false', // section or field callback for echo its output
                // 'section_id' => 'default-section-id', // for setting field only // use current_section instead
                // 'args' => array(
                //     'id' => 'default-section-id', // id of the field
                //     'desc' => __( 'Default description', 'pxaas-add-ons' ), // id of the field
                // ), // for setting field only

                'desc' => '', // desc of the field

                'args' => array(
                    // 'options' => array(key=>value) for radio
                )
            );

            $field = array_merge($default, $field);

            if($field['type'] == 'section'){
                if(!isset($field['callback'])) $field['callback'] = '__return_false';
                // $page_tab = $this->menu_slug.'_widgets-options';
                // $id, $title, $callback, $page
                // $page - The menu page on which to display this section. Should match $menu_slug from Function Reference/add theme page if you are adding a section to an 'Appearance' page, or Function Reference/add options page if you are adding a section to a 'Settings' page.
                add_settings_section( $field['id'], $field['title'], $field['callback'], $this->slug ."-$tab" );

                $this->current_section = $field['id'] ;
            }
            if($field['type'] == 'field'){
                if(!isset($field['callback'])){
                    switch ($field['field_type']) {
                        case 'text':
                            $field['callback'] = array($this, 'settings_field_input');
                            break;
                        case 'number':
                            $field['callback'] = array($this, 'settings_field_number');
                            break;
                        case 'textarea':
                            $field['callback'] = array($this, 'settings_field_textarea');
                            break;
                        case 'editor':
                            $field['callback'] = array($this, 'settings_field_editor');
                            break;
                        case 'checkbox':
                            $field['callback'] = array($this, 'settings_field_checkbox');
                            break;
                        case 'radio':
                            $field['callback'] = array($this, 'settings_field_radio');
                            break;
                        case 'select':
                            $field['callback'] = array($this, 'settings_field_select');
                            break;
                        case 'info':
                            $field['callback'] = array($this, 'settings_field_info');
                            break;
                        case 'page_select':
                            $field['callback'] = array($this, 'settings_field_page_select');
                            break;
                        case 'image':
                            $field['callback'] = array($this, 'settings_field_image');
                            break;
                        case 'repeat_content':
                            $field['callback'] = array($this, 'settings_field_repeat_content');
                            break;
                        case 'repeat_widget':
                            $field['callback'] = array($this, 'settings_field_repeat_widget');
                            break;
                        case 'color':
                            $field['callback'] = array($this, 'settings_field_color');
                            break;
                        default:
                            $field['callback'] = array($this, 'settings_field_input');
                            break;
                    }
                }
                // $id, $title, $callback, $page, $section, $args
                add_settings_field(
                    $field['id'], 
                    $field['title'], 
                    $field['callback'], 
                    $this->slug ."-$tab", 
                    $this->current_section, 
                    array_merge(array(
                        'id'    => $field['id'], 
                        'desc'  => $field['desc']
                    ), $field['args'])
                );
            }
        }

        function register_settings() {
            // add_options_page( $page_title, $menu_title, $capability, $menu_slug, $function);
            $this->slug = add_options_page( 'PXaas Add-ons', 'PXaas Add-ons', 'manage_options', $this->menu_slug, array($this, 'view_admin_settings') );

            $this->options  = get_option($this->option_name, array());

            // https://developer.wordpress.org/reference/functions/register_setting/
            // string $option_group, string $option_name, array $args = array()
            register_setting($this->option_name, $this->option_name, array($this, 'sanitize_settings') );

            // if($options){
            //     foreach ($options as $field) {
            //         $this->register_setting_field($field);
            //     }
            // }

            $tabs_options = $this->get_setting_tab_options('');
            if(!empty($tabs_options)){
                foreach ($tabs_options as $tab => $options) {
                    if(!empty($options)){
                        foreach ($options as $field) {
                            $this->register_setting_field($field, $tab);
                        }
                    }
                }
            }

        }


        function filter_pre_update_option($value, $option, $old_value){
            
            if($option == $this->option_name){
                if(!is_array($value)) $value = array();
                if(!is_array($old_value)) $old_value = array();
                return array_merge($old_value, $value);
            }
            return $value;
        }

        function settings_field_info($args) {
            $desc = $args['desc'];
            echo "<p class='description desc-info'>$desc</div>";

        }

        function settings_field_input($args) {
            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';
            $value = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            echo "<input id='$id' name='{$this->option_name}[{$id}]' size='40' type='text' value='{$value}' />";
            echo "<p class='description'>$desc</div>";

        }

        function settings_field_number($args) {
            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';
            $value = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            $attrs = '';
            if(isset($args['min'])) $attrs .= ' min="'.$args['min'].'"';
            if(isset($args['max'])) $attrs .= ' max="'.$args['max'].'"';
            if(isset($args['step'])) $attrs .= ' step="'.$args['step'].'"';

            echo "<input id='$id' name='{$this->option_name}[{$id}]' size='40' type='number' value='{$value}'".$attrs."/>";
            echo "<p class='description'>$desc</div>";

        }

        function settings_field_textarea($args) {

            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';
            // $options = $this->options;

            // $default = "#login {width: 500px} .success {background-color: #F0FFF8; border: 1px solid #CEEFE1;}";

            // if(!isset($options['custom_style'])) $options['custom_style'] = $default;
            // $text = $options['custom_style'];

            $value = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            echo "<textarea id='{$id}' name='{$this->option_name}[{$id}]' rows='7' cols='50' class='large-text code'>{$value}</textarea>";
            echo "<p class='description'>$desc</div>";

        }

        function settings_field_editor($args) {

            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';

            $value = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            /**
             * 2.
             * This code renders an editor box and a submit button.
             * The box will have 15 rows, the quicktags won't load
             * and the PressThis configuration is used.
             */
            $editor_args = array(
                'textarea_rows' => isset($args['rows'])? $args['rows'] : 10,
                'textarea_name'=> $this->option_name .'['. $id .']',
                'teeny' => true,
                'quicktags' => true
            );
            wp_editor( $value, $this->option_name .'_'. $id .'_', $editor_args );
            echo "<p class='description'>$desc</div>";

        }

        function settings_field_checkbox($args) {

            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : (isset($args['default']) ? $args['default'] : '');
            $value = isset($args['value'])? $args['value'] : 1;

            $checked = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            echo '<label for="'. $id .'">';
                echo '<input type="hidden" name="'. $this->option_name .'['. $id .']" value="">';
                echo '<input type="checkbox" id="'.$id.'" name="'. $this->option_name .'['. $id .']" value="'.$value.'" '. checked( $checked, $value, false ) .'/>';
            echo '&nbsp;' . $desc .'</label>';

        }

        function settings_field_image($args) {

            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';

            $value = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            // echo '<label for="'. $id .'">';
            //     echo '<input type="checkbox" id="'.$id.'" name="'. $this->option_name .'['. $id .']" value="1" '. checked( $value, 1, false ) .'/>';
            // echo '&nbsp;' . $desc .'</label>';


            echo '<img id="'. $this->option_name .'['. $id .'][preview]" src="'.(isset($value['url']) ? esc_attr($value['url']) : '').'" alt="" '.(isset($value['url']) ? ' style="display:block;width:200px;height=auto;"' : ' style="display:none;width:200px;height=auto;"').'>';
            echo '<input type="hidden" name="'. $this->option_name .'['. $id .'][url]" id="'. $this->option_name .'['. $id .'][url]" value="'.(isset($value['url']) ? esc_attr($value['url']) : '').'">';
            echo '<input type="hidden" name="'. $this->option_name .'['. $id .'][id]" id="'. $this->option_name .'['. $id .'][id]" value="'.(isset($value['id']) ? esc_attr($value['id']) : '').'">';
            
            echo '<p class="description"><a href="#" data-uploader_title="'.esc_html__( 'Select Image', 'pxaas-add-ons' ).'" class="button button-primary upload_image_button metakey-'.$this->option_name.' fieldkey-'.$id.'">'.esc_html__('Upload Image', 'pxaas-add-ons').'</a>  <a href="#" class="button button-secondary remove_image_button metakey-'.$this->option_name.' fieldkey-'.$id.'">'.esc_html__('Remove', 'pxaas-add-ons').'</a></p>';


            echo "<p class='description'>$desc</div>";

        }

        function settings_field_radio($args) {

            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';

            $value = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            if (isset($args['options']) && !empty($args['options'])) {
                foreach ($args['options'] as $option_value => $option_text) {
                    // $checked = ' ';
                    // if (get_option($value['id']) == $option_value) {
                    //     $checked = ' checked="checked" ';
                    // }
                    // else if (get_option($value['id']) === FALSE && $value['std'] == $option_value){
                    //     $checked = ' checked="checked" ';
                    // }
                    // else {
                    //     $checked = ' ';
                    // }
                    echo '<div class="mnt-radio" style="display:inline-block;padding:0 10px 0 0;"><input type="radio" name="'. $this->option_name .'['. $id .']" value="'.
                        $option_value.'" '.checked( $option_value, $value, false )."/>".$option_text."</div>\n";

                    if(isset($args['options_block']) && $args['options_block']) echo '<br>';
                }
            }


            echo "<p class='description'>$desc</div>";


        }

        function settings_field_select($args) {

            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';

            $value = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            $field_class = 'select_field' . (isset($args['multiple']) && $args['multiple'] == true ? ' multiple_field':'') . (isset($args['use-select2']) && $args['use-select2'] == true ? ' use-select2':'');

            if(isset($args['multiple']) && $args['multiple'] == true){
                echo '<input type="hidden" name="'.$this->option_name .'['. $id .'][]'.'">'."\n";
                echo '<select id="'. $this->option_name .'['. $id .']" class="'.$field_class.'" name="'. $this->option_name .'['. $id ."][]\" multiple=\"multiple\">\n";
                    if (isset($args['options']) && !empty($args['options'])) {
                        foreach ($args['options'] as $option_value => $option_text) {
                            echo "\t".'<option value="'.$option_value.'" '. (in_array($option_value, (array)$value)? ' selected="selected"':'').'>'.$option_text."</option>\n";
                        }
                    }
                echo "</select>\n";
            }else{
                echo '<select id="'. $this->option_name .'['. $id .']" class="'.$field_class.'" name="'. $this->option_name .'['. $id ."]\">\n";
                    if (isset($args['options']) && !empty($args['options'])) {
                        foreach ($args['options'] as $option_value => $option_text) {
                            echo "\t".'<option value="'.$option_value.'" '.selected( $value, $option_value, false ).'>'.$option_text."</option>\n";
                        }
                    }
                echo "</select>\n";
            }

            echo "<p class='description'>$desc</div>";


        }

        function settings_field_page_select($args) {

            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';

            $value = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            $options = isset($args['options']) ? $args['options'] : array();

            $all_page_ids = get_all_page_ids();
            if(!empty($all_page_ids)){
            echo '<select id="'. $this->option_name .'['. $id .']" class="post_form" name="'. $this->option_name .'['. $id .']">\n';
                $is_selected = false;
                if(!empty($options)){
                    foreach ($options as $opt) {
                        if( isset($opt[0]) && isset($opt[1]) ){
                            echo '<option value="'.$opt[0].'" '.selected( $value, $opt[0], false ).'>'.$opt[1]."</option>\n";
                            if($value == $opt[0]) $is_selected = true;
                        } 
                    }
                }
                foreach ($all_page_ids as $key => $p_id) {
                    $p_p = get_post($p_id);
                    if($p_p->post_status == 'publish'){
                        $selected = ' ';
                        if($is_selected != true){
                            if( $value == $p_id ){
                                $selected = ' selected="selected" ';
                                $is_selected = true;
                            }
                            elseif( isset($args['default_title']) && $args['default_title'] == $p_p->post_title ){
                                $selected = ' selected="selected" ';
                                $is_selected = true;
                            }
                        }
                            
                
                        echo '<option value="'.$p_id.'" '.$selected.'>'.$p_p->post_title."</option>\n";
                    }
                    
                }
            echo "</select>\n";
            } 

            echo "<p class='description'>$desc</div>";


        }
        function settings_field_repeat_content($args) {

            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';

            $fields = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');
            
            $option_field_name = $this->option_name .'['. $id .']';

            echo '<input type="hidden" name="'.$option_field_name .'">'."\n";

            ?>
            <div class="addons-form">
                <div class="repeater-fields-wrap"  data-tmpl="tmpl-content-addfield">
                    <div class="repeater-fields">
                    <?php 
                    if(!empty($fields)){
                        foreach ((array)$fields as $key => $field) {
                            pxaas_addons_get_template_part('templates-inner/add-field',false, array( 'index'=>$key,'name'=>$option_field_name,'field'=>$field ) );
                        }
                    }
                    ?>
                    </div>
                    <button class="btn addfield" type="button"><?php  esc_html_e( 'Add Field','pxaas-add-ons' );?></button>
                </div>
            </div>

            <?php

            echo "<p class='description'>$desc</div>";

            add_action( 'admin_footer', function()use($option_field_name){
                ?>
                <script type="text/template" id="tmpl-content-addfield">
                    <?php pxaas_addons_get_template_part('templates-inner/add-field',false, array( 'name'=>$option_field_name ) );?>
                </script>
                <?php
            });
        }

        function settings_field_repeat_widget($args) {

            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';

            $widgets = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');
            // echo '<pre>';var_dump($widgets);
            $option_field_name = $this->option_name .'['. $id .']';
            echo '<input type="hidden" name="'.$option_field_name .'">'."\n";

            ?>
            <div class="addons-form">
                <div class="repeater-widgets-wrap"  data-tmpl="tmpl-content-addwidget">
                    <div class="repeater-widgets">
                    <?php 
                    if(!empty($widgets)){
                        foreach ((array)$widgets as $key => $widget) {
                            pxaas_addons_get_template_part('templates-inner/add-widget',false, array( 'index'=>$key,'name'=>$option_field_name,'widget'=>$widget ) );
                        }
                    }
                    ?>
                    </div>
                    <button class="btn addwidget" data-name="<?php echo esc_attr( $option_field_name ); ?>" type="button"><?php  esc_html_e( 'Add Widget','pxaas-add-ons' );?></button>
                </div>
            </div>
            <?php
            echo "<p class='description'>$desc</div>";
        }

        function settings_field_color($args) {
            if(!isset($args['id'])) return;
            $id = $args['id'];
            $desc = isset($args['desc'])? $args['desc'] : '';
            $value = isset($this->options[$id]) ? $this->options[$id] : (isset($args['default']) ? $args['default'] : '');

            echo "<input id='$id' class='cth-color-field' name='{$this->option_name}[{$id}]' size='40' type='text' value='{$value}' />";
            echo "<p class='description'>$desc</div>";

        }



        

        /** 
         * Sanitize options
         *
         * @todo    Check if author/key is valid
         * @since   1.0
         */
        function sanitize_settings($args) {

            return $args;
        }

        /**
         * Main Settings panel
         *
         * @since   1.0
         */
        function view_admin_settings() {
            ?>
            <div class="wrap">
    
                <div id="icon-options-general" class="icon32"></div>
                <h2><?php _e( 'PXaas Add-Ons Settings', 'pxaas-add-ons' ); ?></h2>
            
                <?php //settings_errors(); ?>
                <?php
                $active_tab = isset( $_GET[ 'addonstab' ] ) ? $_GET[ 'addonstab' ] : 'general';
                ?>
                <h2 class="nav-tab-wrapper">
                    <?php
                    foreach ($this->option_tabs as $id => $title) {
                        ?>
                        <a href="#cth-addons-tab-<?php echo $id; ?>" data-tabid="<?php echo $id; ?>" class="nav-tab cth-addons-tab <?php echo $active_tab == $id ? ' nav-tab-active' : ''; ?>"><?php echo $title;?></a>
                        <?php
                    }
                    ?>
                </h2>


                <form action="options.php" method="post" id="ctb-addons-options-form">
                <?php
                // $slug = $this->option_name;
                // A settings group name. This should match the group name used in register_setting().
                settings_fields($this->option_name); // Output nonce, action, and option_page fields for a settings page
                // $page - The slug name of the page whose settings sections you want to output. This should match the page name used in add_settings_section().
                // do_settings_sections($this->slug);
                echo "<div class=\"cth-addons-tab-content\">";
                $tabs_options = $this->get_setting_tab_options('');
                if(!empty($tabs_options)){
                    foreach ($tabs_options as $tab => $options) {
                        echo "<div id=\"cth-addons-tab-$tab\" class=\"cth-addons-pane cth-addons-tab-$tab".($active_tab == $tab ? ' current' : '')."\">";
                        do_settings_sections($this->slug. "-$tab");
                        echo "</div>";
                    }
                }
                echo "</div>";

                submit_button();
                ?>
                </form>

            </div>
            <?php
        }
        
        
        function plugin_info() {
            $this->plugin_url = plugin_dir_url(__FILE__);
            $this->plugin_path = plugin_dir_path(__FILE__);

            $this->option_tabs = array( 
                'general'=> esc_html__( 'General', 'pxaas-add-ons' ),
                // 'single'=> esc_html__( 'Single', 'pxaas-add-ons' ),
                // 'listings'=> esc_html__( 'Listings', 'pxaas-add-ons' ),
                'gmap'=> esc_html__( 'Map', 'pxaas-add-ons' ),
                // 'emails'=> esc_html__( 'Emails', 'pxaas-add-ons' ),
                // 'booking'=> esc_html__( 'Booking', 'pxaas-add-ons' ),
                'widgets'=> esc_html__( 'Widgets', 'pxaas-add-ons' ),
                // 'maintenance'=> esc_html__( 'Maintenance', 'pxaas-add-ons' ),
            );
            $this->option_options = pxaas_addons_get_plugin_options();
        }

    }

}

// plugin option values
require_once PXAAS_ADD_ONS_DIR . 'includes/option_values.php';

$pxaas_addons = new PXaas_Addons;
$pxaas_addons->init();

if(!isset($pxaas_addons_options)) $pxaas_addons_options = get_option( 'pxaas-addons-options', array() );

function pxaas_addons_get_option( $setting, $default = null ) {
    global $pxaas_addons_options;

    $default_options = array(

        'maintenance_mode'                      => 'disable',
        'listings_count'                        => '6',

        'resmenu_filter_all'                    => false,
        'resmenu_filter_orderby'                => 'name',
        'resmenu_filter_order'                  => 'ASC',

        'login_redirect_page'                   => '',

        'project_count'                         => 6,
        'project_orderby'                       => 'date',
        'project_order'                         => 'DESC',

        'custom_logreg_enable'                  => 'no',

        'currency'                              => 'USD',
        'currency_symbol'                              => '$',
        'currency_pos'                              => 'left',
        'thousand_sep'                          => ',',
        'decimal_sep'                          => '.',
        'decimals'                              => 0,


    );
    $value = false;
    if ( isset( $pxaas_addons_options[ $setting ] ) ) {
        $value = $pxaas_addons_options[ $setting ];
    }else {
        if(isset($default)){
            $value = $default;
        }else if( isset( $default_options[ $setting ] ) ){
            $value = $default_options[ $setting ];
        }
    }
    return $value;
}



