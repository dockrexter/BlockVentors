<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Membership_Plans extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name. 
    */
    public function get_name() { 
        return 'membership_plans';
    }

    // public function get_id() {
    //      return 'header-search';
    // }

    public function get_title() {
        return __( 'Membership Plans', 'pxaas-add-ons' ); 
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'eicon-gallery-justified';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_query',
            [
                'label' => __( 'Plans Query', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'ids',
            [
                'label' => __( 'Enter Plan IDs', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter Plan ids to show, separated by a comma. Leave empty to show all.", 'pxaas-add-ons')
                
            ]
        );
        $this->add_control(
            'ids_not',
            [
                'label' => __( 'Or Plan IDs to Exclude', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter plan ids to exclude, separated by a comma (,). Use if the field above is empty.", 'pxaas-add-ons')
                
            ]
        );

        $this->add_control(
            'order_by',
            [
                'label' => __( 'Order by', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'date' => esc_html__('Date', 'pxaas-add-ons'), 
                    'ID' => esc_html__('ID', 'pxaas-add-ons'), 
                    'author' => esc_html__('Author', 'pxaas-add-ons'), 
                    'title' => esc_html__('Title', 'pxaas-add-ons'), 
                    'modified' => esc_html__('Modified', 'pxaas-add-ons'),
                    'rand' => esc_html__('Random', 'pxaas-add-ons'),
                    'comment_count' => esc_html__('Comment Count', 'pxaas-add-ons'),
                    'menu_order' => esc_html__('Menu Order', 'pxaas-add-ons'),
                    'post__in' => esc_html__('ID order given (post__in)', 'pxaas-add-ons'),
                ],
                'default' => 'date',
                'separator' => 'before',
                'description' => esc_html__("Select how to sort retrieved posts. More at ", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __( 'Sort Order', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => esc_html__('Ascending', 'pxaas-add-ons'), 
                    'DESC' => esc_html__('Descending', 'pxaas-add-ons'), 
                ],
                'default' => 'ASC',
                'separator' => 'before',
                'description' => esc_html__("Select Ascending or Descending order. More at", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __( 'Plans to show', 'pxaas-add-ons' ),
                'type' => Controls_Manager::NUMBER,
                'default' => '3',
                'description' => esc_html__("Number of plans to show (-1 for all).", 'pxaas-add-ons'),
                
            ]
        );
        $this->end_controls_section();


        $this->start_controls_section(
            'section_layout',
            [
                'label' => __( 'Plans Layout', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'columns_grid',
            [
                'label' => __( 'Columns Grid', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'col-md-12' => esc_html__('One Column', 'pxaas-add-ons'), 
                    'col-md-6'  => esc_html__('Two Columns', 'pxaas-add-ons'), 
                    'col-md-4'  => esc_html__('Three Columns', 'pxaas-add-ons'), 
                    'col-md-3'  => esc_html__('Four Columns', 'pxaas-add-ons'), 
                    'col-md-2'  => esc_html__('Six Columns', 'pxaas-add-ons'),   
                ],
                'default' => 'col-md-4',
            ]
        );
        $this->add_control(
            'best_price_icon',
            [
                'label' => __( 'Best Price Icon', 'pxaas-add-ons' ),
                'type' => Controls_Manager::ICON,
                'default' => 'fa fa-check',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'show_pricing_switcher',
            [
                'label' => __( 'Show Button Switcher Pricing', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'view_pricing_style',
            [
                'label'   => __( 'See the pricing plan decoration style', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    ''    => __( 'Style 1', 'pxaas-add-ons' ),
                    '2'   => __( 'Style 2', 'pxaas-add-ons' ),
                    '2-1' => __( 'Style 2(1)', 'pxaas-add-ons' ),
                    '3'   => __( 'Style 3', 'pxaas-add-ons' ),
                ],
            ]
        );


        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();

        
        if(!empty($settings['ids'])){
            $ids = explode(",", $settings['ids']);
            $post_args = array(
                'post_type' => 'lplan',
                'posts_per_page'=> $settings['posts_per_page'],
                'post__in' => $ids,
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],
                'post_status' => 'publish'
            );
        }elseif(!empty($settings['ids_not'])){
            $ids_not = explode(",", $settings['ids_not']);
            $post_args = array(
                'post_type' => 'lplan',
                'posts_per_page'=> $settings['posts_per_page'],
                'post__not_in' => $ids_not,
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],
                'post_status' => 'publish'
            );
        }else{
            $post_args = array(
                'post_type' => 'lplan',
                'posts_per_page'=> $settings['posts_per_page'],
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],
                'post_status' => 'publish'
            );
        }


        $css_classes = array(
            'membership-plans-wrap',
            $settings['columns_grid'].'-cols',
            'text-center',
        );
        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

        $tab_css = '';
        if($settings['view_pricing_style'] !== '') {
            $css_class.= ' membership-plans-'.$settings['view_pricing_style'];
            $tab_css.= 'tabs-plan-'.$settings['view_pricing_style'].' ';
        }else {
            $css_class.= ' membership-plans';
        }
        
        ?>
        <?php 
            if($settings['show_pricing_switcher'] == 'yes'):?>
                <ul class="<?php echo $tab_css; ?>tabs-plan list-unstyled text-center">
                    <li id="tab1" class="pl-25px pr-25px pt-10px pb-10px bg-fff color-blue mb-10px d-inline-block active"><?php esc_html_e( 'Monthly', 'pxaas-add-ons' ) ?></li>
                    <li id="tab2" class="pl-25px pr-25px pt-10px pb-10px bg-fff color-blue mb-10px d-inline-block"><?php esc_html_e( 'Yearly', 'pxaas-add-ons' ) ?></li>
                </ul>
            <?php endif; ?>

        <div id="tab1-content" class="<?php echo esc_attr($css_class );?>">
            <div class="row">
            <?php 
                // $checkout_page_id = pxaas_addons_get_option('checkout_page');

                $posts_query = new \WP_Query($post_args);
                if($posts_query->have_posts()) : ?>
                    <?php 
                    while($posts_query->have_posts()) : $posts_query->the_post(); ?>
                    <?php $icon = get_post_meta( get_the_ID(), P_META_PREFIX.'price_icon', true ); ?>
                        <!-- plan-item -->
                        <div class="<?php echo $settings['columns_grid']; ?>">
                            <div class="p-relative bg-fff mt-25px mb-25px price-item radius-5px transition-3">
                                <div class="price-head color-bg">
                                    <i class="price-icon <?php echo $icon; ?> fs-100 p-absolute"></i>
                                    <h3 class="fw-500"><?php the_title(); ?></h3>
                                    <h1 class="price-title p-relative fw-500 mt-40px mb-40px">
                                        <span class="price-title-lines p-absolute d-block"></span>
                                        <span class="list-price fw-600 color-blue fs-55">
                                            <?php echo pxaas_addons_get_price_formated( get_post_meta( get_the_ID(), P_META_PREFIX.'price', true ), false ); ?>
                                            <span class="fs-25 curen"><?php echo pxaas_addons_get_option('currency_symbol','$'); ?></span> 
                                        </span>
                                        <span class="fs-20 mouth-cont"><?php echo pxaas_add_ons_get_plan_period_text( get_post_meta( get_the_ID(), P_META_PREFIX.'interval', true ), get_post_meta( get_the_ID(), P_META_PREFIX.'period', true ) ); ?><?php // echo get_post_meta( get_the_ID(), P_META_PREFIX.'period', true ); ?></span>
                                        
                                    </h1>
                                </div>
                                <div class="price-content fl-wrap">
                                    <div class="price-desc fl-wrap">
                                        <?php the_content(); ?>
                                            
                                        <?php 
                                        $purchase_url = get_post_meta( get_the_ID(), P_META_PREFIX.'purchase_url', true );
                                        if( $purchase_url != '' ) : ?>
                                            <a href="<?php echo esc_url( $purchase_url ); ?>" class="price-link main-btn btn-3 mt-20px"><?php echo sprintf(__( 'Order %s', 'pxaas-add-ons' ), get_the_title()); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- plan-item end  -->
                    <?php 
                    endwhile; ?>
                <?php endif; ?> 
            </div>
        </div>

        <div id="tab2-content" class="<?php echo esc_attr($css_class );?>">
            <div class="row">
            <?php 
                // $checkout_page_id = pxaas_addons_get_option('checkout_page');

                $posts_query = new \WP_Query($post_args);
                if($posts_query->have_posts()) : ?>
                    <?php 
                    while($posts_query->have_posts()) : $posts_query->the_post(); ?>
                    <?php $icon = get_post_meta( get_the_ID(), P_META_PREFIX.'price_icon', true ); ?>
                        <!-- plan-item -->
                        <div class="<?php echo $settings['columns_grid']; ?>">
                            <div class="p-relative bg-fff mt-25px mb-25px price-item radius-5px transition-3">
                                <div class="price-head color-bg">
                                    <i class="price-icon <?php echo $icon; ?> fs-100 p-absolute"></i>
                                    <h3 class="fw-500"><?php the_title(); ?></h3>
                                    <h1 class="price-title p-relative fw-500 mt-40px mb-40px">
                                        <span class="price-title-lines p-absolute d-block"></span>
                                        <span class="list-price fw-600 color-blue fs-55">
                                            <?php echo pxaas_addons_get_price_formated( get_post_meta( get_the_ID(), P_META_PREFIX.'price_year', true ), false ); ?>
                                            <span class="fs-25 curen"><?php echo pxaas_addons_get_option('currency_symbol','$'); ?></span> 
                                        </span> 
                                        <span class="fs-20 mouth-cont"><?php esc_html_e( ' / year', 'pxaas-add-ons' ); ?></span>
                                    </h1>
                                </div>
                                <div class="price-content fl-wrap">
                                    <div class="price-desc fl-wrap">
                                        <?php the_content(); ?>
                                            
                                        <?php 
                                        $purchase_url = get_post_meta( get_the_ID(), P_META_PREFIX.'purchase_url', true );
                                        if( $purchase_url != '' ) : ?>
                                            <a href="<?php echo esc_url( $purchase_url ); ?>" class="price-link main-btn btn-3 mt-20px"><?php echo sprintf(__( 'Order %s', 'pxaas-add-ons' ), get_the_title()); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- plan-item end  -->
                    <?php 
                    endwhile; ?>
                <?php endif; ?> 
            </div>
        </div>
        <?php wp_reset_postdata();?>
        <?php

    }

    protected function _content_template() {}

   
    

}



