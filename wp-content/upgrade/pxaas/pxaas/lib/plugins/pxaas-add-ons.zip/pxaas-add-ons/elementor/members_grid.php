<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Members_Grid extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'members_grid';
    }

    // public function get_id() {
    //      return 'header-search';
    // }

    public function get_title() {
        return __( 'Members Grid', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'eicon-gallery-justified';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_query',
            [
                'label' => __( 'Members Query', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'ids',
            [
                'label' => __( 'Enter Member IDs', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter Member ids to show, separated by a comma. Leave empty to show all.", 'pxaas-add-ons')
                
            ]
        );
        $this->add_control(
            'ids_not',
            [
                'label' => __( 'Or Member IDs to Exclude', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter member ids to exclude, separated by a comma (,). Use if the field above is empty.", 'pxaas-add-ons')
                
            ]
        );

        $this->add_control(
            'order_by',
            [
                'label' => __( 'Order by', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'date' => esc_html__('Date', 'pxaas-add-ons'), 
                    'ID' => esc_html__('ID', 'pxaas-add-ons'), 
                    'author' => esc_html__('Author', 'pxaas-add-ons'), 
                    'title' => esc_html__('Title', 'pxaas-add-ons'), 
                    'modified' => esc_html__('Modified', 'pxaas-add-ons'),
                    'rand' => esc_html__('Random', 'pxaas-add-ons'),
                    'comment_count' => esc_html__('Comment Count', 'pxaas-add-ons'),
                    'menu_order' => esc_html__('Menu Order', 'pxaas-add-ons'),
                ],
                'label_block' => true,
                'default' => 'date',
                'separator' => 'before',
                'description' => esc_html__("Select how to sort retrieved posts. More at ", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __( 'Sort Order', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => esc_html__('Ascending', 'pxaas-add-ons'), 
                    'DESC' => esc_html__('Descending', 'pxaas-add-ons'), 
                ],
                'label_block' => true,
                'default' => 'DESC',
                'separator' => 'before',
                'description' => esc_html__("Select Ascending or Descending order. More at", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __( 'Members to show', 'pxaas-add-ons' ),
                'type' => Controls_Manager::NUMBER,
                'default' => '3',
                'label_block' => true,
                'description' => esc_html__("Number of members to show (-1 for all).", 'pxaas-add-ons'),
                
            ]
        );
        $this->end_controls_section();


        $this->start_controls_section(
            'section_layout',
            [
                'label' => __( 'Members Layout', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'columns_grid',
            [
                'label' => __( 'Columns Grid', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'col-md-12 '  => __( 'One Column', 'pxaas-add-ons' ),
                    'col-md-6 col-sm-6 '   => __( 'Two Column', 'pxaas-add-ons' ),
                    'col-md-4 col-sm-6 '   => __( 'Three Column', 'pxaas-add-ons' ),
                    'col-md-3 col-sm-6 '   => __( 'Four Column', 'pxaas-add-ons' ),
                    'col-md-2 col-sm-6 '   => __( 'Six Column', 'pxaas-add-ons' ),
                ],
                'default' => 'col-md-3 col-sm-6 ',
                // 'description' => esc_html__("Number of posts to show (-1 for all).", 'pxaas-add-ons'),
                // 'condition' => array (
                //     'view_member_style' => array('','2','3','4','5','6'),
                // ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'ani_type',
            [
                'label' => __( 'Entrance Animation', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => pxaas_addons_get_animation(),
                'label_block' => true,
                // 'condition' => array (
                //     'view_member_style' => array('','2','3','4','5','6'),
                // ),
            ]
        );
        $this->add_control(
            'ani_delay',
            [
                'label' => __( 'Animation Delay (s)', 'pxaas-add-ons' ),
                'type' => Controls_Manager::NUMBER,
                'default' => __( '0.3' , 'pxaas-add-ons' ),
                'min'     => 0,
                'step'    => 1,
                'label_block' => true,
                'description' => esc_html__("Time for the first element.", 'pxaas-add-ons'),
                // 'condition' => array (
                //     'view_member_style' => array('','2','3','4','5','6'),
                // ),
            ]
        );
        $this->add_control(
            'ani_delay_item',
            [
                'label' => __( 'Animation Delay Between Elements (s)', 'pxaas-add-ons' ),
                'type' => Controls_Manager::NUMBER,
                'default' => __( '0.2' , 'pxaas-add-ons' ),
                'min'     => 0,
                'step'    => 1,
                'label_block' => true,
                // 'condition' => array (
                //     'view_member_style' => array('','2','3','4','5','6'),
                // ),
            ]
        );
        $this->add_control(
            'view_member_style',
            [
                'label'   => __( 'See the member decoration style', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    ''  => __( 'Style Home-1', 'pxaas-add-ons' ),
                    '2' => __( 'Style Home-2', 'pxaas-add-ons' ),
                    '3' => __( 'Style Home-3', 'pxaas-add-ons' ),
                    '4' => __( 'Style Home-4', 'pxaas-add-ons' ),
                    // '5' => __( 'Style Home-5', 'pxaas-add-ons' ),
                    '6' => __( 'Style Home-6', 'pxaas-add-ons' ),
                    '7' => __( 'Style Home-7', 'pxaas-add-ons' ),
                    '8' => __( 'Style Home-8', 'pxaas-add-ons' ),
                ],
                'label_block' => true,
            ]
        );
        // $this->add_control(
        //     'desc',
        //     [
        //         'label' => __( 'Description', 'pxaas-add-ons' ),
        //         'type' => Controls_Manager::TEXT,
        //         'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt labore et dolore magna ut.',
        //         'label_block' => true,
        //         'description' => __("Enter member ids to exclude, separated by a comma (,). Use if the field above is empty.", 'pxaas-add-ons'),
        //         'condition' => array (
        //             'view_member_style' => array('7','8'),
        //         ),
        //         'label_block' => true,
        //     ]
        // );
        $this->add_control(
            'show_desc',
            [
                'label' => __( 'Show description', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Yes', 'pxaas-add-ons' ),
                'label_off' => __( 'No', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'show_btn',
            [
                'label' => __( 'Show Button Member Detail', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'btn_name',
            [
                'label' => __( 'Button Name', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Details',
                'label_block' => true,
                'condition' => array (
                    'show_btn' => 'yes',
                ),
            ]
        );
         $this->add_control(
            'is_external',
            [
                'label' => __( 'Is External Links', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => array (
                    'show_btn' => 'yes',
                ),
                'label_block' => true,
            ]
        ); 
            

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $animation = $settings['ani_type'];
        $target = $settings['is_external'] == 'yes'? ' target="_blank"':'';

        if(is_front_page()) {
            $paged = (get_query_var('page')) ? get_query_var('page') : 1;
        } else {
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        }

        if(!empty($settings['ids'])){
            $ids = explode(",", $settings['ids']);
            $post_args = array(
                'post_type' => 'cth_member',
                'paged' => $paged,
                'posts_per_page'=> $settings['posts_per_page'],
                'post__in' => $ids,
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],

                'post_status' => 'publish'
            );
        }elseif(!empty($settings['ids_not'])){
            $ids_not = explode(",", $settings['ids_not']);
            $post_args = array(
                'post_type' => 'cth_member',
                'paged' => $paged,
                'posts_per_page'=> $settings['posts_per_page'],
                'post__not_in' => $ids_not,
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],

                'post_status' => 'publish'
            );
        }else{
            $post_args = array(
                'post_type' => 'cth_member',
                'paged' => $paged,
                'posts_per_page'=> $settings['posts_per_page'],
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],

                'post_status' => 'publish'
            );
        }

        $css_classes = array(
            'row',
            'items-grid-holder',
        );
        
        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

        if($settings['view_member_style'] !== '') {
            $css_class.= ' members-'.$settings['view_member_style'];
        }else {
            $css_class.= ' members';
        }

        if($settings['view_member_style'] === '') {
            $css_lever = 'color-999 d-block mb-15px';
            $css_icon = 'color-fff fs-14 d-inline-block radius-50 bg-orange-hvr color-fff-hvr transition-2 mr-2px ml-2px';
        }elseif($settings['view_member_style'] === '2') {
            $css_lever = 'color-orange fs-15 d-block mb-15px';
            $css_icon = 'color-orange bg-orange-lh fs-14 d-inline-block radius-50 bg-orange-hvr color-fff-hvr transition-2 mr-2px ml-2px';
        }elseif($settings['view_member_style'] === '3') {
            $css_lever = 'color-blue fs-15 d-block mb-10px';
            $css_icon = 'color-orange fs-14 d-inline-block radius-50 bg-orange-hvr color-fff-hvr transition-2 mr-2px ml-2px';
        }elseif($settings['view_member_style'] === '4') {
            $css_lever = 'color-blue fs-15 d-block mb-10px';
            $css_icon = 'color-orange fs-14 d-inline-block radius-50 bg-orange-hvr color-fff-hvr transition-2 mr-2px ml-2px';
        }elseif($settings['view_member_style'] === '6') {
            $css_lever = 'color-blue fs-15 d-block mb-15px';
            $css_icon = 'color-fff fs-14 d-inline-block radius-50 bg-orange-hvr color-fff-hvr transition-2 mr-2px ml-2px';
        }elseif($settings['view_member_style'] === '7') {
            $css_lever = 'color-green fs-15 d-block mb-15px';
            $css_icon = 'color-fff fs-14 d-inline-block radius-50 bg-blue-hvr color-fff-hvr transition-2 mr-2px ml-2px';
        }elseif($settings['view_member_style'] === '8') {
            $css_lever = 'color-e5e5e5 fs-15 d-block mb-15px';
            $css_icon = 'color-fff fs-14 d-inline-block radius-50 bg-blue-hvr color-fff-hvr transition-2 mr-2px ml-2px';
        }


        
        
        ?>
        <div class="<?php echo esc_attr($css_class );?>">
        <?php 
            $delay = $settings['ani_delay'];
            $posts_query = new \WP_Query($post_args);
            if($posts_query->have_posts()) : ?>
                <?php while($posts_query->have_posts()) : $posts_query->the_post(); ?>
                    <?php if($settings['view_member_style'] === '' || $settings['view_member_style'] === '3') { ?>
                        <div class='team-area-2 <?php echo $settings['columns_grid']; ?><?php echo $animation; ?>' data-wow-delay="<?php echo $delay.'s'; ?>">
                            <div id="member-<?php the_ID(); ?>" <?php post_class('items-grid-item team-box mt-25px mb-25px'); ?>>
                                <div class="p-relative o-hidden d-inline-block radius-50 mb-20px ml-auto mr-auto">
                                <?php
                                    if(has_post_thumbnail( )) the_post_thumbnail('pxaas-member',array('class'=>'respimg radius-50 transition-3') ); ?>
                                    <div class="social p-absolute flex-center transition-4">
                                        <?php if(get_post_meta(get_the_ID(), '_cth_twitterurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Follow on Twitter','pxaas-add-ons');?>" href="<?php echo esc_url( get_post_meta(get_the_ID(), '_cth_twitterurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-twitter"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Like on Facebook','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-facebook"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Circle on Google Plus','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)) ;?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-google-plus"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Be Friend on Linkedin','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-linkedin"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Follow on Instagram','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-instagram"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Follow on  Tumblr','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-tumblr"></i></a>
                                        <?php } ?>  
                                        <?php if(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('View Behance profile','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-behance"></i></a>
                                        <?php } ?>
                                    </div>
                                </div>
                                <h5 class="mb-0px"><?php the_title(); ?></h5>
                                <span class="<?php echo $css_lever; ?>"><?php echo get_post_meta( get_the_ID(), P_META_PREFIX.'member_job', true ); ?></span>
                                <?php if($settings['show_desc'] == 'yes') echo '<div class="member-excerpt">'.get_the_excerpt().'</div>'; ?>
                                <?php if($settings['show_btn'] === 'yes'): ?>
                                    <a class="main-btn btn-3 btn-orange mt-10px" href="<?php echo get_permalink(); ?>" <?php echo $target; ?>><?php echo $settings['btn_name']; ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php }elseif($settings['view_member_style'] === '6') { ?>
                        <div class='team-area-2 <?php echo $settings['columns_grid']; ?><?php echo $animation; ?>' data-wow-delay="<?php echo $delay.'s'; ?>">
                            <div id="member-<?php the_ID(); ?>" <?php post_class('items-grid-item mt-25px mb-25px'); ?>>
                                <div class="p-relative o-hidden d-inline-block radius-10px mb-20px ml-auto mr-auto">
                                <?php
                                    if(has_post_thumbnail( )) the_post_thumbnail('pxaas-member',array('class'=>'respimg radius-10px transition-3') ); ?>
                                    <div class="social p-absolute flex-center transition-4">
                                        <?php if(get_post_meta(get_the_ID(), '_cth_twitterurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Follow on Twitter','pxaas-add-ons');?>" href="<?php echo esc_url( get_post_meta(get_the_ID(), '_cth_twitterurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-twitter"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Like on Facebook','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-facebook"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Circle on Google Plus','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)) ;?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-google-plus"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Be Friend on Linkedin','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-linkedin"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Follow on Instagram','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-instagram"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Follow on  Tumblr','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-tumblr"></i></a>
                                        <?php } ?>  
                                        <?php if(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('View Behance profile','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-behance"></i></a>
                                        <?php } ?>
                                    </div>
                                </div>
                                <h5 class="mb-0px"><?php the_title(); ?></h5>
                                <span class="<?php echo $css_lever; ?>"><?php echo get_post_meta( get_the_ID(), P_META_PREFIX.'member_job', true ); ?></span>
                                <?php if($settings['show_desc'] == 'yes') echo '<div class="member-excerpt">'.get_the_excerpt().'</div>'; ?>
                                <?php if($settings['show_btn'] === 'yes'): ?>
                                    <a class="main-btn btn-3 btn-orange mt-10px" href="<?php echo get_permalink(); ?>" <?php echo $target; ?>><?php echo $settings['btn_name']; ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php }elseif($settings['view_member_style'] === '2' ){ ?>
                        <div class='team-area <?php echo $settings['columns_grid']; ?> <?php echo $animation; ?>' data-wow-delay="<?php echo $delay.'s'; ?>">
                            <div id="member-<?php the_ID(); ?>" <?php post_class('items-grid-item team-box orange radius-5px transition-4 mt-25px mb-25px'); ?>>
                                    
                                <?php if(has_post_thumbnail( )) { ?>
                                <div class="o-hidden radius-50 d-inline-block mb-20px ml-auto mr-auto avatar-wrap">
                                    <?php the_post_thumbnail('pxaas-member',array('class'=>'respimg radius-50 transition-3') ); ?>
                                </div>
                                <?php } ?>

                                <h5 class="mb-0px"><?php the_title(); ?></h5>
                                <span class="color-999 fs-15 d-block mb-15px"><?php echo get_post_meta( get_the_ID(), P_META_PREFIX.'member_job', true ); ?></span>
                                <?php if($settings['show_desc'] == 'yes') echo '<div class="member-excerpt">'.get_the_excerpt().'</div>'; ?>
                                <?php if($settings['show_btn'] === 'yes'): ?>
                                    <a class="main-btn btn-3 mt-10px" href="<?php echo get_permalink(); ?>" <?php echo $target; ?>><?php echo $settings['btn_name']; ?></a>
                                <?php endif; ?>

                                <?php if(get_post_meta(get_the_ID(), '_cth_twitterurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Follow on Twitter','pxaas-add-ons');?>" href="<?php echo esc_url( get_post_meta(get_the_ID(), '_cth_twitterurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-twitter"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Like on Facebook','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-facebook"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Circle on Google Plus','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)) ;?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-google-plus"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Be Friend on Linkedin','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-linkedin"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Follow on Instagram','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-instagram"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Follow on  Tumblr','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-tumblr"></i></a>
                                <?php } ?>  
                                <?php if(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('View Behance profile','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-behance"></i></a>
                                <?php } ?>

                            </div>
                        </div>
                    <?php }elseif($settings['view_member_style'] === '4' || $settings['view_member_style'] === '5'){ ?>
                        <div class='team-area <?php echo $settings['columns_grid']; ?> <?php echo $animation; ?>' data-wow-delay="<?php echo $delay.'s'; ?>">
                            <div id="member-<?php the_ID(); ?>" <?php post_class('items-grid-item mt-25px mb-25px bg-orange-lh radius-10px p-30px'); ?>>
                                <?php if(has_post_thumbnail( )) { ?>
                                <div class="o-hidden d-inline-block radius-50 mb-20px ml-auto mr-auto avatar-wrap">
                                    <?php the_post_thumbnail('pxaas-member',array('class'=>'respimg radius-10px transition-3') ); ?>
                                </div>
                                <?php } ?>

                                <h5 class="mb-0px"><?php the_title(); ?></h5>
                                <span class="<?php echo $css_lever; ?>"><?php echo get_post_meta( get_the_ID(), P_META_PREFIX.'member_job', true ); ?></span>
                                <?php if($settings['show_desc'] == 'yes') echo '<div class="member-excerpt">'.get_the_excerpt().'</div>'; ?>
                                <?php if($settings['show_btn'] === 'yes'): ?>
                                    <a class="main-btn btn-3 btn-orange mt-10px" href="<?php echo get_permalink(); ?>" <?php echo $target; ?>><?php echo $settings['btn_name']; ?></a>
                                <?php endif; ?>

                                <?php if(get_post_meta(get_the_ID(), '_cth_twitterurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Follow on Twitter','pxaas-add-ons');?>" href="<?php echo esc_url( get_post_meta(get_the_ID(), '_cth_twitterurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-twitter"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Like on Facebook','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-facebook"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Circle on Google Plus','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)) ;?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-google-plus"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Be Friend on Linkedin','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-linkedin"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Follow on Instagram','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-instagram"></i></a>
                                <?php } ?>
                                <?php if(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('Follow on  Tumblr','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-tumblr"></i></a>
                                <?php } ?>  
                                <?php if(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true)!=''){ ?>
                                    <a title="<?php esc_html_e('View Behance profile','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-behance"></i></a>
                                <?php } ?>


                            </div>
                        </div>

                    <?php }elseif ($settings['view_member_style'] === '7') { ?>
                        <div class='team-area-3 <?php echo $settings['columns_grid']; ?><?php echo $animation; ?>' data-wow-delay="<?php echo $delay.'s'; ?>">
                            <div id="member-<?php the_ID(); ?>" <?php post_class('items-grid-item mt-25px mb-25px'); ?>>
                                <div class="p-relative o-hidden d-inline-block radius-50 mb-20px ml-auto mr-auto">
                                <?php
                                    if(has_post_thumbnail( )) the_post_thumbnail('pxaas-member',array('class'=>'respimg radius-50 transition-3') ); ?>
                                    <div class="social p-absolute flex-center transition-4">
                                        <?php if(get_post_meta(get_the_ID(), '_cth_twitterurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Follow on Twitter','pxaas-add-ons');?>" href="<?php echo esc_url( get_post_meta(get_the_ID(), '_cth_twitterurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-twitter"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Like on Facebook','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-facebook"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Circle on Google Plus','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)) ;?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-google-plus"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Be Friend on Linkedin','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-linkedin"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Follow on Instagram','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-instagram"></i></a>
                                        <?php } ?>
                                        <?php if(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('Follow on  Tumblr','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-tumblr"></i></a>
                                        <?php } ?>  
                                        <?php if(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true)!=''){ ?>
                                            <a title="<?php esc_html_e('View Behance profile','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-behance"></i></a>
                                        <?php } ?>
                                    </div>
                                </div>
                                <h5 class="mb-0px"><?php the_title(); ?></h5>
                                <span class="<?php echo $css_lever; ?>"><?php echo get_post_meta( get_the_ID(), P_META_PREFIX.'member_job', true ); ?></span>
                                <?php if($settings['show_desc'] == 'yes') echo '<div class="member-excerpt">'.get_the_excerpt().'</div>'; ?>
                                <?php if($settings['show_btn'] === 'yes'): ?>
                                    <a class="main-btn btn-3 btn-orange mt-10px" href="<?php echo get_permalink(); ?>" <?php echo $target; ?>><?php echo $settings['btn_name']; ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php }elseif($settings['view_member_style'] === '8') { ?>
                        <div class='team-area-4 <?php echo $settings['columns_grid']; ?><?php echo $animation; ?>' data-wow-delay="<?php echo $delay.'s'; ?>">
                            <div id="member-<?php the_ID(); ?>" <?php post_class('items-grid-item mt-25px mb-25px'); ?>>
                                <div class="p-relative o-hidden d-inline-block mb-20px ml-auto mr-auto">
                                <?php
                                    if(has_post_thumbnail( )) the_post_thumbnail('pxaas-member',array('class'=>'respimg transition-3') ); ?>
                                    <div class="social p-absolute flex-center transition-4">
                                        <div>
                                            <h5 class="mb-0px color-fff"><?php the_title(); ?></h5>
                                            <span class="<?php echo $css_lever; ?>"><?php echo get_post_meta( get_the_ID(), P_META_PREFIX.'member_job', true ); ?></span>
                                            <?php if($settings['show_desc'] == 'yes') echo '<div class="member-excerpt">'.get_the_excerpt().'</div>'; ?>
                                            <?php if($settings['show_btn'] === 'yes'): ?>
                                                <a class="main-btn btn-3 btn-orange mt-10px" href="<?php echo get_permalink(); ?>" <?php echo $target; ?>><?php echo $settings['btn_name']; ?></a>
                                            <?php endif; ?>
                                            <?php if(get_post_meta(get_the_ID(), '_cth_twitterurl' ,true)!=''){ ?>
                                                <a title="<?php esc_html_e('Follow on Twitter','pxaas-add-ons');?>" href="<?php echo esc_url( get_post_meta(get_the_ID(), '_cth_twitterurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-twitter"></i></a>
                                            <?php } ?>
                                            <?php if(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)!=''){ ?>
                                                <a title="<?php esc_html_e('Like on Facebook','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_facebookurl' ,true)); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-facebook"></i></a>
                                            <?php } ?>
                                            <?php if(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)!=''){ ?>
                                                <a title="<?php esc_html_e('Circle on Google Plus','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_googleplusurl' ,true)) ;?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-google-plus"></i></a>
                                            <?php } ?>
                                            <?php if(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true)!=''){ ?>
                                                <a title="<?php esc_html_e('Be Friend on Linkedin','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_linkedinurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-linkedin"></i></a>
                                            <?php } ?>
                                            <?php if(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true)!=''){ ?>
                                                <a title="<?php esc_html_e('Follow on Instagram','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_instagramurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-instagram"></i></a>
                                            <?php } ?>
                                            <?php if(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true)!=''){ ?>
                                                <a title="<?php esc_html_e('Follow on  Tumblr','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_tumblrurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-tumblr"></i></a>
                                            <?php } ?>  
                                            <?php if(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true)!=''){ ?>
                                                <a title="<?php esc_html_e('View Behance profile','pxaas-add-ons');?>" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cth_behanceurl' ,true) ); ?>" target="_blank" class="<?php echo $css_icon; ?>"><i class="fa fa-behance"></i></a>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                            
                            </div>
                        </div>
                    <?php } ?>
                <?php $delay += $settings['ani_delay_item']; endwhile; ?>
            <?php endif; ?> 

        </div>
        <?php
        // if($settings['show_pagination'] == 'yes') pxaas_addons_custom_pagination($posts_query->max_num_pages,$range = 2, $posts_query) ;
        ?>
        <?php
            // $url = $settings['view_all_link']['url'];
            // $target = $settings['view_all_link']['is_external'] ? 'target="_blank"' : '';
            // if($url != '') echo '<div class="all-members-link"><a href="' . $url . '" ' . $target .' class="btn big-btn circle-btn dec-btn color-bg flat-btn">'.__('View All','pxaas-add-ons').'<i class="fa fa-eye"></i></a></div>';
        ?>
        <?php wp_reset_postdata();?>
        <?php

    }

    protected function _content_template() {}

   
    

}



