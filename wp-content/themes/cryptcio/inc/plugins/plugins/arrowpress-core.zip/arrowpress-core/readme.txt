=== ArrowPress Shortcodes ===

Register shortcodes for ArrowPress theme.
Text-domain: arrowpress-core

version: 1.0.0