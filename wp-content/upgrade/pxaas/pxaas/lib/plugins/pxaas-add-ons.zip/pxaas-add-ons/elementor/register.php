<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Register extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'register';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'register', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Form Register', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Sign Up',
                'label_block' => true,
                
            ]
        );
        $this->add_control(
            'social',
            [
                'label' => __( 'Social network link', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXTAREA, // WYSIWYG,
                'default' => 'with your social network',
                // 'show_label' => false,
                'condition' => array(
                    'social' => 'yes',
                ),
            ]
        );
        $this->add_control(
            'link_g_show',
            [
                'label' => __( 'Link Google', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => array(
                    'social' => 'yes',
                ),
            ]
        );
        $this->add_control(
            'link_g',
            [
             'label' => __( 'URL', 'pxaas-add-ons' ),
             'type' => Controls_Manager::URL,
             'default' => [
                'url' => '#',
                'is_external' => '',
             ],
             'show_external' => true, // Show the 'open in new tab' button.
             'condition' => array(
                    'link_g' => 'yes',
                ),
            ]
        );
        $this->add_control(
            'link_f_show',
            [
                'label' => __( 'Link Facebook', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => array(
                    'social' => 'yes',
                ),
            ]
        );
        $this->add_control(
            'link_f',
            [
             'label' => __( 'URL', 'pxaas-add-ons' ),
             'type' => Controls_Manager::URL,
             'default' => [
                'url' => '#',
                'is_external' => '',
             ],
             'show_external' => true, // Show the 'open in new tab' button.
             'condition' => array(
                    'link_f' => 'yes',
                ),
            ]
        );
        $this->add_control(
            'link_t_show',
            [
                'label' => __( 'Link Twitter', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => array(
                    'social' => 'yes',
                ),
            ]
        );
        $this->add_control(
            'link_t',
            [
                'label' => __( 'URL', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'show_external' => true, // Show the 'open in new tab' button.
                'condition' => array(
                    'link_t' => 'yes',
                ),
            ]
        );
        $this->add_control(
            'link_terms',
            [
                'label' => __( 'URL Terms of Use', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'show_external' => true, // Show the 'open in new tab' button.
             
            ]
        );
        $this->add_control(
            'link_policy',
            [
                'label' => __( 'URL Privacy Policy', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'show_external' => true, // Show the 'open in new tab' button.
            ]
        );
        $this->add_control(
            'btn_title',
            [
                'label' => __( 'Button Title', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT, // WYSIWYG,
                'default' => 'Sign up',
                // 'show_label' => false,
            ]
        );
        $this->add_control(
            'btn_title_login',
            [
                'label' => __( 'Button Title Log In', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT, // WYSIWYG,
                'default' => 'Already registered? Sign in',
                // 'show_label' => false,
            ]
        );
        $this->add_control(
            'link_login',
            [
             'label' => __( 'URL Log In', 'pxaas-add-ons' ),
             'type' => Controls_Manager::URL,
             'default' => [
                'url' => '#',
                'is_external' => '',
             ],
             'show_external' => true, // Show the 'open in new tab' button.
            ]
        );
        $this->add_control(
            'is_external',
            [
                'label' => __( 'Is External Links', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'class',
            [
                'label' => __( 'Css Class', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                
            ]
        );
        

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $link_login = $settings['link_login'];
        $target = $settings['is_external'] == 'yes'? ' target="_blank"':'';

        $css_classes_wrap = array(
            'welcome-page-register',
        );
        $css_class_wrap = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes_wrap ) ) );
    
        ?>
        <div class="<?php echo esc_attr($css_class_wrap );?>">
            <?php if($settings['title']!==''): ?>
                <h1><?php echo $settings['title'] ?></h1>
            <?php endif; ?>
            <?php if($settings['social'] == 'yes'): ?>
                <?php if($settings['content']!==''): ?>
                    <h6 class="fw-400 mt-20px mb-10px color-666"><?php echo $settings['content']; ?></h6>
                <?php endif; ?>
                <?php if($settings['link_g_show'] == 'yes' || $settings['link_f_show'] == 'yes' || $settings['link_t_show'] == 'yes'): ?>
                    <?php if($settings['link_g_show'] == 'yes'): ?>
                        <a href="<?php echo $settings['link_g']['url']; ?>" class="d-inline-block social p-relative mr-10px mb-10px pl-30px pr-30px pt-10px pb-10px radius-5px color-fff color-fff-hvr google" <?php echo $target; ?>>
                            <i class="fa fa-google-plus p-absolute"></i>
                            <span class="pl-20px"><?php esc_html_e( 'Google', 'pxaas-add-ons' ) ?></span>
                        </a>
                    <?php endif; ?>
                    <?php if($settings['link_f_show'] == 'yes'): ?>
                        <a href="<?php echo $settings['link_f']['url']; ?>" class="d-inline-block social p-relative mr-10px mb-10px pl-30px pr-30px pt-10px pb-10px radius-5px color-fff color-fff-hvr facebook" <?php echo $target; ?>>
                            <i class="fa fa-facebook p-absolute"></i>
                            <span class="pl-20px"><?php esc_html_e( 'Facebook', 'pxaas-add-ons' ) ?></span>
                        </a>
                    <?php endif; ?>
                    <?php if($settings['link_t_show'] == 'yes'): ?>
                        <a href="<?php echo $settings['link_t']['url']; ?>" class="d-inline-block social p-relative mr-10px mb-10px pl-30px pr-30px pt-10px pb-10px radius-5px color-fff color-fff-hvr twitter" <?php echo $target; ?>>
                            <i class="fa fa-twitter p-absolute"></i>
                            <span class="pl-20px"><?php esc_html_e( 'Twitter', 'pxaas-add-ons' ) ?></span>
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
                <h5 class="fw-400 mt-10px separator p-relative text-center">
                    <span class="bg-gray p-relative p-15px z-index-1"><?php esc_html_e( 'Or', 'pxaas-add-ons' ) ?></span>
                </h5>
            <?php endif; ?>

            <form id="easybook-register" class="mt-30px main-register-form" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group p-relative">
                            <label for="reg_username">
                                <input id="reg_username" name="username" type="text" placeholder="Your Name" required="" class="d-block w-100" onClick="this.select()" value="">
                                <i class="fa fa-user fs-20 color-blue p-absolute"></i> 
                            </label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group p-relative">
                            <label for="reg_email">
                                <input id="reg_email" name="email" type="email" placeholder="Your Email" required="" class="d-block w-100" onClick="this.select()" value="">
                                <i class="fa fa-envelope fs-20 color-blue p-absolute"></i> 
                            </label>
                        </div>
                            
                    </div>
                </div>
                <div class="form-group p-relative">
                    <label for="reg_password">
                        <input id="reg_password" name="password" type="password" placeholder="Your Password" required="" class="d-inline-block w-100" onClick="this.select()" value="">
                        <i class="fa fa-lock fs-20 color-blue p-absolute"></i> 
                    </label>
                </div>
                <div class="form-group p-relative">
                    <label for="reg_password_retype">
                        <input id="reg_password_retype" name="password_retype"  type="password" placeholder="Repeat Your Password" required="" class="d-inline-block w-100" onClick="this.select()" value="">
                        <i class="fa fa-lock fs-20 color-blue p-absolute"></i> 
                    </label>
                </div>
                <div class="log-message"></div>
                <div class="form-group mb-30px">
                    <label for="check" class="check">
                        <input id="check" type="checkbox" name="ma" value="male" class="w-auto h-auto" required=""><?php esc_html_e( '  you accept our ', 'pxaas-add-ons' ) ?><a href="<?php echo $settings['link_terms']['url'] ?>" <?php echo $target; ?>><?php esc_html_e( 'Terms  of Use', 'pxaas-add-ons' ) ?></a><?php esc_html_e( ' and our ', 'pxaas-add-ons' ) ?><a href="<?php echo $settings['link_policy']['url'] ?>" <?php echo $target; ?>><?php esc_html_e( 'Privacy Policy', 'pxaas-add-ons' ) ?></a>.  
                    </label>
                </div>    
                    
                <button role="button" class="main-btn btn-3 before-gray"><?php echo $settings['btn_title']; ?></button>

                <?php
                    // this prevent automated script for unwanted spam
                    if ( function_exists( 'wp_nonce_field' ) ) 
                        wp_nonce_field( 'pxaas-register', '_regnonce' );
                ?>
                
                <input type="hidden" name="action" value="pxaas_register">

            </form>

            <a href="<?php echo $settings['link_login']['url']; ?>" class="d-inline-block mt-20px"><?php echo $settings['btn_title_login']; ?></a>
        </div>
        <?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

    // }

   
   

}

// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

