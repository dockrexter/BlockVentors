<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Testimonials_Slider extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    
    */
    public function get_name() {
        return 'testimonials_slider';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Testimonials Slider', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_query',
            [
                'label' => __( 'Members Query', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'ids',
            [
                'label' => __( 'Enter Member IDs', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter Member ids to show, separated by a comma. Leave empty to show all.", 'pxaas-add-ons')
                
            ]
        );
        $this->add_control(
            'ids_not',
            [
                'label' => __( 'Or Member IDs to Exclude', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter member ids to exclude, separated by a comma (,). Use if the field above is empty.", 'pxaas-add-ons')
                
            ]
        );

        $this->add_control(
            'order_by',
            [
                'label' => __( 'Order by', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'date' => esc_html__('Date', 'pxaas-add-ons'), 
                    'ID' => esc_html__('ID', 'pxaas-add-ons'), 
                    'author' => esc_html__('Author', 'pxaas-add-ons'), 
                    'title' => esc_html__('Title', 'pxaas-add-ons'), 
                    'modified' => esc_html__('Modified', 'pxaas-add-ons'),
                    'rand' => esc_html__('Random', 'pxaas-add-ons'),
                    'comment_count' => esc_html__('Comment Count', 'pxaas-add-ons'),
                    'menu_order' => esc_html__('Menu Order', 'pxaas-add-ons'),
                ],
                'default' => 'date',
                'separator' => 'before',
                'description' => esc_html__("Select how to sort retrieved posts. More at ", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __( 'Sort Order', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => esc_html__('Ascending', 'pxaas-add-ons'), 
                    'DESC' => esc_html__('Descending', 'pxaas-add-ons'), 
                ],
                'default' => 'DESC',
                'separator' => 'before',
                'description' => esc_html__("Select Ascending or Descending order. More at", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __( 'Members to show', 'pxaas-add-ons' ),
                'type' => Controls_Manager::NUMBER,
                'default' => '3',
                'description' => esc_html__("Number of members to show (-1 for all).", 'pxaas-add-ons'),
                
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'slider_op',
            [
                'label' => __( 'Members Option', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'respon',
            [
                'label' => __( 'Responsive', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '320:1,768:1,992:1,1200:1',
            ]
        );
        $this->add_control(
            'speed',
            [
                'label' => __( 'Speed', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '300',
                'label_block' => true,
                // 'description' => __("Enter Member ids to show, separated by a comma. Leave empty to show all.", 'pxaas-add-ons')
                
            ]
        );
        $this->add_control(
            'au_play',
            [
                'label' => __( 'Auto Play', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'loop',
            [
                'label' => __( 'Loop', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'navi',
            [
                'label' => __( 'Show Navigation', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'dots',
            [
                'label' => __( 'Show Dots', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'view_testi_slider',
            [
                'label'   => __( 'See the testimonials decoration style', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    ''  => __( 'Style 1', 'pxaas-add-ons' ),
                    '2' => __( 'Style 2', 'pxaas-add-ons' ),
                    '3' => __( 'Style 3', 'pxaas-add-ons' ),
                    '4' => __( 'Style 4', 'pxaas-add-ons' ),
                    '5' => __( 'Style 5', 'pxaas-add-ons' ),
                ],
            ]
        );
        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $dataArr = array();
        $dataArr['smartSpeed'] = (int)$settings['speed'];
        if($settings['au_play'] == 'yes') $dataArr['autoplay'] = true;
        if($settings['loop'] == 'yes') 
            $dataArr['loop'] = true;
        else 
            $dataArr['loop'] = false;
        if($settings['navi'] == 'yes') 
            $dataArr['nav'] = true;
        else 
            $dataArr['nav'] = false;
        if($settings['dots'] == 'yes') 
            $dataArr['dots'] = true;
        else 
            $dataArr['dots'] = false;
        if(!empty($settings['respon'])){
            // $css_classes .=' resp-ena';
            $dataArr['responsive'] = $settings['respon'];
        }
        // if(is_numeric($spacing)) $dataArr['margin'] = (int)$spacing;

        if(is_front_page()) {
            $paged = (get_query_var('page')) ? get_query_var('page') : 1;
        } else {
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        }

        if(!empty($settings['ids'])){
            $ids = explode(",", $settings['ids']);
            $post_args = array(
                'post_type' => 'cth_testi',
                'paged' => $paged,
                'posts_per_page'=> $settings['posts_per_page'],
                'post__in' => $ids,
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],

                'post_status' => 'publish'
            );
        }elseif(!empty($settings['ids_not'])){
            $ids_not = explode(",", $settings['ids_not']);
            $post_args = array(
                'post_type' => 'cth_testi',
                'paged' => $paged,
                'posts_per_page'=> $settings['posts_per_page'],
                'post__not_in' => $ids_not,
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],

                'post_status' => 'publish'
            );
        }else{
            $post_args = array(
                'post_type' => 'cth_testi',
                'paged' => $paged,
                'posts_per_page'=> $settings['posts_per_page'],
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],

                'post_status' => 'publish'
            );
        }

        $css_classes = array(
            'items-grid-holder',
            'section-team',
        );
        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

        if($settings['view_testi_slider'] !== '') {
            $css_class.= ' testimonials-'.$settings['view_testi_slider'];
        }else {
            $css_class.= ' testimonials';
        }

        if($settings['view_testi_slider'] === '3') {
            $color_span = 'color-green ';
        }elseif ($settings['view_testi_slider'] === '4') {
            $color_span = 'color-blue ';
        }elseif ($settings['view_testi_slider'] === '5') {
            $css_class.= ' col-md-7';
        }

        if($settings['view_testi_slider'] === '' || $settings['view_testi_slider'] === '2') {
            $caro = "testi-slider ";    
        }else {
            $caro = "single-slider ";
        }
        ?>

        <div class="<?php echo esc_attr($css_class );?>">
            <div class="<?php echo $caro; ?>owl-carousel owl-theme" data-options='<?php echo json_encode($dataArr);?>'>
                <?php 
                $posts_query = new \WP_Query($post_args);
                if($posts_query->have_posts()) : ?>
                    <?php while($posts_query->have_posts()) : $posts_query->the_post(); ?>
                        <div class="item cth-testi-item">
                            <?php if($settings['view_testi_slider'] === '' || $settings['view_testi_slider'] === '2'){ ?>
                                <div class="single-review">
                                    <?php the_post_thumbnail('pxaas-featured-image', array('class'=>'testi-thumb radius-50 ml-auto mr-auto mb-20px') ); ?>
                                    <div class="testi-content fs-16 fw-300 color-555"><?php the_content(); ?></div>
                                    <h5 class="mt-20px mb-0px"><?php the_title(); ?></h5>
                                    <span class="color-orange fw-400 fs-15 d-block mb-10px"><?php echo get_post_meta(get_the_id(), '_cth_job', true ); ?></span>
                                </div>
                            <?php }elseif($settings['view_testi_slider'] === '3' || $settings['view_testi_slider'] === '4') { ?>
                                <div class="single-review">
                                    <div class="row justify-content-md-center bg-fff p-50px">
                                        <div class="col-md-3">
                                            <?php the_post_thumbnail('pxaas-featured-image', array('class'=>'testi-thumb radius-50 ml-auto mr-auto mb-20px') ); ?>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="testi-content"><?php the_content(); ?></div>
                                            <h5 class="mt-20px mb-0px"><?php the_title(); ?></h5>
                                            <span class="<?php echo $color_span; ?>fw-400 fs-15 d-block mb-10px"><?php echo get_post_meta(get_the_id(), '_cth_job', true ); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php }else { ?>
                                <div class="single-review">
                                    <div class="testi-content fs-20 d-block mb-25px fw-300 color-ccc"><i class="fa fa-quote-left fs-25 mb-10px color-green d-block"></i><?php the_content(); ?></div>
                                    <?php the_post_thumbnail('pxaas-featured-image', array('class'=>'testi-thumb radius-50 mb-20px') ); ?>
                                    <h5 class="color-fff mt-20px mb-0px"><?php the_title(); ?></h5>
                                    <span class="color-green fw-300 fs-15 d-block mb-5px"><?php echo get_post_meta(get_the_id(), '_cth_job', true ); ?></span>
                                </div>
                            <?php } ?>
                        </div>
                    <?php endwhile;
                endif; ?>
            </div>
        </div>

<?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

}


// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

