<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Lost_Pass extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'lost_pass';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Lost Password', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Form lost password', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'pass_icon',
            [
                'label' => __( 'Icon', 'pxaas-add-ons' ),
                'type' => Controls_Manager::ICON,
                'default' => 'fa fa-lock',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Forget Your Password !',
                'label_block' => true,
                
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXTAREA, // WYSIWYG,
                'default' => 'Don'.'t worry ! enter your email and we will send you a rest',
                // 'show_label' => false,
            ]
        );
    
        $this->add_control(
            'btn_title',
            [
                'label' => __( 'Button Title', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT, // WYSIWYG,
                'default' => 'Send Request',
                // 'show_label' => false,
            ]
        );
        $this->add_control(
            'btn_title_login',
            [
                'label' => __( 'Button Title Log In', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT, // WYSIWYG,
                'default' => 'Log In',
                // 'show_label' => false,
            ]
        );
        $this->add_control(
            'link_login',
            [
             'label' => __( 'URL Log In', 'pxaas-add-ons' ),
             'type' => Controls_Manager::URL,
             'default' => [
                'url' => '#',
                'is_external' => '',
             ],
             'show_external' => true, // Show the 'open in new tab' button.
            ]
        );
        $this->add_control(
            'is_external',
            [
                'label' => __( 'Is External Links', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'class',
            [
                'label' => __( 'Css Class', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                
            ]
        );
        

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $link_login = $settings['link_login'];
        $target = $settings['is_external'] == 'yes'? ' target="_blank"':'';

        $css_classes_wrap = array(
            'welcome-page-lost-pass',
        );
        $css_class_wrap = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes_wrap ) ) );

        
            
        ?>
        <div class="<?php echo esc_attr($css_class_wrap );?>">
            <i class="<?php echo $settings['pass_icon']; ?> fs-50 color-blue mb-10px"></i>
            <?php if($settings['title']!==''): ?>
                <h2><?php echo $settings['title'] ?></h2>
            <?php endif; ?>
            <?php if($settings['content']!==''): ?>
                <p class="mb-50px"><?php echo $settings['content']; ?></p>
            <?php endif; ?>
            <form class="reset-password-form custom-form mt-30px" method="post">
                <div class="form-group p-relative">
                    <label for="user_reset">
                        <input id="user_reset" name="user_login" type="text" placeholder="Your Email" class="d-block mb-20px" onClick="this.select()" value="" required>
                        <i class="fa fa-envelope fs-20 color-blue p-absolute"></i> 
                    </label>
                </div>
                <button role="button" class="main-btn btn-3 before-gray"><?php echo $settings['btn_title']; ?></button>
                <a href="login-page" class="ml-10px mt-20px mb-10px" <?php echo $target; ?>><?php echo $settings['btn_title_login']; ?></a>
                <input type="hidden" name="action" value="pxaas_losspass">
            </form>
            
        </div>
        <?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

    // }

   
   

}

// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

