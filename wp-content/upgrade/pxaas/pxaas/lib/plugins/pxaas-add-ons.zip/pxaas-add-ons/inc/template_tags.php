<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



function pxaas_addons_get_current_url(){
    global $wp;
    // get current page with query string
    return add_query_arg( $_SERVER['QUERY_STRING'], '', home_url( $wp->request ) );

    
    // $current_url = home_url(add_query_arg(array(),$wp->request));
    // return $current_url;
}

/** 
 * get template part file related to plugin folder
 *
 */
if(!function_exists('pxaas_addons_get_template_part')){
    /**
     * Load a template part into a template
     *
     * Makes it easy for a theme to reuse sections of code in a easy to overload way
     * for child themes.
     *
     * Includes the named template part for a theme or if a name is specified then a
     * specialised part will be included. If the theme contains no {slug}.php file
     * then no template will be included.
     *
     * The template is included using require, not require_once, so you may include the
     * same template part multiple times.
     *
     * For the $name parameter, if the file is called "{slug}-special.php" then specify
     * "special".
      * For the var parameter, simple create an array of variables you want to access in the template
     * and then access them e.g. 
     * 
     * array("var1=>"Something","var2"=>"Another One","var3"=>"heres a third";
     * 
     * becomes
     * 
     * $var1, $var2, $var3 within the template file.
     *
     * @since 1.0.0
     *
     * @param string $slug The slug name for the generic template.
     * @param string $name The name of the specialised template.
     * @param array $vars The list of variables to carry over to the template
     * @author CTHthemes 
     * @ref http://www.zmastaa.com/2015/02/06/php-2/wordpress-passing-variables-get_template_part
     * @ref http://keithdevon.com/passing-variables-to-get_template_part-in-wordpress/
     */
    function pxaas_addons_get_template_part( $slug, $name = null, $vars = null ) {

        $template = "{$slug}.php";
        $name = (string) $name;
        if ( '' !== $name && file_exists( PXAAS_ADD_ONS_DIR ."{$slug}-{$name}.php" ) ) {
            $template = "{$slug}-{$name}.php";
        }

        if(isset($vars)) extract($vars);
        if($located = locate_template( 'cth_templates/'.$template )){
            include($located);
        }else{
            include(PXAAS_ADD_ONS_DIR.$template);
        }
    }
}


function pxaas_addons_get_socials_list(){

    $socials = array(
        'facebook' => __( 'Facebook',  'pxaas-add-ons' ),
        'twitter' => __( 'Twitter',  'pxaas-add-ons' ),
        'youtube' => __( 'Youtube',  'pxaas-add-ons' ),
        'vimeo' => __( 'Vimeo',  'pxaas-add-ons' ),
        'instagram' => __( 'Instagram',  'pxaas-add-ons' ),
        'vk' => __( 'Vkontakte',  'pxaas-add-ons' ),
        'reddit' => __( 'Reddit',  'pxaas-add-ons' ),
        'pinterest' => __( 'Pinterest',  'pxaas-add-ons' ),
        'vine' => __( 'Vine Camera',  'pxaas-add-ons' ),
        'tumblr' => __( 'Tumblr',  'pxaas-add-ons' ),
        'flickr' => __( 'Flickr',  'pxaas-add-ons' ),
        'google-plus-g' => __( 'Google+',  'pxaas-add-ons' ),
        'linkedin' => __( 'LinkedIn',  'pxaas-add-ons' ),
        'whatsapp' => __( 'Whatsapp',  'pxaas-add-ons' ),
        'meetup' => __( 'Meetup',  'pxaas-add-ons' ),
        'custom_icon' => __( 'Custom',  'pxaas-add-ons' ),
    );

    return $socials ;

}  

// facebook login
// https://www.codexworld.com/login-with-facebook-using-php/
// https://stackoverflow.com/questions/12069703/facebook-login-for-wordpress-without-a-plugin
// https://developers.facebook.com/docs/php/howto/example_facebook_login
// https://developers.facebook.com/docs/facebook-login/web#logindialog 


function pxaas_addons_the_excerpt_max_charlength($charlength = 150, $echo = true) {
    $excerpt = get_the_excerpt();
    $charlength++;

    $return = $excerpt;

    if ( mb_strlen( $excerpt ) > $charlength ) {
        $subex = mb_substr( $excerpt, 0, $charlength - 5 );
        $exwords = explode( ' ', $subex );
        $excut = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
        if ( $excut < 0 ) {
            $return = mb_substr( $subex, 0, $excut );
        } else {
            $return = $subex;
        }
        $return .= esc_html__( '...', 'pxaas-add-ons' );
    }
    if(!$echo) return $return;
    else echo $return;
}


/**
 * Pagination for custom query page
 *
 * @since PXaas 1.0
 */
if (!function_exists('pxaas_addons_custom_pagination')) {
    function pxaas_addons_custom_pagination($pages = '',  $range = 2, $current_query = '') {
        // var_dump($pages);die;
        $showitems = ($range * 2) + 1;
        
        if ($current_query == '') {
            global $paged;
            if (empty($paged)) $paged = 1;
        } 
        else {
            $paged = $current_query->query_vars['paged'];
        }
        
        if ($pages == '') {
            if ($current_query == '') {
                global $wp_query;
                $pages = $wp_query->max_num_pages;
                if (!$pages) {
                    $pages = 1;
                }
            } 
            else {
                $pages = $current_query->max_num_pages;
            }
        }
        // <nav class="navigation pagination custom-pagination" role="navigation">
        //<h2 class="screen-reader-text">'.__( 'Posts navigation',  'pxaas-add-ons' ).'</h2>
        if (1 < $pages) {
            echo '<span class="section-separator"></span>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="nav-links pager-wrapper prs-blog-pagi-wrapper">
                    <ul class="pagination">';

                    // if ($paged > 0) 
                        echo '<li><a href="' . get_pagenum_link($paged - 1) . '" class="prev-page-numbers">'.__('prev','pxaas-add-ons').'</a></li>';
                    
                    for ($i = 1; $i <= $pages; $i++) {
                        if (1 != $pages && (!($i >= $paged + $range + 1 || $i <= $paged - $range - 1) || $pages <= $showitems)) {
                            echo ($paged == $i) ? '<li class="btc_third_pegi btc_shop_pagi"><a>' . $i . "<span></span></a></li>" : "<li><a href='" . get_pagenum_link($i) . "' class='page-numbers'>" . $i . "</a></li>";
                        }
                    }

                    // if ($paged < $pages) 
                        echo '<li><a href="' . get_pagenum_link($paged + 1) . '" class="next-page-numbers">'.__('next','pxaas-add-ons').'</a></li>';
                echo'</ul>
                </div>
        </div>';
        }

    }
}


function pxaas_addons_get_contact_form7_forms(){
    $forms = get_posts( 'post_type=wpcf7_contact_form&posts_per_page=-1' );

    $results = array();
    if ( $forms ) {
        $results[] = __( 'Select A Form', 'pxaas-add-ons' );
        foreach ( $forms as $form ) {
            $results[ $form->ID ] = $form->post_title;
        }
        // array_unshift( $results, __( 'Select A Form', 'pxaas-add-ons' ) );
        // $results[] = __( 'Select A Form', 'pxaas-add-ons' );
    } else {
        $results[] =  __( 'No contact forms found', 'pxaas-add-ons' ) ;
    }

    return $results;
}
// echo socials share content
function pxaas_addons_echo_socials_share(){
    $widgets_share_names = pxaas_addons_get_option('widgets_share_names','facebook, pinterest, googleplus, twitter, linkedin');
    if($widgets_share_names !=''):
    ?>
    <div class="share-holder hid-share mb-0px mt-20px">
        <div class="share-container isShare" data-share="<?php echo esc_attr( $widgets_share_names ); ?>">
            <span class="d-inline-block mr-10px"><?php esc_html_e( 'Share: ', 'pxaas-add-ons' ) ?></span>
        </div>
    </div>
    <?php
    endif;  
}


function pxaas_addons_get_price_formated($price = 0, $show_currency = true){
    if($price == '') $price = 0;
    $return = number_format( (float)$price, pxaas_addons_get_option('decimals','2'), pxaas_addons_get_option('decimal_sep','.'), pxaas_addons_get_option('thousand_sep',',') );
    if($show_currency){
        $currency = pxaas_addons_get_option('currency_symbol','$');
        $currency_pos = pxaas_addons_get_option('currency_pos','left_space');
        switch ($currency_pos) {
            case 'left':
                $return = $currency .$return;
                break;
            case 'right':
                $return .= $currency;
                break;
            case 'right_space':
                $return .= '&nbsp;'. $currency;
                break;
            default:
                $return = $currency . '&nbsp;'. $return;
                break;
        }
        
    }

    return $return;
}

function pxaas_addons_get_currency_array(){
    $world_curr = array (
        'ALL' => 'Albania Lek',
        'AFN' => 'Afghanistan Afghani',
        'ARS' => 'Argentina Peso',
        'AWG' => 'Aruba Guilder',
        'AUD' => 'Australia Dollar',
        'AZN' => 'Azerbaijan New Manat',
        'BSD' => 'Bahamas Dollar',
        'BBD' => 'Barbados Dollar',
        'BDT' => 'Bangladeshi taka',
        'BYR' => 'Belarus Ruble',
        'BZD' => 'Belize Dollar',
        'BMD' => 'Bermuda Dollar',
        'BOB' => 'Bolivia Boliviano',
        'BAM' => 'Bosnia and Herzegovina Convertible Marka',
        'BWP' => 'Botswana Pula',
        'BGN' => 'Bulgaria Lev',
        'BRL' => 'Brazil Real',
        'BND' => 'Brunei Darussalam Dollar',
        'KHR' => 'Cambodia Riel',
        'CAD' => 'Canada Dollar',
        'KYD' => 'Cayman Islands Dollar',
        'CLP' => 'Chile Peso',
        'CNY' => 'China Yuan Renminbi',
        'COP' => 'Colombia Peso',
        'CRC' => 'Costa Rica Colon',
        'HRK' => 'Croatia Kuna',
        'CUP' => 'Cuba Peso',
        'CZK' => 'Czech Republic Koruna',
        'DKK' => 'Denmark Krone',
        'DOP' => 'Dominican Republic Peso',
        'XCD' => 'East Caribbean Dollar',
        'EGP' => 'Egypt Pound',
        'SVC' => 'El Salvador Colon',
        'EEK' => 'Estonia Kroon',
        'EUR' => 'Euro Member Countries',
        'FKP' => 'Falkland Islands (Malvinas) Pound',
        'FJD' => 'Fiji Dollar',
        'GHC' => 'Ghana Cedis',
        'GIP' => 'Gibraltar Pound',
        'GTQ' => 'Guatemala Quetzal',
        'GGP' => 'Guernsey Pound',
        'GYD' => 'Guyana Dollar',
        'HNL' => 'Honduras Lempira',
        'HKD' => 'Hong Kong Dollar',
        'HUF' => 'Hungary Forint',
        'ISK' => 'Iceland Krona',
        'INR' => 'India Rupee',
        'IDR' => 'Indonesia Rupiah',
        'IRR' => 'Iran Rial',
        'IMP' => 'Isle of Man Pound',
        'ILS' => 'Israel Shekel',
        'JMD' => 'Jamaica Dollar',
        'JPY' => 'Japan Yen',
        'JEP' => 'Jersey Pound',
        'KZT' => 'Kazakhstan Tenge',
        'KPW' => 'Korea (North) Won',
        'KRW' => 'Korea (South) Won',
        'KGS' => 'Kyrgyzstan Som',
        'LAK' => 'Laos Kip',
        'LVL' => 'Latvia Lat',
        'LBP' => 'Lebanon Pound',
        'LRD' => 'Liberia Dollar',
        'LTL' => 'Lithuania Litas',
        'MKD' => 'Macedonia Denar',
        'MYR' => 'Malaysia Ringgit',
        'MUR' => 'Mauritius Rupee',
        'MXN' => 'Mexico Peso',
        'MNT' => 'Mongolia Tughrik',
        'MZN' => 'Mozambique Metical',
        'NAD' => 'Namibia Dollar',
        'NPR' => 'Nepal Rupee',
        'ANG' => 'Netherlands Antilles Guilder',
        'NZD' => 'New Zealand Dollar',
        'NIO' => 'Nicaragua Cordoba',
        'NGN' => 'Nigeria Naira',
        'NOK' => 'Norway Krone',
        'OMR' => 'Oman Rial',
        'PKR' => 'Pakistan Rupee',
        'PAB' => 'Panama Balboa',
        'PYG' => 'Paraguay Guarani',
        'PEN' => 'Peru Nuevo Sol',
        'PHP' => 'Philippines Peso',
        'PLN' => 'Poland Zloty',
        'QAR' => 'Qatar Riyal',
        'RON' => 'Romania New Leu',
        'RUB' => 'Russia Ruble',
        'SHP' => 'Saint Helena Pound',
        'SAR' => 'Saudi Arabia Riyal',
        'RSD' => 'Serbia Dinar',
        'SCR' => 'Seychelles Rupee',
        'SGD' => 'Singapore Dollar',
        'SBD' => 'Solomon Islands Dollar',
        'SOS' => 'Somalia Shilling',
        'ZAR' => 'South Africa Rand',
        'LKR' => 'Sri Lanka Rupee',
        'SEK' => 'Sweden Krona',
        'CHF' => 'Switzerland Franc',
        'SRD' => 'Suriname Dollar',
        'SYP' => 'Syria Pound',
        'TWD' => 'Taiwan New Dollar',
        'THB' => 'Thailand Baht',
        'TTD' => 'Trinidad and Tobago Dollar',
        'TRY' => 'Turkey Lira',
        'TRL' => 'Turkey Lira',
        'TVD' => 'Tuvalu Dollar',
        'UAH' => 'Ukraine Hryvna',
        'GBP' => 'United Kingdom Pound',
        'UGX' => 'Uganda Shilling',
        'USD' => 'United States Dollar',
        'UYU' => 'Uruguay Peso',
        'UZS' => 'Uzbekistan Som',
        'VEF' => 'Venezuela Bolivar',
        'VND' => 'Viet Nam Dong',
        'YER' => 'Yemen Rial',
        'ZWD' => 'Zimbabwe Dollar',
        'CFA' => 'CFA Franc', 
        'KSH' => 'Kenya shillings',
        'AED' => 'United Arab Emirates',
    );
    $paypal_curr = array(
        "USD" => "US Dollars ($) - Paypal acceptable", 
        "EUR" => "Euros (€) - Paypal acceptable",
        "GBP" => "Pounds Sterling (£) - Paypal acceptable",
        "AUD" => "Australian Dollars ($) - Paypal acceptable",
        "BRL" => "Brazilian Real (R$) - Paypal acceptable",
        "CAD" => "Canadian Dollars ($) - Paypal acceptable",
        "CZK" => "Czech Koruna - Paypal acceptable",
        "DKK" => "Danish Krone - Paypal acceptable",
        "HKD" => "Hong Kong Dollar ($) - Paypal acceptable",
        "HUF" => "Hungarian Forint - Paypal acceptable",
        "ILS" => "Israeli Shekel (₪) - Paypal acceptable",
        "JPY" => "Japanese Yen (¥) - Paypal acceptable",
        "MYR" => "Malaysian Ringgits - Paypal acceptable",
        "MXN" => "Mexican Peso ($) - Paypal acceptable",
        "NZD" => "New Zealand Dollar ($) - Paypal acceptable",
        "NOK" => "Norwegian Krone - Paypal acceptable",
        "PHP" => "Philippine Pesos - Paypal acceptable",
        "PLN" => "Polish Zloty - Paypal acceptable",
        "SGD" => "Singapore Dollar ($) - Paypal acceptable",
        "SEK" => "Swedish Krona - Paypal acceptable",
        "CHF" => "Swiss Franc - Paypal acceptable",
        "TWD" => "Taiwan New Dollars - Paypal acceptable",
        "THB" => "Thai Baht (฿) - Paypal acceptable",
        "INR" => "Indian Rupee (₹) - Paypal acceptable",
        "TRY" => "Turkish Lira (₺) - Paypal acceptable",
        "RIAL" => "Iranian Rial (﷼) - Paypal acceptable",
        "RUB" => "Russian Rubles - Paypal acceptable",

    );

    return array_merge($world_curr, $paypal_curr);
}


function pxaas_addons_extract_iconmonstr(){
    $content =file_get_contents(PXAAS_ADD_ONS_DIR.'assets/css/icon-fonts.css');
    $re = '/\.(im-([\w-]+))/m';
    preg_match_all($re, $content, $matches, PREG_SET_ORDER, 0);
    // var_dump($matches);
    $icons = array();
    if($matches){
        foreach ($matches as $match) {
            $icons[] = array($match[1] => str_replace(array('-'), array(' '), $match[2]) );
        }
    }
    return $icons;
}
function pxaas_addons_extract_etline(){
    $content =file_get_contents(PXAAS_ADD_ONS_DIR.'assets/css/icon-fonts.css');
    $re = '/\.(icon-([\w-]+))/m';
    preg_match_all($re, $content, $matches, PREG_SET_ORDER, 0);
    // var_dump($matches);
    $icons = array();
    if($matches){
        foreach ($matches as $match) {
            $icons[] = array($match[1] => str_replace(array('-'), array(' '), $match[2]) );
        }
    }
    return $icons;
}

function pxaas_addons_get_icon_iconmonstr_select2() {
    $icons = pxaas_addons_extract_iconmonstr();
    $icon_options = array();
    foreach ($icons as $icon) {
        // php 7.3
        // $icon_options['im '.array_key_first($icon)] = reset( $icon );
        $icotitle = reset( $icon );
        $icon_options['im '.key($icon)] = $icotitle;
    }
    return $icon_options;
}

function pxaas_addons_get_icon_et_line_select2() {
    $icons = pxaas_addons_extract_etline();
    $icon_options = array();
    foreach ($icons as $icon) {
        // php 7.3
        // $icon_options[array_key_first($icon)] = reset( $icon );
        $icotitle = reset( $icon );
        $icon_options[key($icon)] = $icotitle;
    }
    return $icon_options;
}

function pxaas_addons_get_animation() {
    $animation = array (
        ''                      => __( 'None', 'pxaas-add-ons' ),
        'type1'                 => __( 'FADING', 'pxaas-add-ons' ),
        'wow fadeIn'            => __( '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Fade In', 'pxaas-add-ons' ),
        'wow fadeInDown'        => __( '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Fade In Down', 'pxaas-add-ons' ),
        'wow fadeInLeft'        => __( '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Fade In Left', 'pxaas-add-ons' ),
        'wow fadeInRight'       => __( '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Fade In Right', 'pxaas-add-ons' ),
        'wow fadeInUp '         => __( '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Fade In Up', 'pxaas-add-ons' ),
        'type2'                 => __( 'ZOOMING', 'pxaas-add-ons' ),
    ); 
    return $animation;
}

// for subscription plan
function pxaas_add_ons_get_subscription_duration_units($unit = ''){
    $duration_units = array(
        // 'hour'          => esc_html__( 'Hour', 'pxaas-add-ons' ),
        'day'           => esc_html__( 'Days', 'pxaas-add-ons' ),
        'week'          => esc_html__( 'Weeks', 'pxaas-add-ons' ),
        'month'         => esc_html__( 'Months', 'pxaas-add-ons' ),
        'year'          => esc_html__( 'Years', 'pxaas-add-ons' ),
    );
    if( !empty($unit) && isset( $duration_units[$unit] ) ) return $duration_units[$unit];

    return $duration_units;
}

function pxaas_add_ons_get_plan_period_text($interval = 1, $period = 'month'){
    $period_texts = array(
        'hour'          => esc_html__( 'hour', 'pxaas-add-ons' ),
        'day'           => esc_html__( 'day', 'pxaas-add-ons' ),
        'week'          => esc_html__( 'week', 'pxaas-add-ons' ),
        'month'         => esc_html__( 'month', 'pxaas-add-ons' ),
        'year'          => esc_html__( 'year', 'pxaas-add-ons' ),
    );
    if($interval){
        $formatted_period = $period_texts[$period];
        if($interval > 1) $formatted_period = sprintf(__( '%d %ss', 'pxaas-add-ons' ), $interval, $period_texts[$period] );
        return sprintf( __( '<span class="period-per"> / </span> %s', 'pxaas-add-ons' ), $formatted_period);
    }

    return __( '', 'pxaas-add-ons' );

    // $formatted_period = _n( $period_texts[$period], '%s '.$period_texts[$period], $interval, 'pxaas-add-ons' );
}



function pxaas_addons_modify_query($query) {
    if ( ! is_admin() && $query->is_main_query() ) {
        if ( is_post_type_archive('cth_project') || is_tax('cth_project_cat') || 'cth_project' == $query->get('post_type') ) {
            $query->set('posts_per_page', pxaas_addons_get_option('project_count'));
            $query->set('orderby', pxaas_addons_get_option('project_orderby'));
            $query->set('order', pxaas_addons_get_option('project_order'));

            // for additional search
            // $query->set('suppress_filters', false);
            // $query->set('cthqueryid', 'main-project');
        }
        
    }
}

add_action( 'pre_get_posts', 'pxaas_addons_modify_query' );

