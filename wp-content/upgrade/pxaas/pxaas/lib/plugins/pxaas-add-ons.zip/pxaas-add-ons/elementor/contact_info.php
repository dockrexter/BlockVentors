<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Contact_info extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'contact_info';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Contact Information', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'address_content',
            [
                'label' => __( 'Infos', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'contact_infos',
            [
                'label' => __( ' Content', 'pxaas-add-ons' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [
                        'icon' => 'icon-phone',
                        'title' => 'Phone',
                        'value' => '+(07) 012345678',
                    ],
                    [
                        'icon' => 'icon-map',
                        'title' => 'Address',
                        'value' => '78 st Merrick Boulevard, New York',
                    ],
                    [
                        'icon' => 'icon-envelope',
                        'title' => 'Mail',
                        'value' => 'support@info.com',
                    ],
                ],
                'fields' => [
                    [
                        'name'  => 'icon',
                        'label' => __( 'Icon - Et-line', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::SELECT2,
                        'options' => pxaas_addons_get_icon_et_line_select2(),
                        'default' => '',
                        'label_block' => false,
                    ],
                    [
                        'name'  => 'title',
                        'label' => __( 'Title', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => 'Phone',
                    ],
                    [
                        'name' => 'value',
                        'label'     => __( 'Content', 'pxaas-add-ons' ),
                        'type'      => Controls_Manager::TEXTAREA, // WYSIWYG,
                        'default'   => '+(07) 012345678',
                        // 'show_label' => false,
                    ],
                ],
            'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();

    }

    protected function render( ) {
        $settings = $this->get_settings();
        if(empty($settings['contact_infos'])) return;
        ?>
        <div class="contact-area contact-area-<?php echo count($settings['contact_infos']);?>">
        <?php foreach ($settings['contact_infos'] as $key => $info) { ?>
                
            <div class="contact-area-item address mb-50px"> 
            <?php if($info['icon'] !== ''): ?>  
                <i class="<?php echo $info['icon']; ?> color-blue bg-gray radius-50 fs-25 mb-15px text-center transition-3"></i>
                <?php endif; ?>
                <h5 class="mb-5px ctinfo-title"><?php echo $info['title']; ?></h5>
                <div class="contact-info"><?php echo $info['value']; ?></div>         
            </div>
        <?php } ?>
        </div>
        <?php

    }

    // protected function _content_template() {
    //     
    //     <?php

    // }  

}

// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

