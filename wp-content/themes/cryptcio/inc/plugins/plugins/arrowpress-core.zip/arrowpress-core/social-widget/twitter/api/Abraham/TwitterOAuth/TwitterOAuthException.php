<?php
class TwitterOAuthException extends \Exception
{
}
