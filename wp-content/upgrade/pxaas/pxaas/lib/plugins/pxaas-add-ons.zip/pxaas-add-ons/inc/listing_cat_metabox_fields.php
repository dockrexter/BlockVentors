<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



//For portfolio_cat taxonomy
//https://make.wordpress.org/core/2015/09/04/taxonomy-term-metadata-proposal/
// Add term page
function pxaas_addons_listing_cat_add_new_meta_field() {
    
    // this will add the custom meta field to the add new term page
    wp_enqueue_media();
    wp_enqueue_script('pxaas_tax_meta', PXAAS_ADD_ONS_DIR_URL . 'inc/assets/upload_file.js', array('jquery'), null, true);
    // wp_enqueue_script('select2', PXAAS_ADD_ONS_DIR_URL . 'assets/js/select2.min.js', array('jquery'), null, true);
    // wp_enqueue_script('pxaas_tax_repeat', PXAAS_ADD_ONS_DIR_URL . 'inc/assets/repeat_fields.js', array('jquery','jquery-ui-sortable'), null, true);
    
    // pxaas_features_select_field(array(
    //                             'id'=>'features',
    //                             'name'=>esc_html__('Available Features','pxaas-add-ons'),
    //                             'values' => array(
    //                                 'yes'=> esc_html__('Yes','pxaas-add-ons'),
    //                                 'no'=> esc_html__('No','pxaas-add-ons'),
    //                             ),
    //                             'required' => false,
    //                             'default'=>'yes'
    // ));

    // pxaas_repeat_fields_options_field(array(
    //                             'id'=>'add-features',
    //                             'name'=>esc_html__('Additional Features','pxaas-add-ons'),
    //                             'values' => array(
    //                                 'yes'=> esc_html__('Yes','pxaas-add-ons'),
    //                                 'no'=> esc_html__('No','pxaas-add-ons'),
    //                             ),
    //                             'required' => false,
    //                             'default'=>'yes'
    // ));


    // pxaas_radio_options_field(array(
    //                             'id'=>'tax_show_header',
    //                             'name'=>esc_html__('Show Header Section','pxaas-add-ons'),
    //                             'values' => array(
    //                                     'yes'=> esc_html__('Yes','pxaas-add-ons'),
    //                                     'no'=> esc_html__('No','pxaas-add-ons'),
    //                                 ),
    //                             'default'=>'yes'
    // ));
    pxaas_select_media_file_field('featured_img',esc_html__('Featured Image','pxaas-add-ons'), array());

}
add_action('listing_cat_add_form_fields', 'pxaas_addons_listing_cat_add_new_meta_field', 10, 2);

// Edit term page
function pxaas_addons_listing_cat_edit_meta_field($term) {
    wp_enqueue_style( 'font-awesome', PXAAS_ADD_ONS_DIR_URL . 'inc/assets/font-awesome/font-awesome.min.css');
    wp_enqueue_style( 'cth-backend', PXAAS_ADD_ONS_DIR_URL . 'inc/assets/backend.css');
    wp_enqueue_media();
    wp_enqueue_script('pxaas_tax_meta', PXAAS_ADD_ONS_DIR_URL . 'inc/assets/upload_file.js', array('jquery'), null, true);
    wp_enqueue_script('select2', PXAAS_ADD_ONS_DIR_URL . 'assets/js/select2.min.js', array('jquery'), null, true);
    wp_enqueue_script('pxaas_tax_repeat', PXAAS_ADD_ONS_DIR_URL . 'inc/assets/repeat_fields.js', array('jquery','jquery-ui-sortable'), null, true);
    
    // put the term ID into a variable
    // $t_id = $term->term_id;

    $term_meta = get_term_meta( $term->term_id, '_cth_term_meta', true );
    
    // retrieve the existing value(s) for this meta field. This returns an array
    // $term_meta = get_option("_cth_tax_listing_cat_$t_id");

    pxaas_features_select_field(array(
                                'id'=>'features',
                                'name'=>esc_html__('Available Features','pxaas-add-ons'),
                                'values' => array(
                                    'yes'=> esc_html__('Yes','pxaas-add-ons'),
                                    'no'=> esc_html__('No','pxaas-add-ons'),
                                ),
                                'required' => false,
                                'default'=>'yes'
    ),$term_meta,false);

    pxaas_repeat_fields_options_field(array(
                                'id'=>'add-features',
                                'name'=>esc_html__('Additional Features','pxaas-add-ons'),
                                'values' => array(
                                    'yes'=> esc_html__('Yes','pxaas-add-ons'),
                                    'no'=> esc_html__('No','pxaas-add-ons'),
                                ),
                                'required' => false,
                                'default'=>'yes'
    ),$term_meta,false);

    pxaas_addons_content_widgets_order_options_field(array(
                                'id'=>'content-widgets-order',
                                'name'=>esc_html__('Content Widgets Order','pxaas-add-ons'),
                                'values' => array(
                                    'speaker'=> esc_html__('Speaker Widget','pxaas-add-ons'),
                                    'promo_video'=> esc_html__('Promo Video','pxaas-add-ons'),
                                    'content'=> esc_html__('Content Widget','pxaas-add-ons'),
                                    'gallery'=> esc_html__('Gallery Widget','pxaas-add-ons'),
                                    'slider'=> esc_html__('Slider Widget','pxaas-add-ons'),
                                    'faqs'=> esc_html__('FAQs Widget','pxaas-add-ons'),
                                    
                                ),
                                'required' => false,
                                'default'=>array('promo_video','content','gallery','slider','faqs','speaker'),

                                'id_2'=>'sidebar-widgets-order',
                                'values_2' => array(
                                    'wkhour'=> esc_html__('Working Hour Widget','pxaas-add-ons'),
                                    'countdown'=> esc_html__('Countdown','pxaas-add-ons'),
                                    'addfeas' => esc_html__('Additional Features','pxaas-add-ons'),
                                    'booking'=> esc_html__('Booking Widget','pxaas-add-ons'),
                                    'contacts'=> esc_html__('Contacts Widget','pxaas-add-ons'),
                                    'author'=> esc_html__('Author Widget','pxaas-add-ons'),
                                    'moreauthor'=> esc_html__('More From Author Widget','pxaas-add-ons'),
                                    
                                ),
                                'default_2'=>array('wkhour','countdown','booking','contacts','author','moreauthor')
    ),$term_meta,false);


    
    pxaas_radio_options_field(array(
                                'id'=>'tax_show_header',
                                'name'=>esc_html__('Show Header Section','pxaas-add-ons'),
                                'values' => array(
                                        'yes'=> esc_html__('Yes','pxaas-add-ons'),
                                        'no'=> esc_html__('No','pxaas-add-ons'),
                                    ),

                                'default'=>'yes'
    ),$term_meta,false);

    pxaas_addons_icon_select_field(array(
                                'id'=>'icon_class',
                                'name'=>esc_html__('Icon','pxaas-add-ons'),
                                // 'values' => array(
                                //         'yes'=> esc_html__('Yes','pxaas-add-ons'),
                                //         'no'=> esc_html__('No','pxaas-add-ons'),
                                //     ),

                                'default'=>'fa fa-cutlery'
    ),$term_meta,false);

    pxaas_select_media_file_field('featured_img',esc_html__('Featured Image','pxaas-add-ons'), $term_meta,false);
}
add_action('listing_cat_edit_form_fields', 'pxaas_addons_listing_cat_edit_meta_field', 10, 2);

// Save extra taxonomy fields callback function.
function pxaas_addons_save_listing_cat_custom_meta($term_id) {
    if (isset($_POST['term_meta'])) {
        $term_meta = get_term_meta( $term_id, '_cth_term_meta', true );
        if(!$term_meta||!is_array($term_meta)) $term_meta = array();
        $cat_keys = array_keys($_POST['term_meta']);
        foreach ($cat_keys as $key) {
            if (isset($_POST['term_meta'][$key])) {
                $term_meta[$key] = $_POST['term_meta'][$key];
            }
        }
        
        // Save the option array.
        update_term_meta($term_id, '_cth_term_meta', $term_meta);

    }
}
add_action('create_listing_cat', 'pxaas_addons_save_listing_cat_custom_meta', 10, 2);
add_action('edited_listing_cat', 'pxaas_addons_save_listing_cat_custom_meta', 10, 2);
