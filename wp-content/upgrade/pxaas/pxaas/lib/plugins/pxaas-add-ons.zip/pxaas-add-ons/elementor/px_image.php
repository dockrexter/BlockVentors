<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Px_Image extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'px_image';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'PXaas Image', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'image',
                [
                    'label' => __( 'Choose Image', 'pxaas-add-ons' ),
                    'type' => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ]
        );
        $this->add_control(
            'show_btn_video',
            [
                'label' => __( 'Show video button', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'link_video',
            [
                'label' => __( 'URL Video', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'condition' => [
                    'show_btn_video' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'show_title_image',
            [
                'label' => __( 'Show Image Title', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Demo',
                'condition' => [
                    'show_title_image' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'link',
            [
                'label' => __( 'URL', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'condition' => [
                    'show_title_image' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'show_title_new',
            [
                'label' => __( 'Used when it is a new product.', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => [
                    'show_title_image' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'title_new',
            [
                'label' => __( 'Title', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'New',
                'condition' => [
                    'show_title_new' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'is_external',
            [
                'label' => __( 'Is External Links', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => [
                    'show_title_image' => 'yes',
                ],
            ]
        );


        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $image = $settings['image'];
        $title = $settings['title'];
        $link = $settings['link'];
        $link_video = $settings['link_video'];
        $target = $settings['is_external'] == 'yes'? ' target="_blank"':'';

        $css_wrap = "mt-25px mb-25px";
        $css_img = "";
        if($settings['show_btn_video'] === 'yes') {
            $css_wrap .= " p-relative img-video";
            $css_img .= "m-auto d-block radius-10px";
        }
        if($settings['show_title_image'] === 'yes') {
            $css_wrap .= " img-show-title";
            $css_img .= "transition-3";
        }
        if($settings['show_btn_video'] === 'yes' && $settings['show_title_image'] === 'yes') {
            $css_wrap .= " p-relative img-show-title-video";
            $css_img .= "m-auto d-block radius-10px transition-3";
        }

        ?>
        <div class="<?php echo $css_wrap; ?>">
            <?php if($settings['show_btn_video'] === 'yes'): ?>
                <img class="<?php echo $css_img; ?>" src="<?php if($image['url']!= '') echo $image['url']; ?>" alt="">
            <?php else: ?>
                <a class="px-image-link" href="<?php if($link['url'] != '') echo $link['url']; ?>" <?php echo $target; ?>>
                    <img class="<?php echo $css_img; ?>" src="<?php if($image['url']!= '') echo $image['url']; ?>" alt="">
                </a>
            <?php endif; ?>
            
            <?php if($settings['show_btn_video'] === 'yes'): ?>
                <a class="play-trigger p-absolute fs-30 pl-5px color-fff bg-green bg-fff-hvr color-green-hvr radius-50 text-center transition-2" href="<?php if($link_video['url']!= '') echo $link_video['url']; ?>" <?php echo $target; ?> data-lity=""><i class="fa fa-play"></i></a>
            <?php endif ?>
            <?php if($settings['show_title_image'] === 'yes'): ?>
                <a class="color-333 color-orange-hvr mt-25px d-block" href="<?php if($link['url']!= '') echo $link['url']; ?>" <?php echo $target; ?>>
                    <h6 class="fw-400"><?php echo $title; ?>
                        <?php if($settings['show_title_new'] === 'yes'): ?>
                            <span class="color-fff bg-blue p-5px radius-50px ml-5px"><?php echo $settings['title_new']; ?></span>
                        <?php endif; ?>
                    </h6>
                </a>
            <?php endif; ?>
        </div>
        <?php

    }
   

}


// "widgetType":"image"
// "widgetType":"button"
// "widgetType":"counter"

