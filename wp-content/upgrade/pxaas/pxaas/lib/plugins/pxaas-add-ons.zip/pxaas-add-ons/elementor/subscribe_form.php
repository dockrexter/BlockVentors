<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Subscribe_Form extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'subscribe_form';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Subscribe Form', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'btn_color',
            [
                'label'       => __( 'Button Color', 'pxaas-add-ons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => '1',
                'options'     => [
                    '1'  => __( 'Color - 1', 'pxaas-add-ons' ),
                    '2'  => __( 'Color - 2', 'pxaas-add-ons' ),
                    '3'  => __( 'Color - 3', 'pxaas-add-ons' ),
                ],
            ]
        );   

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();

        $css_color = "";
        if ($settings['btn_color'] === '1') {
            $css_color .= "btn-bg-blue";
        }
        if ($settings['btn_color'] === '2') {
            $css_color .= "btn-bg-orange";
        }
        if ($settings['btn_color'] === '3') {
            $css_color .= "btn-bg-green";
        }
        ?>
        
        <div class="subscribe <?php echo $css_color; ?>">
            <?php echo do_shortcode('[pxaas_subscribe]'); ?>
        </div>
        <?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

    // }

   
   

}

// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

