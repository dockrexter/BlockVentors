<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */

  

/* tweet feeds widget action */
add_action('wp_ajax_nopriv_pxaas_get_tweets', 'pxaas_add_ons_get_tweets_callback');
add_action('wp_ajax_pxaas_get_tweets', 'pxaas_add_ons_get_tweets_callback');

require_once( PXAAS_ADD_ONS_DIR . "inc/twitter-api/twitteroauth/twitteroauth.php"); 
/**
 * Gets connection with user Twitter account
 * @param  String $cons_key     Consumer Key
 * @param  String $cons_secret  Consumer Secret Key
 * @param  String $oauth_token  Access Token
 * @param  String $oauth_secret Access Secrete Token
 * @return Object               Twitter Session
 */
function pxaas_add_ons_getConnectionWithToken($cons_key, $cons_secret, $oauth_token, $oauth_secret)
{
    $connection = new TwitterOAuth($cons_key, $cons_secret, $oauth_token, $oauth_secret);
  
    return $connection;
}

function pxaas_add_ons_get_tweets_callback(){

    
    // Cache Settings
    define('CACHE_ENABLED', false);
    define('CACHE_LIFETIME', 3600); // in seconds
    define('HASH_SALT', md5(PXAAS_ADD_ONS_DIR."inc/twitter-api/"));

    $consumer_key = pxaas_addons_get_option('consumer_key');
    $consumer_secret = pxaas_addons_get_option('consumer_secret');
    $access_token = pxaas_addons_get_option('access_token');
    $access_token_secret = pxaas_addons_get_option('access_token_secret');

    // Check if keys are in place
    if ($consumer_key == '' || $consumer_secret == '' || $access_token == '' || $access_token_secret == '') {
        wp_send_json( esc_html__( 'You need a consumer key and secret keys. Get one from','pxaas-add-ons' ).'<a href="'.esc_url('https://apps.twitter.com/' ).'" target="_blank">apps.twitter.com</a>' ) ;
    }

    // If count of tweets is not fall back to default setting
    $username = filter_input(INPUT_GET, 'username', FILTER_SANITIZE_SPECIAL_CHARS);
    $number = filter_input(INPUT_GET, 'count', FILTER_SANITIZE_NUMBER_INT);
    $exclude_replies = filter_input(INPUT_GET, 'exclude_replies', FILTER_SANITIZE_SPECIAL_CHARS);
    $list_slug = filter_input(INPUT_GET, 'list', FILTER_SANITIZE_SPECIAL_CHARS);
    $hashtag = filter_input(INPUT_GET, 'hashtag', FILTER_SANITIZE_SPECIAL_CHARS);
    
    
    // Connect
    $connection = pxaas_add_ons_getConnectionWithToken($consumer_key, $consumer_secret, $access_token, $access_token_secret);
    
    // Get Tweets
    if (!empty($list_slug)) {
      $params = array(
          'owner_screen_name' => $username,
          'slug' => $list_slug,
          'per_page' => $number
      );

      $url = '/lists/statuses';
    } else if($hashtag) {
      $params = array(
          'count' => $number,
          'q' => '#'.$hashtag
      );

      $url = '/search/tweets';
    } else {
      $params = array(
          'count' => $number,
          'exclude_replies' => $exclude_replies,
          'screen_name' => $username
      );

      $url = '/statuses/user_timeline';
    }

    $tweets = $connection->get($url, $params);

    wp_send_json($tweets);

}
add_action('wp_ajax_nopriv_pxaas_mailchimp', 'pxaas_mailchimp_subscribe_callback');
add_action('wp_ajax_pxaas_mailchimp', 'pxaas_mailchimp_subscribe_callback');

/*
 *  @desc   Register user
*/
require_once PXAAS_ADD_ONS_DIR .'inc/classes/Drewm/CTHMailChimp.php';
function pxaas_mailchimp_subscribe_callback() {
    $output = array(
        'success' => false,
        '_POST'     => $_POST
    );
    // $output['success'] = 'no';

    // var_dump($_POST);
    // wp_send_json( $output );
    if ( ! isset( $_POST['_nonce'] ) || ! wp_verify_nonce( $_POST['_nonce'], 'pxaas_mailchimp' ) ){
        $output['message'] = esc_html__('Sorry, your nonce did not verify.','pxaas-add-ons' );
        wp_send_json( $output );
    }
    if(isset($_POST['_list_id'])&& $_POST['_list_id']){
        $list_id = $_POST['_list_id'];
    }else{
        $list_id = pxaas_addons_get_option('mailchimp_list_id'); 
    }

    /*
     * ------------------------------------
     * Mailchimp Email Configuration
     * ------------------------------------
     */
    $MailChimp = new CTH_MailChimp( pxaas_addons_get_option('mailchimp_api') );

    $result = $MailChimp->post("lists/$list_id/members", array(
        'email_address' => $_POST['email'],
        'status'        => 'subscribed'
    ) );

    if ($MailChimp->success()) {
        $output['success'] = 'yes';
        $output['message'] = esc_html__('Almost finished. Please check your email and verify.','pxaas-add-ons' );
        $output['last_response'] = $MailChimp->getLastResponse();
    } else {
        $output['message'] = esc_html__('Oops. Something went wrong!','pxaas-add-ons' );
        $output['last_response'] = $MailChimp->getLastResponse();
    }

    wp_send_json( $output );
}


/* Login Ajax Action */
add_action( 'wp_ajax_nopriv_pxaas-login', 'pxaas_addons_login_callback' );
add_action( 'wp_ajax_pxaas-login', 'pxaas_addons_login_callback' );
/*
 *  @desc   Process theme login
 */
function pxaas_addons_login_callback() {

    $json = array(
        'success' => true,
        'data' => array(
            '_POST'=>$_POST
        )
    );

    // wp_send_json($json );

    $nonce = $_POST['_loginnonce'];
    // var_dump($_POST);
    // wp_send_json($json );
    
    if ( ! wp_verify_nonce( $nonce, 'pxaas-login' ) ){
        $json['success'] = false;
        $json['data']['login_err'] = esc_html__( 'Security checked!, Cheatn huh?', 'pxaas-add-ons' ) ;
        wp_send_json($json );
    }
    // https://codex.wordpress.org/Function_Reference/wp_signon
    // NOTE: If you don't provide $credentials, wp_signon uses the $_POST variable (the keys being "log", "pwd" and "rememberme").
    
    // set the WP login cookie
    $secure_cookie = is_ssl() ? true : false;
    $user = wp_signon( NULL, $secure_cookie );

    if ( is_wp_error($user) ) {
        $json['success'] = false;
        $json['data']['login_err'] = $user->get_error_message();
    } else {
        
        // $json['data']['pxaas_addons_do_wp_mail'] =  pxaas_addons_do_wp_mail( 'cththemes@gmail.com', 'User Login', 'There is an user login success');
        
        do_action( 'pxaas_addons_user_login' );
        pxaas_addons_auto_login_new_user( $user->ID );
        // wp_set_current_user( $user->ID );
        // wp_set_auth_cookie( $user->ID, true, $secure_cookie ); // This function does not return a value
        // do_action( 'wp_login', $user->user_login );
        $json['data']['userID'] = $user->ID;
        if( isset($_POST['redirection']) ) $json['data']['redirection'] =  esc_url($_POST['redirection']);
    }

    wp_send_json($json );
}


function pxaas_addons_wp_mail_from_name( $name ) {
    return pxaas_addons_get_option('emails_name')? pxaas_addons_get_option('emails_name'): $name;
}

function pxaas_addons_wp_mail_from( $email ) {
    return pxaas_addons_get_option('emails_email')? pxaas_addons_get_option('emails_email'): $email;
}
// string|array $to, string $subject, string $message, string|array $headers = '', string|array $attachments = array()
function pxaas_addons_do_wp_mail( $to, $subject='', $message='', $headers = array(), $attachments = array() ){

    // return 'dfdsfsdf';

    // $headers = array();
    if(pxaas_addons_get_option('emails_ctype') == 'html'){
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
    }
    //$headers[] = 'From: '. $sender_option.' ' . '<'.$sender_email_option.'>';
    add_filter( 'wp_mail_from_name', 'pxaas_addons_wp_mail_from_name' );
    add_filter('wp_mail_from', 'pxaas_addons_wp_mail_from');
    $headers[] = 'Reply-To: '. pxaas_addons_wp_mail_from_name(__( 'Sender Name', 'pxaas-add-ons' )) .' ' . '<'.pxaas_addons_wp_mail_from(__( 'senderemail@gmail.com', 'pxaas-add-ons' )).'>';

    $email_sent = wp_mail( $to, $subject , $message , $headers, $attachments );

    remove_filter( 'wp_mail_from_name', 'pxaas_addons_wp_mail_from_name' );
    remove_filter('wp_mail_from', 'pxaas_addons_wp_mail_from');

    return $email_sent;
}

// process email template
function pxaas_addons_process_email_template($email_template = '', $email_vars = array()){
    $email_vars = array_merge($email_vars,array('site_title' => get_bloginfo('name')));
    // get allow variables
    $allow_field_names = array_keys($email_vars);
    // extract variables, skip if existing
    extract($email_vars, EXTR_SKIP);

    if(preg_match_all("/{([\w-_]+)[^\w-_]*}/", $email_template, $matches) != FALSE){
        $fieldsPattern = array();//$matches[0];
        $fieldsReplace = array();
        foreach ($matches[1] as $key => $fn) {
            $fieldsPattern[] = "/{(".$fn.")[^\w-_]*}/";
            if( isset($$fn) && in_array($fn, $allow_field_names ) ){
                $fieldsReplace[] = $$fn;  //'['.$fn.']';
            }else{
                $fieldsReplace[] = '{'.$fn.'}';
            } 
        }
        $email_template = preg_replace($fieldsPattern, $fieldsReplace, $email_template);
    }
    return $email_template;
}

// add_action('wp_ajax_nopriv_cth_vc_images', 'pxaas_addons_cth_vc_images_callback');
add_action('wp_ajax_cth_vc_images', 'pxaas_addons_cth_vc_images_callback');
function pxaas_addons_cth_vc_images_callback() {
    $images = $_POST['images'];
    $html = $images;
    if($images != '') {
        $images = explode(",", $images);
        if(count($images)){
            $html = '';
            foreach ($images as $key => $img) {
                $html .= wp_get_attachment_image( $img, 'thumbnail', '', array('class'=>'cth-vc-img-thumb') );
            }
        }
    }
    wp_send_json($html);
}


add_action( 'login_form_login', 'pxaas_addons_redirect_to_custom_login' );
function pxaas_addons_redirect_to_custom_login() {
    if( pxaas_addons_get_option('custom_logreg_enable') == 'no' ) return;
    if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {
        $redirect_to = isset( $_REQUEST['redirect_to'] ) ? $_REQUEST['redirect_to'] : null;
     
        if ( is_user_logged_in() ) {
            pxaas_addons_redirect_logged_in_user( $redirect_to );
            exit;
        }
 
        // The rest are redirected to the login page
        $login_url = get_permalink( pxaas_addons_get_option('login_page') ); // home_url( 'member-login' );
        if ( ! empty( $redirect_to ) ) {
            $login_url = add_query_arg( 'redirect_to', $redirect_to, $login_url );
        }
 
        wp_safe_redirect( $login_url );
        exit;
    }
}
function pxaas_addons_redirect_logged_in_user( $redirect_to = null ) {
    $user = wp_get_current_user();
    if ( user_can( $user, 'manage_options' ) ) {
        if ( $redirect_to ) {
            wp_safe_redirect( $redirect_to );
        } else {
            wp_safe_redirect( admin_url() );
        }
    } else {
        wp_safe_redirect( home_url( '/' ) );
    }
}

add_filter( 'authenticate', 'pxaas_addons_maybe_redirect_at_authenticate' , 101, 3 );
function pxaas_addons_maybe_redirect_at_authenticate( $user, $username, $password ) {
    if( pxaas_addons_get_option('custom_logreg_enable') == 'no' ) return $user;
    // Check if the earlier authenticate filter (most likely, 
    // the default WordPress authentication) functions have found errors
    if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
        if ( is_wp_error( $user ) ) {
            $error_codes = join( ',', $user->get_error_codes() );
 
            $login_url = get_permalink( pxaas_addons_get_option('login_page') );
            $login_url = add_query_arg( 'login', $error_codes, $login_url );
 
            wp_safe_redirect( $login_url );
            exit;
        }
    }
 
    return $user;
}






add_action( 'login_form_register', 'pxaas_addons_redirect_to_custom_register' );
function pxaas_addons_redirect_to_custom_register() {
    if( pxaas_addons_get_option('custom_logreg_enable') == 'no' ) return;
    $register_page = get_permalink( pxaas_addons_get_option('register_page') );
    if ( $_SERVER['REQUEST_METHOD'] == 'GET') {
        if ( is_user_logged_in() ) {
            pxaas_addons_redirect_logged_in_user();
        } else {
            wp_safe_redirect( $register_page );
        }
        exit;
    }
}

function pxaas_addons_register_user( $email, $username, $password ) {
    $errors = new WP_Error();
    $password = $_POST['password'];
    $password_retype = $_POST['password_retype'];
    // Email address is used as both username and email. It is also the only
    // parameter we need to validate
    if ( ! is_email( $email ) ) {
        $errors->add( 'email', pxaas_addons_get_error_message( 'email' ) );
        return $errors;
    }
 
    if ( username_exists( $email ) || email_exists( $email ) ) {
        $errors->add( 'email_exists', pxaas_addons_get_error_message( 'email_exists') );
        return $errors;
    }

    if( $password !== $password_retype) {
        $errors->add( 'pass_coincide', pxaas_addons_get_error_message( 'pass_coincide') );
        return $errors;
    }
 
    // Generate the password so that the subscriber will have to check email...
    // $password = wp_generate_password( 12, false );
    if( $password === $password_retype ) {
        $user_data = array(
            'user_login'        => $username,
            'user_email'        => $email,
            'user_pass'         => $password,
            // 'user_pass_retype'  => $password_retype,
            // 'first_name'        => $first_name,
            // 'last_name'         => $last_name,
            // 'nickname'          => $first_name,
            // 'role'       => 'listing_author' //'subscriber'
        );
    }
        
 
    $user_id = wp_insert_user( $user_data );
    wp_new_user_notification( $user_id, null, 'both' );
    return $user_id;
}

add_action( 'login_form_register', 'pxaas_addons_do_register_user' );
function pxaas_addons_do_register_user() {
    if( pxaas_addons_get_option('custom_logreg_enable') == 'no' ) return;
    $register_page = get_permalink( pxaas_addons_get_option('register_page') );
    if ( 'POST' == $_SERVER['REQUEST_METHOD'] ) {
        $redirect_url = $register_page;
 
        if ( ! get_option( 'users_can_register' ) ) {
            // Registration closed, display error
            $redirect_url = add_query_arg( 'register-errors', 'closed', $redirect_url );
        } else {
            $nonce = $_POST['_regnonce'];
            // $email = $_POST['email'];
            $username = sanitize_text_field( $_POST['username'] );
            $email = sanitize_text_field( $_POST['email'] );
            $password = sanitize_text_field( $_POST['password'] );
            $password_retype = sanitize_text_field( $_POST['password_retype'] );
 
            $result = pxaas_addons_register_user( $email, $username, $password, $password_retype );
 
            if ( is_wp_error( $result ) ) {
                // Parse errors into a string and append as parameter to redirect
                $errors = join( ',', $result->get_error_codes() );
                $redirect_url = add_query_arg( 'register-errors', $errors, $redirect_url );
            } else {
                // Success, redirect to login page.
                $redirect_url = get_permalink( pxaas_addons_get_option('login_page') );
                $redirect_url = add_query_arg( 'registered', $email, $redirect_url );
            }
        }
 
        wp_safe_redirect( $redirect_url );
        exit;
    }
}





add_action( 'login_form_lostpassword', 'pxaas_addons_redirect_to_custom_lostpassword' );
function pxaas_addons_redirect_to_custom_lostpassword() {
    if( pxaas_addons_get_option('custom_logreg_enable') == 'no' ) return;
    $forgot_pass_page = get_permalink( pxaas_addons_get_option('forgot_pass_page') );
    if ( 'GET' == $_SERVER['REQUEST_METHOD'] ) {
        if ( is_user_logged_in() ) {
            pxaas_addons_redirect_logged_in_user();
            exit;
        }
        wp_safe_redirect( $forgot_pass_page );
        exit;
    }
}

add_action( 'login_form_lostpassword', 'pxaas_addons_do_password_lost' );
function pxaas_addons_do_password_lost() {
    if( pxaas_addons_get_option('custom_logreg_enable') == 'no' ) return;
    // $forgot_pass_page = get_permalink( pxaas_addons_get_option('forgot_pass_page') );
    if ( 'POST' == $_SERVER['REQUEST_METHOD'] ) {
        $errors = retrieve_password();
        
        // $redirect_url = $forgot_pass_page;
        if ( is_wp_error( $errors ) ) {
            // Errors found
            $redirect_url = get_permalink( pxaas_addons_get_option('forgot_pass_page') );
            $redirect_url = add_query_arg( 'errors', join( ',', $errors->get_error_codes() ), $redirect_url );
        } else {
            // Email sent
            $redirect_url = get_permalink( pxaas_addons_get_option('login_page') );
            $redirect_url = add_query_arg( 'checkemail', 'confirm', $redirect_url );
        }
 
        wp_safe_redirect( $redirect_url );
        exit;
    }
}
add_filter( 'retrieve_password_message', 'pxaas_addons_replace_retrieve_password_message' , 10, 4 );
function pxaas_addons_replace_retrieve_password_message( $message, $key, $user_email, $user_data ) {
    if( pxaas_addons_get_option('custom_logreg_enable') == 'no' ) return $message;
    // Create new message
    $msg  = __( 'Hello!', 'pxaas-add-ons' ) . "\r\n\r\n";
    $msg .= sprintf( __( 'You asked us to reset your password for your account using the email address %s.', 'pxaas-add-ons' ), $user_email ) . "\r\n\r\n";
    $msg .= __( "If this was a mistake, or you didn't ask for a password reset, just ignore this email and nothing will happen.", 'pxaas-add-ons' ) . "\r\n\r\n";
    $msg .= __( 'To reset your password, visit the following address:', 'pxaas-add-ons' ) . "\r\n\r\n";
    $msg .= site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_email ), 'login' ) . "\r\n\r\n";
    $msg .= __( 'Thanks!', 'pxaas-add-ons' ) . "\r\n";
 
    return $msg;
}
