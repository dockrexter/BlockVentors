<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Posts_Grid extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'posts_grid';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Posts Grid', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'eicon-gallery-justified';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.10
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_query',
            [
                'label' => __( 'Posts Query', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'cat_ids',
            [
                'label' => __( 'Post Category IDs to include', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter post category ids to include, separated by a comma. Leave empty to get posts from all categories.", 'pxaas-add-ons')
                
            ]
        );

        $this->add_control(
            'ids',
            [
                'label' => __( 'Enter Post IDs', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '437,439,451',
                'label_block' => true,
                'description' => __("Enter Post ids to show, separated by a comma. Leave empty to show all.", 'pxaas-add-ons')
                
            ]
        );
        $this->add_control(
            'ids_not',
            [
                'label' => __( 'Or Post IDs to Exclude', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                'description' => __("Enter post ids to exclude, separated by a comma (,). Use if the field above is empty.", 'pxaas-add-ons')
                
            ]
        );

        $this->add_control(
            'order_by',
            [
                'label' => __( 'Order by', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'date' => esc_html__('Date', 'pxaas-add-ons'), 
                    'ID' => esc_html__('ID', 'pxaas-add-ons'), 
                    'author' => esc_html__('Author', 'pxaas-add-ons'), 
                    'title' => esc_html__('Title', 'pxaas-add-ons'), 
                    'modified' => esc_html__('Modified', 'pxaas-add-ons'),
                    'rand' => esc_html__('Random', 'pxaas-add-ons'),
                    'comment_count' => esc_html__('Comment Count', 'pxaas-add-ons'),
                    'menu_order' => esc_html__('Menu Order', 'pxaas-add-ons'),
                ],
                'default' => 'date',
                'separator' => 'before',
                'description' => esc_html__("Select how to sort retrieved posts. More at ", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __( 'Sort Order', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => esc_html__('Ascending', 'pxaas-add-ons'), 
                    'DESC' => esc_html__('Descending', 'pxaas-add-ons'), 
                ],
                'default' => 'DESC',
                'separator' => 'before',
                'description' => esc_html__("Select Ascending or Descending order. More at", 'pxaas-add-ons').'<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex</a>.', 
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __( 'Posts to show', 'pxaas-add-ons' ),
                'type' => Controls_Manager::NUMBER,
                'default' => '4',
                'description' => esc_html__("Number of posts to show (-1 for all).", 'pxaas-add-ons'),
                
            ]
        );

        

        $this->end_controls_section();

        $this->start_controls_section(
            'section_layout',
            [
                'label' => __( 'Posts Layout', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'columns_grid',
            [
                'label' => __( 'Columns Grid', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    ''            => __( 'Default', 'pxaas-add-ons' ),  
                    'col-md-12 '  => __( 'One Column', 'pxaas-add-ons' ),
                    'col-md-6 '   => __( 'Two Column', 'pxaas-add-ons' ),
                    'col-md-4 '   => __( 'Three Column', 'pxaas-add-ons' ),
                    'col-md-3 '   => __( 'Four Column', 'pxaas-add-ons' ),
                    'col-md-2 '   => __( 'Six Column', 'pxaas-add-ons' ),
                ],
                'default' => '',
                // 'description' => esc_html__("Number of posts to show (-1 for all).", 'pxaas-add-ons'),
                
            ]
        );

        $this->add_control(
            'excerpt_length',
            [
                'label' => __( 'Post Description Length', 'pxaas-add-ons' ),
                'type' => Controls_Manager::NUMBER,
                'default' => '250',
                'min'     => 0,
                'max'     => 500,
                'step'    => 10,                
            ]
        );

        $this->add_control(
            'show_pagination',
            [
                'label' => __( 'Show Pagination', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_author',
            [
                'label' => __( 'Show Author', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'show_tags',
            [
                'label' => __( 'Show Tags', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'btn_name',
            [
                'label' => __( 'Button Name Read', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Read More',
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();

        if(is_front_page()) {
            $paged = (get_query_var('page')) ? get_query_var('page') : 1;
        } else {
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        }

        if(!empty($settings['ids'])){
            $ids = explode(",", $settings['ids']);
            $post_args = array(
                'post_type' => 'post',
                'paged' => $paged,
                'posts_per_page'=> $settings['posts_per_page'],
                'post__in' => $ids,
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],
                'post_status' => 'publish'
            );
        }elseif(!empty($settings['ids_not'])){
            $ids_not = explode(",", $settings['ids_not']);
            $post_args = array(
                'post_type' => 'post',
                'paged' => $paged,
                'posts_per_page'=> $settings['posts_per_page'],
                'post__not_in' => $ids_not,
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],
                'post_status' => 'publish'
            );
        }else{
            $post_args = array(
                'post_type' => 'post',
                'paged' => $paged,
                'posts_per_page'=> $settings['posts_per_page'],
                'orderby'=> $settings['order_by'],
                'order'=> $settings['order'],

                'post_status' => 'publish'
            );
        }


        if(!empty($settings['cat_ids']))
            $post_args['cat'] = $settings['cat_ids'];
        $css_classes = array(
            'row',
            'blog-posts',
        );

        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

        ?>
        <div class="<?php echo esc_attr($css_class );?>">
        <?php 
            $posts_query = new \WP_Query($post_args);
            if($posts_query->have_posts()) : ?>
                <?php while($posts_query->have_posts()) : $posts_query->the_post(); ?>
                    
                        <div class="blog-box mb-50px <?php echo $settings['columns_grid']; ?>">
                            <div class="o-hidden">
                                <?php the_post_thumbnail( 'full', array('class'=>'img-fluid transition-4') ); ?>
                            </div>
                            <h4 class="mt-20px">
                                <a class="color-333 fw-600 color-blue-hvr" href="#0"><?php the_title(); ?></a> 
                            </h4>
                            <?php if( pxaas_get_option( 'blog_author') || pxaas_get_option( 'blog_tags' )){ ?>
                                <p class="mt-10px mb-15px">
                                    <?php if( pxaas_get_option( 'blog_author') ){ 
                                        if ($settings['show_author'] === 'yes') { ?>
                                            <span class="pos-author mr-10px"><i class="fa fa-user color-blue"></i>
                                                <?php the_author_posts_link( ); ?>
                                            </span>
                                    <?php }
                                    } ?>
                                    <?php if( pxaas_get_option( 'blog_tags' ) && get_the_tags( ) ) { 
                                        if($settings['show_tags'] === 'yes') { ?>
                                            <span class="pos-tags"><i class="fa fa-tag color-blue"></i>
                                                <?php the_tags('' , ', ' , ''); ?>
                                            </span>
                                    <?php } 
                                    } ?>
                                </p>
                            <?php } ?>
                            
                            <?php the_excerpt(); ?>
                            <a class="read transition-5 o-hidden d-inline-block p-relative pl-20px mt-10px mr-15px color-aaa color-blue-hvr" href="<?php echo the_permalink(); ?>"><span class="line transition-4 p-absolute d-inline-block bg-333"></span><?php echo ' '.$settings['btn_name']; ?></a>
                        </div>

                <?php endwhile; ?>
                <?php if($settings['show_pagination'] === 'yes') pxaas_custom_pagination( $posts_query->max_num_pages, 2, $posts_query  ); ?>
            <?php endif; 
            wp_reset_postdata();
            ?> 
        </div>
        <?php
        // if($settings['show_pagination'] == 'yes') pxaas_addons_custom_pagination($posts_query->max_num_pages,$range = 2, $posts_query) ;
        ?>
        <?php
            // $url = $settings['read_all_link']['url'];
            // $target = $settings['read_all_link']['is_external'] ? 'target="_blank"' : '';
            // if($url != '') echo '<div class="all-posts-link"><a href="' . $url . '" ' . $target .' class="btn big-btn circle-btn dec-btn color-bg flat-btn">'.__('Read All','pxaas-add-ons').'<i class="fa fa-eye"></i></a></div>';
        ?>
        
        <?php

    }

    protected function _content_template() {}

   
    

}

