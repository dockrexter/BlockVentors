<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_List extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    
    */
    public function get_name() {
        return 'cth_list';
    }

    // public function get_id() {
    //      return 'header-search';
    // }

    public function get_title() {
        return __( 'Text List', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-th';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            '_content',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'list_items',
            [
                'label' => __( 'List Items', 'pxaas-add-ons' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [
                        'title'     => 'Item 01',
                        'content' => 'nostrud exercitation ullamco laboris nisi',
                    ],
                    [
                        'title'     => 'Item 02',
                        'content' => 'sed do eiusmod tempor incididunt ut labore',
                    ],
                    [
                        'title'     => 'Item 03',
                        'content' => 'Lorem ipsum dolore magna aliqua',
                    ],
                    [
                        'title'     => 'Item 04',
                        'content' => 'Lorem ipsum dolor consectetur adipiscing',
                    ],
                ],
                'fields' => [
                    [
                        'name'      => 'title',
                        'label'     => __( 'Title', 'pxaas-add-ons' ),
                        'type'      => Controls_Manager::TEXT,
                        'default'   => 'Admin Title',
                        // 'show_label' => false,
                    ],
                    [
                        'name'      => 'content',
                        'label'     => __( 'Content', 'pxaas-add-ons' ),
                        'type'      => Controls_Manager::TEXTAREA, // WYSIWYG,
                        'default'   => 'Lorem ipsum dolor consectetur adipiscing',
                        // 'show_label' => false,
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );  

        
        $this->end_controls_section();



        $this->start_controls_section(
            '_layout',
            [
                'label' => __( 'Layout', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'list_type',
            [
                'label'   => __( 'List Style', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'dot',
                'options' => [
                    'dot'    => __( 'Dot style', 'pxaas-add-ons' ),
                    
                    'icon'   => __( 'Icon Style', 'pxaas-add-ons' ),
                    'num'   => __( 'Number Style', 'pxaas-add-ons' ),
                    'none'   => __( 'No Style', 'pxaas-add-ons' ),
                ],
            ]
        );
        $this->add_control(
            'icon',
            [
                'label'       => __( 'Icon from https://iconmonstr.com/iconicfont/ (ex: "im im-store")', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT2,
                'options' => pxaas_addons_get_icon_iconmonstr_select2(),
                'default' => '',
                'label_block' => true,
                'condition' => [
                    'list_type' => 'icon',
                ]
            ]
        );

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $list_items = $settings['list_items'];
        if(empty($list_items)) return;

        $list_type = $settings['list_type'];
        
        $css_classes = array(
            'cthlist-items',
            'cthlist-'.$list_type,
        );

        $_tag = $_tag_item = 'div';
        if($list_type == 'num'){
            $_tag = 'ol';
            $_tag_item = 'li';
        }

        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );
        ?>
        <<?php echo $_tag; ?> class="<?php echo esc_attr($css_class); ?>">
            <?php foreach ($list_items as $key => $litem) {
                echo '<'.$_tag_item.' class="cthlist-item">';
                echo '<span class="cthlist-item-icon">';
                if($list_type == 'icon' && !empty($settings['icon']) ) echo '<i class="'.$settings['icon'].'"></i>';
                echo '</span>';
                echo '<span class="cthlist-item-content">';
                echo $litem['content'];
                echo '</span>';
                echo '</'.$_tag_item.'>';
            } ?>
        </<?php echo $_tag; ?>>
<?php

    }
}
