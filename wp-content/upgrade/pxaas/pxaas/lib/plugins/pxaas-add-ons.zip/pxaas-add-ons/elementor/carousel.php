<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Carousel extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    
    */
    public function get_name() {
        return 'carousel';
    }

    // public function get_id() {
    //      return 'header-search';
    // }

    public function get_title() {
        return __( 'Carousel Option', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'abc',
            [
                'label' => __( 'Member', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'caro_content',
            [
                'label' => __( 'Testimonials ', 'pxaas-add-ons' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [
                        'testi_title' => __( 'Title #1', 'pxaas-add-ons' ),
                        'testi_content' => __( 'Item content. Click the edit button to change this text.', 'pxaas-add-ons' ),
                    ],
                    
                ],
                'fields' => [
                    // [
                    //     'name' => 'number_order',
                    //     'label' => __( 'Number order', 'pxaas-add-ons' ),
                    //     'type' => Controls_Manager::NUMBER,
                    //     'default' => __( '1' , 'pxaas-add-ons' ),
                    //     'label_block' => false,
                    //     'min'     => 1,
                    //     'step'    => 1,
                    // ],
                    [
                        'name'  => 'icon',
                        'label' => __( 'Icon', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::SELECT2,
                        'options' => pxaas_addons_get_icon_iconmonstr_select2(),
                        'default' => 'im im-color-fan',
                        'label_block' => false,
                    ],
                    [
                        'name' => 'list_title',
                        'label' => __( 'Title', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => __( 'SIMPLE AND USEFUL!' , 'pxaas-add-ons' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'list_content',
                        'label' => __( 'Content', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXTAREA,
                        'default' => '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. the industrys standard dummy.</p>',
                        // 'show_label' => false,
                    ],
                    
                    [
                        'name' => 'image',
                        'label' => __( 'Choose Image', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::MEDIA,
                        'default' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'name' => 'list_title_img',
                        'label' => __( 'Title Image', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => 'Lorem ipsum dolor sit amet',
                        'label_block' => true,
                    ],
                    [
                        'name' => 'content_img',
                        'label' => __( 'Content Image', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXTAREA,
                        'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incididunt labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi.',
                        // 'show_label' => false,
                    ],
                    [
                        'name' => 'show_sep',
                        'label' => __( 'Show Separator', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::SWITCHER,
                        'default' => 'yes',
                        'label_on' => __( 'Show', 'pxaas-add-ons' ),
                        'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                        'return_value' => 'yes',
                    ],
                    [
                        'name' => 'btn_name',
                        'label' => __( 'Path Name', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => 'Learn more',
                        'label_block' => true,
                        
                    ],
                    [
                        'name' => 'link_img',
                        'label' => __( 'URL', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::URL,
                        'default' => [
                            'url' => '#',
                            'is_external' => '',
                        ],
                        'show_external' => true, // Show the 'open in new tab' button.
                    ],
                    
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );  
        $this->end_controls_section();


        $this->start_controls_section(
            'def',
            [
                'label' => __( 'Carousel Option', 'pxaas-add-ons' ),
            ]
        );
            $this->add_control(
                'local_dots',
                [
                    'label' => __( 'Button position to move the image', 'pxaas-add-ons' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'col-md-4',
                    'options' => [
                        'col-md-4'  => __( 'Left', 'pxaas-add-ons' ),
                        'col-md-12' => __( 'Top', 'pxaas-add-ons' ),
                    ],
                 ]
            );
            // $this->add_control(
            //     'view_caro',
            //     [
            //         'label'   => __( 'Choose the carousel style', 'pxaas-add-ons' ),
            //         'type'    => Controls_Manager::SELECT,
            //         'default' => '',
            //         'options' => [
            //             ''         => __( 'Left - Style 1', 'pxaas-add-ons' ),
            //             'col-md-5' => __( 'Left - Style 2', 'pxaas-add-ons' ),
            //         ],
            //         'condition' => [
            //             'local_dots' => 'col-md-4',
            //         ],
            //      ]
            // );
            $this->add_control(
                'respon',
                [
                    'label' => __( 'Responsive', 'pxaas-add-ons' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => '320:1,768:1,992:1,1200:1',
                ]
            );
            $this->add_control(
                'speed',
                [
                    'label' => __( 'Speed', 'pxaas-add-ons' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => '650',
                    'label_block' => true,                    
                ]
            );
            $this->add_control(
                'au_play',
                [
                    'label' => __( 'Auto Play', 'pxaas-add-ons' ),
                    'type' => Controls_Manager::SWITCHER,
                    'default' => 'no',
                    'label_on' => __( 'Show', 'pxaas-add-ons' ),
                    'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                    'return_value' => 'yes',
                ]
            );
            $this->add_control(
                'loop',
                [
                    'label' => __( 'Loop', 'pxaas-add-ons' ),
                    'type' => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                    'label_on' => __( 'Show', 'pxaas-add-ons' ),
                    'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                    'return_value' => 'yes',
                ]
            );
            $this->add_control(
                'navi',
                [
                    'label' => __( 'Show Navigation', 'pxaas-add-ons' ),
                    'type' => Controls_Manager::SWITCHER,
                    'default' => 'no',
                    'label_on' => __( 'Show', 'pxaas-add-ons' ),
                    'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                    'return_value' => 'yes',
                ]
            );
            $this->add_control(
                'dots',
                [
                    'label' => __( 'Show Dots', 'pxaas-add-ons' ),
                    'type' => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                    'label_on' => __( 'Show', 'pxaas-add-ons' ),
                    'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                    'return_value' => 'yes',
                ]
            );

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $content = $settings['caro_content'];

        $dataArr = array();
        $dataArr['smartSpeed'] = (int)$settings['speed'];
        if($settings['au_play'] == 'yes') $dataArr['autoplay'] = true;
        if($settings['loop'] == 'yes') 
            $dataArr['loop'] = true;
        else 
            $dataArr['loop'] = false;
        if($settings['navi'] == 'yes') 
            $dataArr['nav'] = true;
        else 
            $dataArr['nav'] = false;
        if($settings['dots'] == 'yes') 
            $dataArr['dots'] = true;
        else 
            $dataArr['dots'] = false;
        if(!empty($settings['respon'])){
            // $css_classes .=' resp-ena';
            $dataArr['responsive'] = $settings['respon'];
        }
        // if(is_numeric($spacing)) $dataArr['margin'] = (int)$spacing;

        
        $css_classes = array(
            'row',
            'carousel-element',
        );
        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );
        if($settings['local_dots'] === 'col-md-4') {
            $align      = '';
            $col_dots   = 'col-md-5 ';
            $col_caro   = 'col-md-7 ';
            $class_icon = ' fs-20 bg-gray radius-50 text-center mb-10px mr-5px';
            $class_dots = ' mb-40px';
            // if($settings['view_caro'] === 'col-md-5') {
            //     $col_dots   = 'col-md-5 ';
            //     $col_caro   = 'col-md-7 ';
            // }
        }else {
            $align      = ' text-center';
            $col_dots   = 'col-md-12 ';
            $col_caro   = 'col-md-10 offset-md-1 ';
            $class_icon = ' fs-20 radius-50 text-center mb-10px mr-5px';
            $class_dots = ' d-inline-block p-relative mb-40px mr-25px bg-gray pr-25px pl-25px pt-10px pb-10px radius-10px';
        }
        ?>
        <?php if(is_array($settings['caro_content']) && !empty($settings['caro_content']) ): ?>
            <div class="<?php echo esc_attr($css_class );?>">
                <div class="<?php echo $col_dots; ?>mt-25px mb-25px">
                    <div class="vision-dots<?php echo $align; ?> vision-dots-<?php echo count($settings['caro_content']);?>">
                        <?php $number_order = 1; ?>
                        <?php foreach ($settings['caro_content'] as $key => $val) { ?>
                            <!-- Location Top -->
                            <?php if($settings['local_dots'] != 'col-md-4') { ?>
                                <div class="dots<?php echo $class_dots; ?>">

                                    <?php if($val['icon'] !== ''): ?>
                                        <i class="<?php echo $val['icon'].$class_icon ?>"></i> 
                                    <?php endif; ?>
                                    <?php if($val['list_title'] !== ''): ?>
                                        <h4 class="mb-5px"><?php echo $val['list_title']; ?></h4>
                                    <?php endif; ?>
                                    <?php if($settings['local_dots'] === 'col-md-4'): ?>
                                        <?php if($val['list_content'] !== ''): ?>
                                            <p><?php echo $val['list_content']; ?></p>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                
                                </div>
                            <?php }else { ?>
                                <div class="dots<?php echo $class_dots; ?>">
                                    <h4 class="p-absolute bg-orange-lh color-orange radius-50 text-center"><?php if($number_order < 10){ echo '0'.$number_order; }else { echo $number_order;} ?></h4>
                                    <div class="pl-80px">
                                        <h4 class="mb-5px"><?php echo $val['list_title']; ?></h4>
                                        <?php if($val['list_content'] !== ''): ?>
                                            <p><?php echo $val['list_content']; ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php } ?>
                            <?php $number_order+= 1; ?>
                        <?php } ?>
                    </div>
                </div>
                <?php if($settings['local_dots'] === 'col-md-4') { ?>
                    <div class="<?php echo $col_caro; ?>mt-25px">
                        <div class="carousel-slider owl-carousel owl-theme" data-options='<?php echo json_encode($dataArr);?>'>
                            <?php foreach ($settings['caro_content'] as $key => $val) { ?>
                                <div class="single-item">
                                    <img alt="img" src="<?php echo $val['image']['url']; ?>">
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } else { ?>
                    <div class="<?php echo $col_caro; ?>mt-25px">
                        <div class="carousel-slider owl-carousel owl-theme" data-options='<?php echo json_encode($dataArr);?>'>
                            <?php foreach ($settings['caro_content'] as $key => $val) { ?>
                                <div class="single-item">
                                    <div class="row">
                                        <div class="col-md-6 mb-25px">
                                            <img alt="img" src="<?php echo $val['image']['url']; ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <h4 class="mb-15px"><?php echo $val['list_title_img']; ?></h4>
                                            <p class="mb-25px"><?php echo $val['content_img']; ?></p>
                                            <?php if( 'yes' == $val['show_sep']): ?>
                                                <a class="main-btn btn-3" href="<?php if($val['link_img']['url']!= '') echo $val['link_img']['url']; ?>"><?php echo $val['btn_name'];?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>
            </div>
        <?php endif; ?>

<?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

}


// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

