<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Px_Counter extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'px_counter';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'PXaas Counter', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'eicon-counter';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.10
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'icon',
            [
                'label' => __( 'Icon', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT2,
                'options' => pxaas_addons_get_icon_iconmonstr_select2(),
                'default' => '',
                'label_block' => false,
            ]
        );
        $this->add_control(
            'number',
            [
                'label' => __( 'Counter Number', 'pxaas-add-ons' ),
                'type' => Controls_Manager::NUMBER,
                'default' => '254',
                'min'     => 1,
                // 'max'     => 500,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'New Listing Every Week',
                'label_block' => true,
                
            ]
        );

        $this->add_control(
            'color',
            [
                'label'       => __( 'Couter Color', 'pxaas-add-ons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => '',
                'options'     => [
                    ''   => __( 'Default', 'pxaas-add-ons' ),
                    '1'  => __( 'Color - 1', 'pxaas-add-ons' ),
                    '2'  => __( 'Color - 2', 'pxaas-add-ons' ),
                    '3'  => __( 'Color - 3', 'pxaas-add-ons' ),
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render( ) {
        $settings = $this->get_settings();
        $color = $settings['color']; 

        if($color === '') {
            $css_wrap = "";
            $css_bgcolor = "bg-orange";
            $css_color = "color-orange";
        }
        if($color === '1') {
            $css_wrap = "counter-1";
            $css_bgcolor = "bg-blue";
            $css_color = "color-blue";
        }
        if($color === '2') {
            $css_wrap = "counter-2";
            $css_bgcolor = "";
            $css_color = "";
        }

        if($settings['number']):
        ?>
            <div class="inline-facts-wrap <?php echo $css_wrap; ?> mt-25px mb-25px text-center">
                <i class="<?php echo $settings['icon']; ?> <?php echo $css_bgcolor; ?> fs-30 mb-20px color-fff radius-10px transition-2"></i>
                <h3 class="mb-0px"><?php echo $settings['title'];?></h3>
                <div class="milestone-counter">
                    <div class="stats animaper">
                        <div class="num d-block fs-35 <?php echo $css_color; ?>" data-from="0" data-to="<?php echo $settings['number'];?>">0</div>
                    </div>
                </div>
            </div>
        <?php
        endif;
    }

    protected function _content_template() {
        ?>
        <# if(settings.number){ #>
        <div class="inline-facts-wrap mt-25px mb-25px">
            <i class="<# {{{settings.icon}}} #> fs-30 mb-20px color-fff bg-orange radius-10px transition-2"></i>
            <h3 class="mb-0px">{{{settings.title}}}</h3>
            <div class="milestone-counter">
                <div class="stats animaper">
                    <div class="num d-block fs-35 color-orange" data-content="0" data-num="{{{settings.number}}}">{{{settings.number}}}</div>
                </div>
            </div>
        </div>
        <# } #>
        <?php
    }

   
    

}



