function cth_get_vc_attach_images(images, holder, wrapper){
    $.post({
        dataType: "json",
        url: ajaxurl,
        data: {action: 'cth_vc_images', images: images},
        success:function(result){
            // console.log(result)
            wrapper.find('i.vc_element-icon').remove();
            holder.html(result);
        }
    });
}
window.CTHVCImages = vc.shortcode_view.extend({
    $wrapper: !1
    ,changeShortcodeParams: function (model) {
        var params;
        if (window.CTHVCImages.__super__.changeShortcodeParams.call(this, model), params = _.extend({}, model.get("params")), this.$wrapper || (this.$wrapper = this.$el.find(".wpb_element_wrapper")), _.isObject(params)){
            var wrapper_jq = this.$wrapper;
            this.$wrapper.find('.wpb_vc_param_value.cth-vc-images').each(function(){
                var singleimgHolder = $(this);
                var param_name = singleimgHolder.attr('name') ;
                if(param_name !== 'undefined' && "undefined" !== params[param_name] && '' !== params[param_name]){
                    cth_get_vc_attach_images(params[param_name], singleimgHolder, wrapper_jq);
                }
            });
        }
    }
});
