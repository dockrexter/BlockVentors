<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Google_Map extends Widget_Base {

    public function get_name() {
        return 'google_map';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Map', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'eicon-google-maps';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Map Position', 'pxaas-add-ons' ),
            ]
        );

        
        $this->add_control(
            'map_lat',
            [
                'label' => __( 'Address Latitude', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '40.7143528',
                'description' => __('Enter your address latitude. You can get value from: ', 'pxaas-add-ons').'<a href="'.esc_url('http://www.gps-coordinates.net/').'" target="_blank">'.esc_url('http://www.gps-coordinates.net/').'</a>',
                'label_block' => true,
                
            ]
        );

        $this->add_control(
            'map_lng',
            [
                'label' => __( 'Address Longtitude', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '-74.0059731',
                'description' => __('Enter your address longtitude. You can get value from: ', 'pxaas-add-ons').'<a href="'.esc_url('http://www.gps-coordinates.net/').'" target="_blank">'.esc_url('http://www.gps-coordinates.net/').'</a>',
                'label_block' => true,
                
            ]
        );

    
        $this->add_control(
            'map_address',
            [
                'label' => __( 'Address String', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'New York City',
                'label_block' => true,
                
            ]
        );

        $this->add_control(
            'zoom',
            [
                'label' => __( 'Zoom Level', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 14,
                ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 20,
                    ],
                ],
            ]
        );


        $this->add_control(
            'height',
            [
                'label' => __( 'Height', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 500,
                ],
                'range' => [
                    'px' => [
                        'min' => 40,
                        'max' => 1440,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .singleMap' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


    
        $this->end_controls_section();

        

    }

    protected function render( ) {
        $settings = $this->get_settings();
        $map_cls = 'singleMap';
        // if(pxaas_addons_get_option('use_osm_map') == 'yes')  $map_cls = 'singleMapOSM';

        if(pxaas_addons_get_option('use_osm_map') == 'yes'){
            $map_cls = 'singleMapOSM';
            wp_enqueue_style( 'openlayers' , PXAAS_ADD_ONS_DIR_URL ."assets/css/ol.css", false ); 
            wp_enqueue_script( 'openlayers', PXAAS_ADD_ONS_DIR_URL ."assets/js/ol.js" , array(), null , true );
        }else{
            $gmap_api_key = pxaas_addons_get_option('gmap_api_key');
            wp_enqueue_script("googleapis", "https://maps.googleapis.com/maps/api/js?key=$gmap_api_key",array(),false,true);
        }

        ?>
            <div id="<?php echo uniqid('map'); ?>" class="<?php echo esc_attr( $map_cls ); ?>" data-lat="<?php echo $settings['map_lat'];?>" data-lng="<?php echo $settings['map_lng'];?>" data-loc="<?php echo $settings['map_address'];?>" data-zoom="<?php echo $settings['zoom']['size'];?>"></div>
        <?php
    }
}


