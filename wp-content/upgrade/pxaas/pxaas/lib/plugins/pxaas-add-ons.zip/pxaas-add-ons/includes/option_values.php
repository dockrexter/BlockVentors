<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



function pxaas_addons_get_plugin_options(){ 
    return array(
        'general' => array(

            array(
                "type" => "section",
                'id' => 'general_section_5',
                "title" => __( 'Currency Options', 'pxaas-add-ons' ),
            ),

            array(
                "type" => "field",
                "field_type" => "select",
                'id' => 'currency',
                "title" => __('Currency', 'pxaas-add-ons'),
                'args'=> array(
                    'default'=> 'USD',
                    'options'=> pxaas_addons_get_currency_array(),
                    'class'     => 'base_currency_select'
                )
            ),

            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'currency_symbol',
                'args' => array(
                    'default'  => '$',
                ),
                "title" => __('Symbol', 'pxaas-add-ons'),
                // 'desc'  => __('General', 'pxaas-add-ons'),
            ),


            // array(
            //     "type" => "field",
            //     "field_type" => "select",
            //     'id' => 'currency_pos',
            //     "title" => __('Currency position', 'pxaas-add-ons'),
            //     'args'=> array(
            //         'default'=> 'left_space',
            //         'options'=> array(
            //             'left' => __( 'Left', 'pxaas-add-ons' ),
            //             'left_space' => __( 'Left with space', 'pxaas-add-ons' ),
            //             'right' => __( 'Right', 'pxaas-add-ons' ),
            //             'right_space' => __( 'Right with space', 'pxaas-add-ons' ),
            //         ),
            //     )
            // ),
            

            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'thousand_sep',
                'args' => array(
                    'default'  => ',',
                ),
                "title" => __('Thousand separator', 'pxaas-add-ons'),
                // 'desc'  => __('General', 'pxaas-add-ons'),
            ),

            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'decimal_sep',
                'args' => array(
                    'default'  => '.',
                ),
                "title" => __('Decimal separator', 'pxaas-add-ons'),
                // 'desc'  => __('General', 'pxaas-add-ons'),
            ),

            array(
                "type" => "field",
                "field_type" => "number",
                'id' => 'decimals',
                "title" => __('Number of decimals', 'pxaas-add-ons'),
                'args' => array(
                    'default'  => '0',
                    'min'  => '0',
                    'max'  => '14',
                    'step'  => '1',
                ),
                // 'desc'  => __('Timezone offset value from UTC', 'pxaas-add-ons'),
            ),

            array(
                "type" => "section",
                'id' => 'general_section_1',
                "title" => __( 'Custom Login/Register', 'pxaas-add-ons' ),
            ),

            
            array(
                "type" => "field",
                "field_type" => "checkbox", 
                'id' => 'custom_logreg_enable',
                'args'=> array(
                    'default' => 'no',
                    'value' => 'yes',
                ),
                "title" => __('Enable custom login/register page', 'pxaas-add-ons'),  
                'desc'  => __( 'Check this if you want to redirect user to custom login/register page instead of WordPress default.', 'pxaas-add-ons' ),
            ),

            array(
                "type" => "field",
                "field_type" => "page_select",
                'id' => 'register_page',
                "title" => __('Register Page', 'pxaas-add-ons'),
                'desc'  => __('The page will be used for user register. The page content must container [pxaas-register-form] shortcode', 'pxaas-add-ons'),
                'args' => array(
                    'default_title' => "Register Page",
                )
            ),

            array(
                "type" => "field",
                "field_type" => "page_select",
                'id' => 'login_page',
                "title" => __('Login Page', 'pxaas-add-ons'),
                'desc'  => __('The page will be used for user login. The page content must container [pxaas-login-form] shortcode', 'pxaas-add-ons'),
                'args' => array(
                    'default_title' => "Login Page",
                )
            ),

            array(
                "type" => "field",
                "field_type" => "page_select",
                'id' => 'forgot_pass_page',
                "title" => __('Forgot Password Page', 'pxaas-add-ons'),
                'desc'  => __('The page will be used for user forgot password. The page content must container [pxaas-password-lost-form] shortcode', 'pxaas-add-ons'),
                'args' => array(
                    'default_title' => "Lost password page",
                )
            ),

            array(
                "type" => "field",
                "field_type" => "page_select",
                'id' => 'login_redirect_page',
                "title" => __('Login Success Redirect', 'pxaas-add-ons'),
                'desc'  => __('The page logged in user will be redirect to.', 'pxaas-add-ons'),
                'args' => array(
                    'default_title' => "Login Success",
                )
            ),

            // [pxaas-password-reset-form]

        ),
        
        'gmap' => array(
            array(
                "type" => "section",
                'id' => 'gmap_osm_sec',
                "title" => __( 'OpenStreetMap', 'pxaas-add-ons' ),
            ),

            array(
                "type" => "field",
                "field_type" => "checkbox",
                'id' => 'use_osm_map',
                'args'=> array(
                    'default' => 'no',
                    'value' => 'yes',
                ),
                "title" => __('Use Free OpenStreetMap Instead', 'pxaas-add-ons'),
                'desc'  => '',
            ),
            array(
                "type" => "section",
                'id' => 'gmap_section_1',
                "title" => __( 'Google API', 'pxaas-add-ons' ),
            ),

            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'gmap_api_key',
                "title" => __('Google Map API Key', 'pxaas-add-ons'),
                'desc'  => sprintf( __( 'You have to enter your API key to use google map feature. Required services: <b>Google Places API Web Service</b>, <b>Google Maps JavaScript API</b> and <b>Google Maps Geocoding API</b>.<br><a href="%s" target="_blank">Get Your Key</a>', 'pxaas-add-ons' ), esc_url('https://developers.google.com/maps/documentation/javascript/get-api-key' ) ),
            ),

            
            array(
                "type" => "section",
                'id' => 'gmap_option',
                "title" => __( 'Map Option', 'pxaas-add-ons' ),
            ),

            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'gmap_default_lat',
                'args'=> array(
                    'default'=> '40.7',
                ),
                "title" => __('Default Latitude', 'pxaas-add-ons'),
                'desc'  => sprintf( __( 'Enter your address latitude - default: 40.7. You can get value from this <a href="%s" target="_blank">website</a>', 'pxaas-add-ons' ), esc_url('http://www.gps-coordinates.net/' ) ),
            ),

            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'gmap_default_long',
                'args'=> array(
                    'default'=> '-73.87',
                ),
                "title" => __('Default Longtitude', 'pxaas-add-ons'),
                'desc'  => sprintf( __( 'Enter your address longtitude - default: -73.87. You can get value from this <a href="%s" target="_blank">website</a>', 'pxaas-add-ons' ), esc_url('http://www.gps-coordinates.net/' ) ),
            ),

            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'gmap_default_zoom',
                'args'=> array(
                    'default'=> '10',
                ),
                "title" => __('Default Zoom', 'pxaas-add-ons'),
                'desc'  => __('Default map zoom level, max: 18', 'pxaas-add-ons'),
            ),


            array(
                "type" => "field",
                "field_type" => "image",
                'id' => 'gmap_marker',
                "title" => __('Map Marker', 'pxaas-add-ons'),
                'desc'  => ''
            ),

            
        ),

        'widgets' => array(


            array(
                "type" => "section",
                'id' => 'mailchimp_sub_section',
                "title" => __( 'Mailchimp Section', 'pxaas-add-ons' ),
            ),

            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'mailchimp_api',
                "title" => __('Mailchimp API key', 'pxaas-add-ons'),
                'desc'  => '<a href="'.esc_url('http://kb.mailchimp.com/accounts/management/about-api-keys#Finding-or-generating-your-API-key').'" target="_blank">'.esc_html__('Find your API key','pxaas-add-ons' ).'</a>'
            ),
            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'mailchimp_list_id',
                "title" => __('Mailchimp List ID', 'pxaas-add-ons'),
                'desc'  => '<a href="'.esc_url('http://kb.mailchimp.com/lists/managing-subscribers/find-your-list-id').'" target="_blank">'.esc_html__('Find your list ID','pxaas-add-ons' ).'</a>',
            ),
        
            array(
                "type" => "field",
                "field_type" => "info",
                'id' => 'mailchimp_shortcode',
                "title" => __('Subscribe Shortcode', 'pxaas-add-ons'),
                'desc'  => wp_kses_post( __('Use the <code><strong>[pxaas_subscribe]</strong></code> shortcode  to display subscribe form inside a post, page or text widget.
                    <br>Available Variables:<br>
                    <code><strong>message</strong></code> (Optional) - The message above subscription form.<br>
                    <code><strong>placeholder</strong></code> (Optional) - The form placeholder text.<br>
                    <code><strong>button</strong></code> (Optional) - The submit button text.<br>
                    <code><strong>list_id</strong></code> (Optional) - List ID. If you want user subscribe to a different list from the option above.<br>
                    <code><strong>class</strong></code> (Optional) - Your extraclass used to style the form.<br><br>
                    Example: <code><strong>[pxaas_subscribe list_id="b02fb5f96f" class="your_class_here"]</strong></code>', 'pxaas-add-ons') )
                                    
            ),
            array(
                "type" => "section",
                'id' => 'tweets_section',
                "title" => __( 'Twitter Feeds Section', 'pxaas-add-ons' ),
                'callback' => function($arg){ 
                    echo '<p>'.esc_html__('Visit ','pxaas-add-ons' ).
                        '<a href="'.esc_url('https://apps.twitter.com' ).'" target="_blank">'.esc_html__("Twitter's Application Management",'pxaas-add-ons' ).'</a> '
                        .__('page, sign in with your account, click on Create a new application and create your own keys if you haven\'t one.<br> Fill all the fields bellow with those keys.','pxaas-add-ons' ).
                        '</p>';  
                }
            ),

            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'consumer_key',
                "title" => __('Consumer Key', 'pxaas-add-ons'),
                'desc'  => ''
            ),
            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'consumer_secret',
                "title" => __('Consumer Secret', 'pxaas-add-ons'),
                'desc'  => ''
            ),
            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'access_token',
                "title" => __('Access Token', 'pxaas-add-ons'),
                'desc'  => ''
            ),
            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'access_token_secret',
                "title" => __('Access Token Secret', 'pxaas-add-ons'),
                'desc'  => ''
            ),
            array(
                "type" => "field",
                "field_type" => "info",
                'id' => 'tweets_shortcode',
                "title" => __('Access Token Secret', 'pxaas-add-ons'),
                'desc'  => wp_kses_post( __('You can use <code><strong>PXaas Twitter Feed</strong></code> widget or  <code><strong>[pxaas_tweets]</strong></code> shortcode  to display tweets inside a post, page or text widget.
<br>Available Variables:<br>
<code><strong>username</strong></code> (Optional) - Option to load tweets from another account. Leave this empty to load from your own.<br>
<code><strong>list</strong></code> (Optional) - List name to load tweets from. If you define list name you also must define the <strong>username</strong> of the list owner.<br>
<code><strong>hashtag</strong></code> (Optional) - Option to load tweets with a specific hashtag.<br>
<code><strong>count</strong></code> (Required) - Number of tweets you want to display.<br>
<code><strong>list_ticker</strong></code> (Optional) - Display tweets as a list ticker?. Values: <strong>yes</strong> or <strong>no</strong><br>
<code><strong>follow_url</strong></code> (Optional) - Follow us link.<br>
<code><strong>extraclass</strong></code> (Optional) - Your extraclass used to style the form.<br><br>
Example: <code><strong>[pxaas_tweets count="3" username="CTHthemes" list_ticker="no" extraclass="your_class_here"]</strong></code>', 'pxaas-add-ons') )
                
            ),
            // socials share
            array(
                "type" => "section",
                'id' => 'widgets_section_3',
                "title" => __( 'Socials Share', 'pxaas-add-ons' ),
            ),
            array(
                "type" => "field",
                "field_type" => "text",
                'id' => 'widgets_share_names',
                "title" => __('Socials Share', 'pxaas-add-ons'),
                'desc'  => __('Enter your social share names separated by a comma.<br> List bellow are available names:<strong><br> facebook,twitter,linkedin,in1,tumblr,digg,googleplus,reddit,pinterest,stumbleupon,email,vk</strong>', 'pxaas-add-ons'),
                'args'=> array(
                    'default' => 'facebook, pinterest, googleplus, twitter, linkedin'
                ),
            ),


        ),
        // end tab array

        
    );
}