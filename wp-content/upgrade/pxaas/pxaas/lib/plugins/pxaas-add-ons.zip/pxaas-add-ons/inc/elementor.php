<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */




// https://github.com/pojome/elementor/blob/master/docs/content/hooks/php-hooks.md

// Add a custom category for panel widgets
add_action( 'elementor/init', function() {
   
    \Elementor\Plugin::$instance->elements_manager->add_category( 
        'pxaas-elements',
        [
            'title' => __( 'PXaas Elements', 'pxaas-add-ons' ),
            'icon' => 'fa fa-gmap', //default icon
        ],
        1 // position
    );

} );


add_action( 'elementor/widgets/widgets_registered', function( $widgets_manager ) {

    $elements = array(
        'hero_slider',
        'section_title',
        'feature_box',
        'image',
        'list',
        'px_image',
        'button',
        'px_button',

        'login',
        'lost_pass',
        'register',
        'counter',
        'px_counter',
        'carousel',
        'course',
        'members_grid',
        'membership_plans',
        'our_work',

        'testimonials_slider',
        'posts_grid',
        'our_partners',
        'contact_info',
        'subscribe_form',


        'project_title',
        'project_image',
        'project_information',
        'project_share',

        'contact_form7',
        'google_map',

    );

    foreach ( $elements as $element_name ) {
        $template_file = PXAAS_ADD_ONS_DIR.'elementor/'.$element_name.'.php';
        if ( $template_file && is_readable( $template_file ) ) {
            require_once $template_file;
            $class_name = '\Elementor\CTH_' . ucwords($element_name,'_');
            $widgets_manager->register_widget_type( new $class_name() );
        }
            
    }
} );


