<?php 
/**
Plugin Name: PXaas Add-Ons
Plugin URI: https://pxaas.cththemes.com
Description: A custom plugin for PXaas - Saas & Software Landing Page Theme
Version: 1.0.6
Author: CTHthemes
Author URI: http://themeforest.net/user/cththemes
Text Domain: pxaas-add-ons
Domain Path: /languages/
Copyright: ( C ) 2014 - 2019 cththemes.com . All rights reserved.
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */


if ( ! defined('ABSPATH') ) {
    die('Please do not load this file directly!');
}
define ('PXAAS_ADD_ONS_DIR',plugin_dir_path(__FILE__ ));
define ('PXAAS_ADD_ONS_DIR_URL',plugin_dir_url(__FILE__ ));
define ('P_META_PREFIX','_cth_');

// for debug plugin
if( !defined('CTH_DEBUG') ) define("CTH_DEBUG", false);
if( !defined('CTH_LOG_FILE') ) define("CTH_LOG_FILE", "./cthdev.log");

/* plugin options */
require_once PXAAS_ADD_ONS_DIR . 'plugin_options.php';

// for listing post type
require_once PXAAS_ADD_ONS_DIR .'posttypes/pxaas-plan.php';
require_once PXAAS_ADD_ONS_DIR .'posttypes/pxaas-project.php';
require_once PXAAS_ADD_ONS_DIR .'posttypes/pxaas-testi.php';


//register Team Member post type
function PXaas_Add_ons_register_cpt_PXaas_Member() {
    
    $labels = array( 
        'name' => __( 'Members', 'pxaas-add-ons' ),
        'singular_name' => __( 'Cth_Member', 'pxaas-add-ons' ),
        'add_new' => __( 'Add New Member', 'pxaas-add-ons' ),
        'add_new_item' => __( 'Add New Member', 'pxaas-add-ons' ),
        'edit_item' => __( 'Edit Member', 'pxaas-add-ons' ),
        'new_item' => __( 'New Member', 'pxaas-add-ons' ),
        'view_item' => __( 'View Member', 'pxaas-add-ons' ),
        'search_items' => __( 'Search Members', 'pxaas-add-ons' ),
        'not_found' => __( 'No Members found', 'pxaas-add-ons' ),
        'not_found_in_trash' => __( 'No Members found in Trash', 'pxaas-add-ons' ),
        'parent_item_colon' => __( 'Parent Member:', 'pxaas-add-ons' ),
        'menu_name' => __( 'PXaas Members', 'pxaas-add-ons' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Members',
        'supports' => array( 'title', 'editor', 'thumbnail','excerpt'/*,'comments', 'post-formats'*/),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'menu_icon' =>  'dashicons-groups',
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array( 'slug' => __('member','pxaas-add-ons') ),
        'capability_type' => 'post'
    );

    register_post_type( 'cth_member', $args );
}
// Register Member 
add_action( 'init', 'PXaas_Add_ons_register_cpt_PXaas_Member' );
if(!function_exists('pxaas_member_columns_head')){
    function pxaas_member_columns_head($defaults) {
        $defaults['pxaas_member_thumbnail'] = 'Thumbnail';
        $defaults['pxaas_member_id'] = 'ID';
        return $defaults;
    }
}
if(!function_exists('pxaas_member_columns_content')){
    // CUSTOM POSTS
    function pxaas_member_columns_content($column_name, $post_ID) {
        if ($column_name == 'pxaas_member_id') {
            echo $post_ID;
        }
        if ($column_name == 'pxaas_member_thumbnail') {
            echo get_the_post_thumbnail( $post_ID, 'thumbnail', array('style'=>'width:100px;height:auto;') );
        }
    }
}

add_filter('manage_member_posts_columns', 'pxaas_member_columns_head', 10);
add_action('manage_member_posts_custom_column', 'pxaas_member_columns_content', 10, 2);

// Page ID
if(!function_exists('pxaas_page_columns_head')){
    function pxaas_page_columns_head($defaults) {
        $defaults['page_id'] = 'ID';
        return $defaults;
    }
}
if(!function_exists('pxaas_page_columns_content')){
    // CUSTOM POSTS
    function pxaas_page_columns_content($column_name, $post_ID) {
        if ($column_name == 'page_id') {
            echo $post_ID;
        }
    }
}

add_filter('manage_page_posts_columns', 'pxaas_page_columns_head', 10);
add_action('manage_page_posts_custom_column', 'pxaas_page_columns_content', 10, 2);

// Post ID
if(!function_exists('pxaas_post_columns_head')){
    function pxaas_post_columns_head($defaults) {
        $defaults['post_id'] = 'ID';
        return $defaults;
    }
}
if(!function_exists('pxaas_post_columns_content')){
    // CUSTOM POSTS
    function pxaas_post_columns_content($column_name, $post_ID) {
        if ($column_name == 'post_id') {
            echo $post_ID;
        }
    }
}

add_filter('manage_post_posts_columns', 'pxaas_post_columns_head', 10);
add_action('manage_post_posts_custom_column', 'pxaas_post_columns_content', 10, 2);



//=============================================//
//CMB2
require_once PXAAS_ADD_ONS_DIR .'inc/cmb2/functions.php';



/**
 * Implement Ajax requests
 *
 * @since PXaas 1.0
 */
require_once PXAAS_ADD_ONS_DIR . 'inc/ajax.php';

require_once PXAAS_ADD_ONS_DIR . 'inc/template_tags.php';

require_once PXAAS_ADD_ONS_DIR . 'inc/post_like.php';

require_once PXAAS_ADD_ONS_DIR . 'inc/elementor.php';


//widgets
require_once PXAAS_ADD_ONS_DIR .'widgets/pxaas_recent_posts.php';
require_once PXAAS_ADD_ONS_DIR .'widgets/pxaas_about_author.php';
require_once PXAAS_ADD_ONS_DIR .'widgets/pxaas_banner.php';
require_once PXAAS_ADD_ONS_DIR .'widgets/pxaas_banner_video.php';
require_once PXAAS_ADD_ONS_DIR .'widgets/pxaas_instagram_feed.php';
require_once PXAAS_ADD_ONS_DIR .'widgets/pxaas_twitter_feed.php';
// require_once PXAAS_ADD_ONS_DIR .'widgets/pxaas_mailchimp.php';

function pxaas_add_ons_register_widgets() {
    
    register_widget( 'PXaas_About_Author' );
    register_widget( 'PXaas_Recent_Posts' );
    register_widget( 'PXaas_Instagram_Feed' );
    register_widget( 'PXaas_Banner' );
    register_widget( 'PXaas_Banner_Video' );
    register_widget( 'PXaas_Twitter_Feed' );
    // register_widget( 'PXaas_Mailchimp' );
    


}

add_action( 'widgets_init', 'pxaas_add_ons_register_widgets' );





function cth_pxaas_plugins_init() {
    $plugin_dir = basename(dirname(__FILE__));
    load_plugin_textdomain( 'pxaas-add-ons', false, $plugin_dir . '/languages' );
}
add_action('plugins_loaded', 'cth_pxaas_plugins_init');


function pxaas_addons_activation_hook_callback() {
        
    // http://www.wpexplorer.com/wordpress-page-templates-plugin/
    $exists_options = get_option( 'pxaas-addons-options', array() );
    // add new pages
    // - page args
    $_p = array();
    $_p['post_content']   = '';
    $_p['post_status']    = 'publish';
    $_p['post_type']      = 'page';
    $_p['comment_status'] = 'closed';
    $_p['ping_status']    = 'closed';

    $_p['page_template']    = 'home-page.php';

    // - register page
    $register_page_title = __('User Register','pxaas-add-ons');
    $register_page = get_page_by_title($register_page_title);
    if (!$register_page){
        $_p['post_title']     = $register_page_title;
        $_p['post_content']   = '[pxaas-register-form]';
        // Insert the post into the database
        $exists_options['register_page'] = wp_insert_post($_p); // return post Id or 0 or WP_Error if not success
    }else{
        //make sure the page is not trashed...
        $register_page->post_status = 'publish';
        $register_page->post_content = '[pxaas-register-form]';
        // $register_page->page_template = 'home-page.php';
        $exists_options['register_page'] = wp_update_post($register_page); // return post Id or 0 if not success
    }
    // - login page
    $page_title = __('User Login','pxaas-add-ons');
    $page_post = get_page_by_title($page_title);
    if (!$page_post){
        $_p['post_title']     = $page_title;
        $_p['post_content']   = '[pxaas-login-form]';
        // Insert the post into the database
        $exists_options['login_page'] = wp_insert_post($_p); // return post Id or 0 or WP_Error if not success
    }else{
        //make sure the page is not trashed...
        $page_post->post_status = 'publish';
        $page_post->post_content = '[pxaas-login-form]';
        $exists_options['login_page'] = wp_update_post($page_post); // return post Id or 0 if not success
    }
    // - lost password page
    $page_title = __('User Lost Password','pxaas-add-ons');
    $page_post = get_page_by_title($page_title);
    if (!$page_post){
        $_p['post_title']     = $page_title;
        $_p['post_content']   = '[pxaas-password-lost-form]';
        // Insert the post into the database
        $exists_options['forgot_pass_page'] = wp_insert_post($_p); // return post Id or 0 or WP_Error if not success
    }else{
        //make sure the page is not trashed...
        $page_post->post_status = 'publish';
        $page_post->post_content = '[pxaas-password-lost-form]';
        $exists_options['forgot_pass_page'] = wp_update_post($page_post); // return post Id or 0 if not success
    }



    // update plugin options
    $return = update_option( 'pxaas-addons-options', $exists_options );
}
register_activation_hook( __FILE__, 'pxaas_addons_activation_hook_callback' );


function pxaas_addons_deactivation_hook_callback() {
    
    // move pages to trash
    $force_delete = false;
    // trash listing pages
    $exists_options = get_option( 'pxaas-addons-options', array() );
    if(isset($exists_options['register_page'])){
        wp_delete_post($exists_options['register_page'], $force_delete);
    }
    if(isset($exists_options['login_page'])){
        wp_delete_post($exists_options['login_page'], $force_delete);
    }
    if(isset($exists_options['forgot_pass_page'])){
        wp_delete_post($exists_options['forgot_pass_page'], $force_delete);
    }
}
register_deactivation_hook( __FILE__, 'pxaas_addons_deactivation_hook_callback' );



/* Enable shortcode in widget text content */
add_filter('widget_text', 'do_shortcode');

if(!function_exists('faicon_sc')) {

    function faicon_sc( $atts, $content="" ) {
    
        extract(shortcode_atts(array(
               'name' =>"magic",
               'class'=>'',
         ), $atts));

        $name = str_replace(array("fa fa-","fa-"), "", $name);

        $classes = 'fa fa-'.$name;
        if(!empty($class)){
            $classes .= ' '.$class;
        }
        
        return '<i class="'.$classes.'"></i>'. $content;
     
    }
        
    add_shortcode( 'faicon', 'faicon_sc' ); //Icon
}
if(!function_exists('pxaas_instagram_sc')){
    function pxaas_instagram_sc($atts, $content = ''){

        extract(shortcode_atts(array(
               'limit' =>"6",
               'get'=>'user',//tagged
               'clientid'=>'5d9aa6ad29704bcb9e7e151c9b7afcbc',
               'access'=>'3075034521.5d9aa6a.284ff8339f694dbfac8f265bf3e93c8a',
               'userid'=>'3075034521',
               'tagged'=>'pxaas-add-ons',
               'resolution'=>'thumbnail',
               'columns'=>'3'
         ), $atts));

        if($get == 'tagged'){
            $getval = $tagged;
        }else if($get == 'user'){
            $getval = $userid;
        }else {
            $getval = 'popular';
        }

        ob_start();

        ?>

        <div class="cththemes-instafeed grid-cols-<?php echo esc_attr($columns );?>" data-limit="<?php echo esc_attr($limit );?>" data-get="<?php echo esc_attr($get );?>" data-getval="<?php echo esc_attr($getval );?>" data-client="<?php echo esc_attr($clientid );?>" data-access="<?php echo esc_attr($access );?>" data-res="<?php echo esc_attr($resolution );?>"><div class='cth-insta-thumb'><ul class="cththemes-instafeed-ul" id="<?php echo uniqid('cththemes-instafeed');?>"></ul></div></div>

        <?php

        $output = ob_get_clean();

        return $output;

    }

    //add_shortcode( 'pxaas_instagram', 'pxaas_instagram_sc' ); 
}

if(!function_exists('pxaas_subscribe_callback')) {

    function pxaas_subscribe_callback( $atts, $content="" ) {
        
        extract(shortcode_atts(array(
           'class'=>'',
           // 'title'=>'Newsletter',
           'message'=>__( '<p>Want to be notified when we launch a new template or an udpate. Just  send you a notification by email.</p>', 'pxaas-add-ons' ),
           'placeholder'=>__( 'Enter Your Email', 'pxaas-add-ons' ),
           'button'=>__( 'Get Started', 'pxaas-add-ons' ),
           'list_id' => '',
        ), $atts));

        $return = '';

        ob_start();
        ?>
        
        <div class="subscribe-form <?php echo esc_attr( $class ); ?>">
            <!-- <?php echo $message; ?> -->
            <form class="pxaas_mailchimp-form p-relative">
                <input id="subscribe-email" class="enteremail radius-50px pl-15px pt-7px pb-7px no-border w-100" name="email" type="email" required="required" placeholder="<?php echo esc_html( $placeholder ); ?>">
                
                <label class="subscribe-agree-label" for="subscribe-agree-checkbox">
                    <input id="subscribe-agree-checkbox" type="checkbox" name="sub-agree-terms" required="required" value="1"><?php _e( 'I agree with the <a href="#" target="_blank">Privacy Policy</a>', 'pxaas-add-ons' ); ?>
                </label>

                <button  type="submit" class="subscribe-button op-absolute"><?php echo esc_html( $button ); ?></button>

                <label for="subscribe-email" class="subscribe-message"></label>
                <?php if ( function_exists( 'wp_create_nonce' ) ) { ?>
                <input type="hidden" name="_nonce" value="<?php echo wp_create_nonce( 'pxaas_mailchimp' ) ?>">
                <?php } 
                if($list_id !=''){ ?>
                <input type="hidden" name="_list_id" value="<?php echo esc_attr( $list_id ); ?>">
                <?php } ?>
            </form>
        </div>
        <?php  
        return ob_get_clean();
            
    }
        
    add_shortcode( 'pxaas_subscribe', 'pxaas_subscribe_callback' ); //Mailchimp

}

if(!function_exists('pxaas_tweets_sc')){
    function pxaas_tweets_sc($atts, $content = ''){

        extract(shortcode_atts(array(
               'username' =>'',
               'list'=>'',
               'hashtag'=>'',
               'count'=>'3',
               'list_ticker'=>'no',
               'follow_url' => '',
               'extraclass'=>''
         ), $atts));

        if ( $count =='')
            $count = 3;

        ob_start();

        ?>
        <div class="tweet pxaas-tweet tweet-count-<?php echo esc_attr($count );?> tweet-ticker-<?php echo esc_attr($list_ticker );?>" data-username="<?php echo esc_attr($username );?>" data-list="<?php echo esc_attr($list );?>" data-hashtag="<?php echo esc_attr($hashtag );?>" data-ticker="<?php echo esc_attr($list_ticker );?>" data-count="<?php echo esc_attr($count );?>"></div>
        <?php 
        if($follow_url != '') : ?>
        <div class="follow-wrap">
            <a  href="<?php echo esc_url( $follow_url );?>" target="_blank" class="twiit-button"><i class="fa fa-twitter"></i><?php _e(' Follow Us','pxaas-add-ons');?></a>  
        </div>
        <?php endif;?>
        <?php

        $output = ob_get_clean();

        return $output;

    }

    add_shortcode( 'pxaas_tweets', 'pxaas_tweets_sc' ); 
}


if(!function_exists('pxaas_addons_login_logout_sc')){
    function pxaas_addons_login_logout_sc($atts, $content = ''){

        extract(shortcode_atts(array(
               'show_register' =>esc_html_x( 'no', 'Show register button: yes or no', 'pxaas-add-ons' ),
               'show_register_when_logged_in'=>'no',
               'style'=>'two',
               'extraclass'=>''
        ), $atts));
        
        $login_page_url = get_permalink( pxaas_addons_get_option('login_page') );
        if( pxaas_addons_get_option('custom_logreg_enable') == 'no' ) {
            $login_page_url = wp_login_url( get_permalink( pxaas_addons_get_option('login_redirect_page') ) );
        }
        ob_start();
        if(is_user_logged_in()): ?>
            <div class="nav-item log-out">
                <a class="nav-link flex-center bg-blue radius-5px transition-3" href="<?php echo wp_logout_url( $login_page_url ); ?>"><?php esc_html_e( 'Log Out', 'pxaas-add-ons' ) ?></a>
            </div>
            
        <?php else: ?>  
            <div class="nav-item log-in">
                <a class="nav-link flex-center bg-blue radius-5px transition-3" href="<?php echo esc_url( $login_page_url );?>"><?php esc_html_e( 'Log In', 'pxaas-add-ons' ) ?></a>
            </div>
        <?php endif;
        $output = ob_get_clean();
        return $output;

    }

    add_shortcode( 'pxaas_login', 'pxaas_addons_login_logout_sc' ); 
}

function pxaas_addons_get_error_message( $error_code ) {
    switch ( $error_code ) {
        case 'empty_username':
            return __( 'ERROR: You do have an email address, right?', 'pxaas-add-ons' );
 
        case 'empty_password':
            return __( 'ERROR: You need to enter a password to login.', 'pxaas-add-ons' );
 
        case 'invalid_username':
            return __(
                "ERROR: We don't have any users with that email address. Maybe you used a different one when signing up?",
                'pxaas-add-ons'
            );
 
        case 'incorrect_password':
            $err = __(
                "ERROR: The password you entered wasn't quite right. <a href='%s'>Did you forget your password</a>?",
                'pxaas-add-ons'
            );
            return sprintf( $err, wp_lostpassword_url() );

        case 'email':
            return __( 'ERROR: The email address you entered is not valid.', 'pxaas-add-ons' );
     
        case 'email_exists':
            return __( 'ERROR: An account exists with this email address.', 'pxaas-add-ons' );

        case 'pass_coincide':
            return __( 'ERROR: You have not entered a password or password does not match.', 'pxaas-add-ons' );
         
        case 'closed':
            return __( 'ERROR: Registering new users is currently not allowed.', 'pxaas-add-ons' );

        case 'empty_username':
            return __( 'You need to enter your email address to continue.', 'pxaas-add-ons' );
         
        case 'invalid_email':
        case 'invalidcombo':
            return __( 'There are no users registered with this email address.', 'pxaas-add-ons' );

        default:
            break;
    }
     
    return __( 'An unknown error occurred. Please try again later.', 'pxaas-add-ons' );
}
function pxaas_addons_get_error_message_lost_pass( $error_code ) {
    switch ( $error_code ) {
        case 'empty_username':
            return __( 'You need to enter your email address to continue.', 'pxaas-add-ons' );
         
        case 'invalid_email':
        case 'invalidcombo':
            return __( 'There are no users registered with this email address.', 'pxaas-add-ons' );

        case 'expiredkey':
        case 'invalidkey':
            return __( 'The password reset link you used is not valid anymore.', 'pxaas-add-ons' );
         
        case 'password_reset_mismatch':
            return __( "The two passwords you entered don't match.", 'pxaas-add-ons' );
             
        case 'password_reset_empty':
            return __( "Sorry, we don't accept empty passwords.", 'pxaas-add-ons' );

        default:
            break;
    }
     
    return __( 'An unknown error occurred. Please try again later.', 'pxaas-add-ons' );
}


if(!function_exists('pxaas_addons_render_rigister_form')){
    function pxaas_addons_render_rigister_form( $attrs, $content = null ) {
        // Parse shortcode attributes
        $default_attrs = array( 'show_title' => false );
        $attrs = shortcode_atts( $default_attrs, $attrs );
     
        if ( is_user_logged_in() ) { ?>
            <h6 class="login-success"><?php esc_html_e( 'You are already signed in.', 'pxaas-add-ons' ); ?></h6>
        <?php } elseif ( ! get_option( 'users_can_register' ) ) { ?>
            <h6 class="register-f"><?php esc_html_e( 'Registering new users is currently not allowed.', 'pxaas-add-ons' ); ?></h6>
        <?php } else {
            $attrs['errors'] = array();
            if ( isset( $_REQUEST['register-errors'] ) ) {
                $error_codes = explode( ',', $_REQUEST['register-errors'] );
             
                foreach ( $error_codes as $error_code ) {
                    $attrs['errors'] []= pxaas_addons_get_error_message( $error_code );
                }
            }
            ?>
                <div class="welcome-page-register">
                    <?php if ( count( $attrs['errors'] ) > 0 ) : ?>
                        <?php foreach ( $attrs['errors'] as $error ) : ?>
                            <p class="login-error reg-error">
                                <?php echo $error; ?>
                            </p>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <h1><?php esc_html_e( 'Sign Up', 'pxaas-add-ons' );?></h1>
                    <h6 class="fw-400 mt-20px mb-10px color-666"><?php esc_html_e( 'with your social network', 'pxaas-add-ons' );?></h6>

                    <?php if ( shortcode_exists( 'fbl_login_button' ) || shortcode_exists( 'wordpress_social_login' ) ): ?>
                    <div class="soc-log fl-wrap">
                        <?php _e( '<p>For faster login or register use your social account.</p>', 'pxaas-add-ons' ); ?>
                        <?php if(shortcode_exists( 'fbl_login_button' )) echo do_shortcode( '[fbl_login_button redirect="" hide_if_logged="" size="large" type="continue_with" show_face="true"]' );?>

                        <?php if(shortcode_exists( 'wordpress_social_login' )) echo do_shortcode( '[wordpress_social_login]' ); ?>
                    </div>
                    <?php 
                        _e( '<div class="log-separator fl-wrap"><span>or</span></div>', 'pxaas-add-ons' );
                    endif; ?>
                    <h5 class="fw-400 mt-10px separator p-relative text-center">
                        <span class="bg-gray p-relative p-15px z-index-1"><?php esc_html_e( 'Or', 'pxaas-add-ons' ) ?></span>
                    </h5>

                    <form id="easybook-register" action="<?php echo wp_registration_url(); ?>" class="mt-30px main-register-form" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group p-relative">
                                    <label for="reg_username">
                                        <input id="reg_username" name="username" type="text" placeholder="Your Name" required="" class="d-block w-100" value="">
                                        <i class="fa fa-user fs-20 color-blue p-absolute"></i> 
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group p-relative">
                                    <label for="reg_email">
                                        <input id="reg_email" name="email" type="email" placeholder="Your Email" required="" class="d-block w-100" value="">
                                        <i class="fa fa-envelope fs-20 color-blue p-absolute"></i> 
                                    </label>
                                </div>
                                    
                            </div>
                        </div>
                        <div class="form-group p-relative">
                            <label for="reg_password">
                                <input id="reg_password" name="password" type="password" placeholder="Your Password" required="" class="d-inline-block w-100" value="">
                                <i class="fa fa-lock fs-20 color-blue p-absolute"></i> 
                            </label>
                        </div>
                        <div class="form-group p-relative">
                            <label for="reg_password_retype">
                                <input id="reg_password_retype" name="password_retype"  type="password" placeholder="Repeat Your Password" required="" class="d-inline-block w-100" value="">
                                <i class="fa fa-lock fs-20 color-blue p-absolute"></i> 
                            </label>
                        </div>
                        <div class="form-group mb-30px">
                            <label for="check" class="check">
                                <input id="check" type="checkbox" name="ma" value="male" class="w-auto h-auto" required=""><?php esc_html_e( '  you accept our ', 'pxaas-add-ons' ) ?><a href="#"  target="_blank"><?php esc_html_e( 'Terms  of Use', 'pxaas-add-ons' ) ?></a><?php esc_html_e( ' and our ', 'pxaas-add-ons' ) ?><a href="#"  target="_blank"><?php esc_html_e( 'Privacy Policy', 'pxaas-add-ons' ) ?></a>.  
                            </label>
                        </div>    
                            
                        <button type="submit" role="button" class="main-btn btn-3 before-gray"><?php esc_html_e( 'Send request', 'pxaas-add-ons' ) ?></button>

                        <?php
                            // this prevent automated script for unwanted spam
                            if ( function_exists( 'wp_nonce_field' ) ) 
                                wp_nonce_field( 'pxaas-register', '_regnonce' );
                        ?>

                    </form>
                    <?php  $login_page = get_permalink( pxaas_addons_get_option('login_page') ); ?>
                    <p><?php esc_html_e( 'Have an account?','pxaas-add-ons' ) ?><a href="<?php echo $login_page; ?>" class="d-inline-block mt-20px ml-10px"><?php esc_html_e( 'Login', 'pxaas-add-ons' ) ?></a></p>
                </div>
            <?php
        }
    }
    add_shortcode( 'pxaas-rigister-form', 'pxaas_addons_render_rigister_form' );
    add_shortcode( 'pxaas-register-form', 'pxaas_addons_render_rigister_form' );
}


if(!function_exists('pxaas_addons_render_login_form')){
    function pxaas_addons_render_login_form($attrs, $content = '') {
        ob_start();

        if ( is_user_logged_in() ) { ?>
            <h6 class="login-success"><?php esc_html_e( 'You are already signed in.', 'pxaas-add-ons' ); ?></h6>
        <?php } else { ?>
                <div class="welcome-page">
                    <?php if ( isset( $_REQUEST['checkemail'] ) && $_REQUEST['checkemail'] == 'confirm' ) : ?>
                        <p class="login-error login-info">
                            <?php _e( 'Check your email for a link to reset your password.', 'pxaas-add-ons' ); ?>
                        </p>
                    <?php endif; ?>

                    <?php if ( isset( $_REQUEST['login'] ) ) : 
                        $error_codes = explode( ',', $_REQUEST['login'] );
                        $errors= pxaas_addons_get_error_message( $error_codes ); ?>
                        <?php if($errors != ''): ?>
                            <p class="login-error">
                                <?php echo $errors; ?>
                            </p>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if ( isset( $_REQUEST['registered'] ) ) : ?>
                        <p class="login-error reg-success">
                            <?php
                                printf(
                                    __( 'You have successfully registered to <strong>%s</strong>. We have emailed your password to the email address you entered.', 'pxaas-add-ons' ),
                                    get_bloginfo( 'name' )
                                );
                            ?>
                        </p>
                    <?php endif; ?>

                    <h1><?php esc_html_e( 'Log in Now', 'pxaas-add-ons' );?></h1>
                    <p class="mb-50px"><?php esc_html_e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam', 'pxaas-add-ons' );?></p>
                    <form class="mt-30px mb-20px" method="post" action="<?php echo wp_login_url(); ?>">
                        <div class="form-group p-relative">
                            <label for="user_login">
                                <input id="user_login" name="log" type="text" placeholder="Your Email" class="d-block mb-20px" onclick="select()" value="" required="">
                                <i class="fa fa-envelope fs-20 color-blue p-absolute"></i> 
                            </label>
                        </div>
                        <div class="form-group p-relative">
                            <label for="user_pass">
                                <input id="user_pass" name="pwd" type="password" placeholder="Your Password" class="d-block mb-20px" onclick="select()" value="" required="">
                                <i class="fa fa-lock fs-20 color-blue p-absolute"></i> 
                            </label>
                        </div>
                        <div class="filter-tags">
                            <input name="rememberme" id="rememberme" value="true" type="checkbox">
                            <label for="rememberme"><?php esc_html_e( 'Remember me', 'pxaas-add-ons' );?></label>
                        </div>
                        <button  type="submit" role="button" class="main-btn btn-3 before-gray"><?php esc_html_e( 'Log In', 'pxaas-add-ons' );?></button>
                        <?php
                            // this prevent automated script for unwanted spam
                            if ( function_exists( 'wp_nonce_field' ) ) 
                                wp_nonce_field( 'pxaas-login', '_loginnonce' );
                        ?>
                        <?php 
                        $login_redirect_page = pxaas_addons_get_option('login_redirect_page');
                        if($login_redirect_page != 'cth_current_page' && is_numeric($login_redirect_page) )
                            $login_redirect_url = get_permalink( $login_redirect_page );
                        else 
                            $login_redirect_url = home_url( '/' );

                        ?>
                        <input type="hidden" name="redirection" value="<?php echo $login_redirect_url; ?>" />

                    </form>
                <?php  $register_page = get_permalink( pxaas_addons_get_option('register_page') ); ?>
                <a href="<?php echo $register_page; ?>" class="float-left mb-10px"><?php esc_html_e( 'Not a member? Sign up', 'pxaas-add-ons' );?></a>
                <a href="lost-password-page" class="float-right"><?php esc_html_e( 'Forget my password', 'pxaas-add-ons' );?></a>
                </div>
            <?php } ?>
        <?php
        $html = ob_get_contents();
        ob_end_clean();
     
        return $html;
    }
    
    add_shortcode( 'pxaas-login-form', 'pxaas_addons_render_login_form' );
}

if(!function_exists('pxaas_addons_render_password_lost_form')){
    function pxaas_addons_render_password_lost_form( $attrs, $content = null ) {
        // Parse shortcode attributes
        $default_attrs = array( 'show_title' => false );
        $attrs = shortcode_atts( $default_attrs, $attrs );
     
        if ( is_user_logged_in() ) { ?>
            <h6 class="login-success"><?php esc_html_e( 'You are already signed in.', 'pxaas-add-ons' ); ?></h6>
        <?php } else {
            $attrs['errors'] = array();
            if ( isset( $_REQUEST['errors'] ) ) {
                $error_codes = explode( ',', $_REQUEST['errors'] );
             
                foreach ( $error_codes as $error_code ) {
                    $attrs['errors'] []= pxaas_addons_get_error_message_lost_pass( $error_code );
                }
            }
            ?>
                <div class="welcome-page-lost-pass">
                    <?php if ( count( $attrs['errors'] ) > 0 ) : ?>
                        <?php foreach ( $attrs['errors'] as $error ) : ?>
                            <p class="login-error">
                                <?php echo $error; ?>
                            </p>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <i class="fa fa-lock fs-50 color-blue mb-10px"></i>
                    <h2><?php esc_html_e( 'Forget Your Password !', 'pxaas-add-ons' ) ?></h2>
                    <p class="mb-50px"><?php esc_html_e( 'Don'."'".'t worry ! enter your email and we will send you a rest', 'pxaas-add-ons' ) ?></p>
                    <form class="reset-password-form custom-form mt-30px" action="<?php echo wp_lostpassword_url(); ?>" method="post">
                        <div class="form-group p-relative">
                            <label for="user_login">
                                <input id="user_login" name="user_login" type="email" placeholder="Your Email" class="d-block mb-20px" value="" required>
                                <i class="fa fa-envelope fs-20 color-blue p-absolute"></i> 
                            </label>
                        </div>
                        <button type="submit" role="button" class="main-btn btn-3 before-gray"><?php esc_html_e( 'Send Request', 'pxaas-add-ons' ); ?></button>
                        
                        
                    </form>
                    <?php $login_page = get_permalink( pxaas_addons_get_option('login_page') ); ?>
                    <a href="<?php echo $login_page; ?>" class="d-block ml-10px mt-20px mb-10px"><?php esc_html_e( 'Log In', 'pxaas-add-ons' ); ?></a>
                </div>
            <?php
        }
    }
    add_shortcode( 'pxaas-password-lost-form', 'pxaas_addons_render_password_lost_form' );
}

if(!function_exists('pxaas_addons_render_password_reset_form')){
    function pxaas_addons_render_password_reset_form( $attrs, $content = null ) {
        // Parse shortcode attributes
        $default_attrs = array( 'show_title' => false );
        $attrs = shortcode_atts( $default_attrs, $attrs );
     
        if ( is_user_logged_in() ) {
            return __( 'You are already signed in.', 'pxaas-add-ons' );
        } else {
            if ( isset( $_REQUEST['login'] ) && isset( $_REQUEST['key'] ) ) {
                $attrs['login'] = $_REQUEST['login'];
                $attrs['key'] = $_REQUEST['key'];
     
                // Error messages
                $errors = array();
                if ( isset( $_REQUEST['error'] ) ) {
                    $error_codes = explode( ',', $_REQUEST['error'] );
     
                    foreach ( $error_codes as $code ) {
                        $errors []= pxaas_addons_get_error_message_lost_pass( $code );
                    }
                }
                $attrs['errors'] = $errors;
                ?>
                    <div class="welcome-page-reset-pass">
                        <i class="fa fa-lock fs-50 color-blue mb-10px"></i>
                        <h2><?php esc_html_e( 'Reset Your Password !', 'pxaas-add-ons' ) ?></h2>
                        <p class="mb-50px"><?php esc_html_e( 'Don'.'t worry ! enter your email and we will send you a rest', 'pxaas-add-ons' ) ?></p>

                            <div class="form-group p-relative">
                                <label for="reg_password">
                                    <input id="reg_password" name="password" type="password" placeholder="New password" required="" class="d-inline-block w-100" value="">
                                    <i class="fa fa-lock fs-20 color-blue p-absolute"></i> 
                                </label>
                            </div>
                            <div class="form-group p-relative">
                                <label for="reg_password_retype">
                                    <input id="reg_password_retype" name="password_retype"  type="password" placeholder="Repeat new password" required="" class="d-inline-block w-100" value="">
                                    <i class="fa fa-lock fs-20 color-blue p-absolute"></i> 
                                </label>
                            </div>
                            <button type="submit" role="button" class="main-btn btn-3 before-gray"><?php esc_html_e( 'Reset Password', 'pxaas-add-ons' ); ?></button>
                            
                            
                        </form>
                        <?php  $login_page = get_permalink( pxaas_addons_get_option('login_page') ); ?>
                        <a href="<?php echo $login_page; ?>" class="d-block ml-10px mt-20px mb-10px"><?php esc_html_e( 'Log In', 'pxaas-add-ons' ); ?></a>
                    </div>
                <?php
            } else {
                return __( 'Invalid password reset link.', 'pxaas-add-ons' );
            }
        }
    }
    add_shortcode( 'pxaas-password-reset-form', 'pxaas_addons_render_password_reset_form' );
}

// add_action( 'login_form_login', 'redirect_to_custom_login' );
// function redirect_to_custom_login() {
//     if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {
//         $redirect_to = isset( $_REQUEST['redirect_to'] ) ? $_REQUEST['redirect_to'] : null;
     
//         if ( is_user_logged_in() ) {
//             $this->redirect_logged_in_user( $redirect_to );
//             exit;
//         }
 
//         // The rest are redirected to the login page
//         $login_url = home_url( 'member-login' );
//         if ( ! empty( $redirect_to ) ) {
//             $login_url = add_query_arg( 'redirect_to', $redirect_to, $login_url );
//         }
 
//         wp_redirect( $login_url );
//         exit;
//     }
// }



function pxaas_addons_print_admin_notices($messages = array()){

    add_action( 'admin_notices', function() use ($messages) {
        ?>
        <div class="updated notice is-dismissible">
            <?php echo implode("<br>", $messages); ?>
        </div>
        <?php
    } );
}

