<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Section_Title extends Widget_Base {
// Feature Box
    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'section_title';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Section Title', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'OUR CUSTOMERS FEEDBACK',
                'label_block' => true, 
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXTAREA, // WYSIWYG,
                'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                // 'show_label' => false,
            ]
        );
        $this->add_control(
            'loca_sec',
            [
                'label'   => __( 'Location Section', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'section-title-center',
                'options' => [
                    'section-title-right'  => __( 'Right', 'pxaas-add-ons' ),
                    'section-title-center' => __( 'Center', 'pxaas-add-ons' ),
                    'section-title-left'   => __( 'Left', 'pxaas-add-ons' ),
                ],
            ]
        );
        $this->add_control(
            'sec_style_not_icon',
            [
                'label'       => __( 'Section Title Style When Not Used Icon', 'pxaas-add-ons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => '',
                'options'     => [
                    ''      => __( 'Default', 'pxaas-add-ons' ),
                    '1'  => __( 'Style - 1', 'pxaas-add-ons' ),
                    '2'  => __( 'Style - 2(White)', 'pxaas-add-ons' ),
                    '3'  => __( 'Style - 3', 'pxaas-add-ons' ),
                    'sub'=> __( 'Style - 4(Subscribe)', 'pxaas-add-ons' ),
                    '5'  => __( 'Style - 5(Blue)', 'pxaas-add-ons' ),
                    '5-1'=> __( 'Style - 5(1)(Orange)', 'pxaas-add-ons' ),
                    '6'  => __( 'Style - 6(Only Title)', 'pxaas-add-ons' ),

                    '10'  => __( 'Style - Framed(1)', 'pxaas-add-ons' ),
                    '11'  => __( 'Style - Framed(2)', 'pxaas-add-ons' ),
                    '12'  => __( 'Style - Framed(3)', 'pxaas-add-ons' ),

                ],
            ]
        );
        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $loca_sec = $settings['loca_sec'];

        $sec_style = $settings['sec_style_not_icon'];

        $css_classes_wrap = array(
            'section-title',
            $loca_sec,
        );
        $css_class_wrap = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes_wrap ) ) );
        if($sec_style === '') {
            $css_class_wrap .= "";
        }else {
            $css_class_wrap .= ' section-type-not-icon-'.$sec_style;
        }
        $css_h3 = "title-h";

        if($sec_style === '1') {
            $css_class_wrap .= "";
            $css_h3 .= " fw-600";
        }
        if($sec_style === '2') {
            $css_class_wrap .= "";
            $css_h3 .= " color-fff";
        }
        if($sec_style === '3') {
            $css_class_wrap .= " mt-50px";
            $css_h3 .= "";
        }
        if($sec_style === 'sub') {
            $css_class_wrap .= "";
            $css_h3 .= " color-fff";
        }
        if($sec_style === '5') {
            $css_class_wrap .= " mt-25px";
            $css_h3 .= " color-blue";
        }
        if($sec_style === '5-1') {
            $css_class_wrap .= " mt-25px";
            $css_h3 .= " color-orange";
        }
        if($sec_style === '6') {
            $css_class_wrap .= "";
            $css_h3 .= "";
        }


        if($sec_style === '10') {
            $css_class_wrap .= " mt-25px mb-25px";
            $css_h3 .= " mb-20px color-orange bg-orange-lh pt-5px pb-5px pl-15px pr-15px radius-50px d-inline-block";
        }
        if($sec_style === '11') {
            $css_class_wrap .= "";
            $css_h3 .= " fs-30 bg-gray d-inline-block radius-50px pt-5px pb-5px pl-25px pr-25px color-blue mb-10px";
        }
        if($sec_style === '12') {
            $css_class_wrap .= " mt-25px mb-25px";
            $css_h3 .= " fs-20 fw-400 d-inline-block pt-10px pb-10px pr-25px pl-25px radius-50px bg-green-lh color-green";
        }
        ?>
        <div class="<?php echo esc_attr($css_class_wrap );?>">
            <?php if($settings['title']!= ''): ?>
                <h3 class="<?php echo $css_h3; ?>"><?php echo $settings['title']; ?></h3>
            <?php endif; ?>
            <?php if($settings['content']!='' && $sec_style != '6'): ?>
                <!-- <div class="sec-desc">
                    <p>
                        <?php echo $settings['content']; ?>
                    </p>
                </div> -->
                <p class="title-p"><?php echo $settings['content']; ?></p>
            <?php endif; ?> 
        </div>
        
        <?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

    // }

   
   

}

// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

