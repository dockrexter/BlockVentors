<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Our_Partners extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'our_partners';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Our Partners', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'eicon-gallery-justified';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.10
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_images',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'images',
            [
                'label' => __( 'Partners Images', 'pxaas-add-ons' ),
                'type' => Controls_Manager::GALLERY,
                'default' => array(
                    array('id' => 3765,'url'=>''),
                    array('id' => 3764,'url'=>''),
                    array('id' => 3755,'url'=>''),
                    array('id' => 3759,'url'=>''),
                    array('id' => 3753,'url'=>''),
                    array('id' => 3754,'url'=>''),
                ),
                'description' => __( 'Please select at least 6 image!).', 'pxaas-add-ons' )
            ]
        );

        $this->add_control(
            'links',
            [
                'label' => __( 'Partner Links', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXTAREA, // WYSIWYG,
                'default' => '#|#|#|#|#|#',
                // 'show_label' => false,
                'description' => __( 'Enter links for each partner (Note: divide links with linebreaks (Enter) or | and no spaces).', 'pxaas-add-ons' )
            ]
        );

        $this->add_control(
            'is_external',
            [
                'label' => __( 'Is External Links', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );

        

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();

        
        $css_classes = array(
            'row partner-wrap',
        );

        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

        if(is_array($settings['images']) && !empty($settings['images'])):

            $seppos = strpos(strip_tags($settings['links']), "|");
            if($seppos !== false){
                $partnerslinks = explode("|", strip_tags($settings['links']));
            }else{
                $partnerslinks = preg_split( '/\r\n|\r|\n/', strip_tags($settings['links']) );//explode("\n", $content);
            }
        ?>
            <div class="<?php echo esc_attr($css_class );?>">
                <?php foreach ($settings['images'] as $key => $image) { ?>
                    <div class="col-md-2 col-sm-4">
                        <div class="mt-25px mb-25px text-center">
                            <?php 
                                if(isset($partnerslinks[$key])){
                                    $target = $settings['is_external'] == 'yes'? ' target="_blank"':'';
                                    echo '<a href="'.esc_url($partnerslinks[$key] ).'"'.$target.'>';
                                }else{
                                    echo '<a href="javascript:void(0);">';
                                }
                            ?>
                                <?php echo wp_get_attachment_image( $image['id'],  'partner' );?>
                            </a>
                        </div>
                    </div>
                <?php } ?>
            </div>
        <?php
        endif;
    }

    protected function _content_template() {}

   
    

}
