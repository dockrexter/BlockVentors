<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Hero_Slider extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'hero_slider';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Hero Slider', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'eicon-accordion';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.10
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section',
            [
                'label' => __( 'Slider Content', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'slider_item',
            [
                'label' => __( 'Section Content', 'pxaas-add-ons' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [
                        'sec_title' => __( 'Section #1', 'pxaas-add-ons' ),
                        'sec_content' => __( 'Section Item content.', 'pxaas-add-ons' ),
                    ],
                ],
                'description' => __( 'If more than 1 item appears, a slider will appear.', 'pxaas-add-ons' ),
                'fields' => [
                    [
                        'name'  => 'list_title',
                        'label' => __( 'Title', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => 'OUR CUSTOMERS FEEDBACK',
                        'label_block' => true, 
                    ],
                    [
                        'name'  => 'list_content',
                        'label' => __( 'Content', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXTAREA, // WYSIWYG,
                        'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                        // 'show_label' => false,
                    ],
                    [
                        'name'  => 'show_btn',
                        'label_block' => false,
                                'label' => __( 'Show Button', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::SWITCHER,
                        'default' => 'no',
                        'label_on' => __( 'Show', 'pxaas-add-ons' ),
                        'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                        'return_value' => 'yes',
                    ],
                    [
                        'name'  => 'btn_name',
                        'label' => __( 'Button Name', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => 'Get Started',
                        'label_block' => false,
                        'condition' => [
                            'show_btn' => 'yes',
                        ],
                    ],
                    [
                        'name'  => 'link',
                        'label' => __( 'URL', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::URL,
                        'default' => [
                            'url' => '#',
                            'is_external' => '',
                        ],
                        'condition' => [
                            'show_btn' => 'yes',
                        ],
                    ],
                    [
                        'name'  => 'show_btn_video',
                        'label_block' => false,
                                'label' => __( 'Show Button Video', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::SWITCHER,
                        'default' => 'no',
                        'label_on' => __( 'Show', 'pxaas-add-ons' ),
                        'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                        'return_value' => 'yes',
                    ],
                    [
                        'name'  => 'bg_btn_video',
                        'label'   => __( 'Background button video', 'pxaas-add-ons' ),
                        'type'    => Controls_Manager::SELECT,
                        'default' => 'btn-orange',
                        'options' => [
                            'btn-orange'    => __( 'Orange', 'pxaas-add-ons' ),
                            ''   => __( 'Blue', 'pxaas-add-ons' ),
                        ],
                        'condition' => [
                            'show_btn_video' => 'yes',
                        ],
                    ],
                    [
                        'name'  => 'btn_video_name',
                        'label' => __( 'Button Video Name', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => 'Watch Our Video',
                        'label_block' => false,
                        'condition' => [
                            'show_btn_video' => 'yes',
                        ],
                    ],
                    [
                        'name'  => 'link_video',
                        'label' => __( 'URL Video', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::URL,
                        'default' => [
                            'url' => '#',
                            'is_external' => '',
                        ],
                        'condition' => [
                            'show_btn_video' => 'yes',
                        ],
                    ],
                    [
                        'name'  => 'add_infos',
                        'label' => __( 'Additional Infos', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXTAREA, // WYSIWYG,
                        'default' => '',
                        // 'show_label' => false,
                    ],
                    [
                        'name'  => 'local_img',
                        'label'   => __( 'Location Image', 'pxaas-add-ons' ),
                        'type'    => Controls_Manager::SELECT,
                        'default' => 'right',
                        'options' => [
                            'left'    => __( 'Left', 'pxaas-add-ons' ),
                            'right'   => __( 'Right', 'pxaas-add-ons' ),
                        ],
                    ],
                    [
                        'name' => 'image',
                        'label' => __( 'Choose Image', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::MEDIA,
                        'default' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'name'  => 'list_class',
                        'label' => __( 'Css Class', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => '',
                        'label_block' => false,
                    ],

                ],
            'title_field' => '{{{ list_title }}}',
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'slider_op',
            [
                'label' => __( 'Slider Option', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'slider_style',
            [
                'label' => __( 'Style', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1'   => __( 'Style - 1', 'pxaas-add-ons' ),
                    '1-1' => __( 'Style - 1(1)', 'pxaas-add-ons' ),
                    '2'   => __( 'Style - 2', 'pxaas-add-ons' ),
                    '3'   => __( 'Style - 3', 'pxaas-add-ons' ),
                ],
                'default' => '1',
                // 'description' => esc_html__("Number of posts to show (-1 for all).", 'pxaas-add-ons'),   
            ]
        );
        $this->add_control(
            'is_external',
            [
                'label' => __( 'Is External Links', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'bg_ball',
            [
                'label' => __( 'Bubbles appear and frame', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => [
                    'slider_style' => '2',
                ],
                'description' => __( 'Frames and bubbles appear on the left background', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'btn_name_2',
            [
                'label' => __( 'Button Name 2', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Learn More',
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'link_btn_2',
            [
                'label' => __( 'URL 2', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'gmail',
            [
                'label' => __( 'Name Gmail', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'example@mail.com',
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'link_gmail',
            [
                'label' => __( 'URL Gmail', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'phone',
            [
                'label' => __( 'URL Phone', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '+01 234 567 890',
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'text',
            [
                'label' => __( 'Title Social Link', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Follow Us:',
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'link_fb',
            [
                'label' => __( 'URL FaceBook', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'link_twitter',
            [
                'label' => __( 'URL Twitter', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'link_behance',
            [
                'label' => __( 'URL Behance', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'link_rss',
            [
                'label' => __( 'URL RSS', 'pxaas-add-ons' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => '',
                ],
                'condition' => [
                    'slider_style' => array('1-1','2'),
                ],
            ]
        );
        $this->add_control(
            'respon',
            [
                'label' => __( 'Responsive', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '320:1,768:1,992:1,1200:1',
                'condition' => [
                    'slider_style' => '1',
                ],
            ]
        );
        $this->add_control(
            'speed',
            [
                'label' => __( 'Speed', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '650',
                'label_block' => true,
                // 'description' => __("Enter Member ids to show, separated by a comma. Leave empty to show all.", 'pxaas-add-ons')
                'condition' => [
                    'slider_style' => '1',
                ],
            ]
        );
        $this->add_control(
            'au_play',
            [
                'label' => __( 'Auto Play', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => [
                    'slider_style' => '1',
                ],
            ]
        );
        $this->add_control(
            'loop',
            [
                'label' => __( 'Loop', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => [
                    'slider_style' => '1',
                ],
            ]
        );
        $this->add_control(
            'navi',
            [
                'label' => __( 'Show Navigation', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => [
                    'slider_style' => '1',
                ],
            ]
        );
        $this->add_control(
            'dots',
            [
                'label' => __( 'Show Dots', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
                'condition' => [
                    'slider_style' => '1',
                ],
            ]
        );
        $this->end_controls_section();

    }

    protected function render( ) {
        $settings = $this->get_settings();
        $count_item = count($settings['slider_item']);
        $target = $settings['is_external'] == 'yes'? ' target="_blank"':'';

        $dataArr = array();
        $dataArr['smartSpeed'] = (int)$settings['speed'];
        if($settings['au_play'] == 'yes') $dataArr['autoplay'] = true;
        if($settings['loop'] == 'yes') 
            $dataArr['loop'] = true;
        else 
            $dataArr['loop'] = false;
        if($settings['navi'] == 'yes') 
            $dataArr['nav'] = true;
        else 
            $dataArr['nav'] = false;
        if($settings['dots'] == 'yes') 
            $dataArr['dots'] = true;
        else 
            $dataArr['dots'] = false;
        if(!empty($settings['respon'])){
            // $css_classes .=' resp-ena';
            $dataArr['responsive'] = $settings['respon'];
        }
        // if(is_numeric($spacing)) $dataArr['margin'] = (int)$spacing;
        
        ?>
        <?php if($settings['slider_style'] === '1') { ?>
            <?php if($count_item > 1) { ?>
                <div class="hero-slider single-slider owl-carousel owl-theme" data-options='<?php echo json_encode($dataArr);?>'>
                    <?php foreach ($settings['slider_item'] as $key => $val) { ?>
                    <div class="item">
                        <div class="row sec-padding flex-center">
                            <?php if($val['local_img'] === 'left') { ?>
                                <div class="col-md-6 text-center">
                                    <img alt="img" src="<?php if($val['image']['url']!= '') echo $val['image']['url']; ?>">
                                </div>
                                <div class="col-md-6 mb-50px z-index-1">
                                    <h1 class="mb-20px"><?php echo $val['list_title'] ?></h1>
                                    <p><?php echo $val['list_content'] ?></p>
                                    <?php if($val['show_btn']==='yes'): ?>
                                        <a class="main-btn btn-3 mt-40px mr-10px before-gray" href="<?php if($val['link']['url']!= '') echo $val['link']['url']; ?>" <?php echo $target ?>><?php echo $val['btn_name'] ?></a>
                                    <?php endif; ?>
                                    <?php if($val['show_btn_video']==='yes'): ?>
                                        <a class="play-trigger main-btn btn-3 mt-30px before-gray<?php echo ' '.$val['bg_btn_video']; ?>" href="<?php if($val['link_video']['url']!= '') echo $val['link_video']['url']; ?>" <?php echo $target ?> data-lity><i class="fa fa-play mr-5px"></i><?php echo $val['btn_video_name'] ?></a>
                                    <?php endif; ?>

                                    <?php echo $val['add_infos']; ?>
                                </div>
                            <?php }else { ?>
                                <div class="col-md-6 mb-50px z-index-1">
                                    <h1 class="mb-20px"><?php echo $val['list_title'] ?></h1>
                                    <p><?php echo $val['list_content'] ?></p>
                                    <?php if($val['show_btn']==='yes'): ?>
                                        <a class="main-btn btn-3 mt-40px mr-10px before-gray" href="<?php if($val['link']['url']!= '') echo $val['link']['url']; ?>" <?php echo $target ?>><?php echo $val['btn_name'] ?></a>
                                    <?php endif; ?>
                                    <?php if($val['show_btn_video']==='yes'): ?>
                                        <a class="play-trigger main-btn btn-3 mt-30px before-gray<?php echo ' '.$val['bg_btn_video']; ?>" href="<?php if($val['link_video']['url']!= '') echo $val['link_video']['url']; ?>" <?php echo $target ?> data-lity><i class="fa fa-play mr-5px"></i><?php echo $val['btn_video_name'] ?></a>
                                    <?php endif; ?>

                                    <?php echo $val['add_infos']; ?>

                                </div>
                                <div class="col-md-6 text-center">
                                    <img alt="img" src="<?php if($val['image']['url']!= '') echo $val['image']['url']; ?>">
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <?php } ?>
                </div>  
            <?php }else { ?>
                <div class="sec-hero-slider">
                    <?php foreach ($settings['slider_item'] as $key => $val) { ?>
                        <div class="row sec-padding flex-center" >
                            <?php if($val['local_img'] === 'left') { ?>
                                <div class="col-md-6 text-center">
                                    <img alt="img" src="<?php if($val['image']['url']!= '') echo $val['image']['url']; ?>">
                                </div>
                                <div class="col-md-6 mb-50px z-index-1">
                                    <h1 class="mb-20px"><?php echo $val['list_title'] ?></h1>
                                    <p><?php echo $val['list_content'] ?></p>
                                    <?php if($val['show_btn']==='yes'): ?>
                                        <a class="main-btn btn-3 mt-40px mr-10px before-gray" href="<?php if($val['link']['url']!= '') echo $val['link']['url']; ?>" <?php echo $target ?>><?php echo $val['btn_name'] ?></a>
                                    <?php endif; ?>
                                    <?php if($val['show_btn_video']==='yes'): ?>
                                        <a class="play-trigger main-btn btn-3 mt-30px before-gray<?php echo ' '.$val['bg_btn_video']; ?>" href="<?php if($val['link_video']['url']!= '') echo $val['link_video']['url']; ?>" <?php echo $target ?> data-lity><i class="fa fa-play mr-5px"></i><?php echo $val['btn_video_name'] ?></a>
                                    <?php endif; ?>

                                    <?php echo $val['add_infos']; ?>
                                </div>
                            <?php }else { ?>
                                <div class="col-md-6 mb-50px z-index-1">
                                    <h1 class="mb-20px"><?php echo $val['list_title'] ?></h1>
                                    <p><?php echo $val['list_content'] ?></p>
                                    <?php if($val['show_btn']==='yes'): ?>
                                        <a class="main-btn btn-3 mt-40px mr-10px before-gray" href="<?php if($val['link']['url']!= '') echo $val['link']['url']; ?>" <?php echo $target ?>><?php echo $val['btn_name'] ?></a>
                                    <?php endif; ?>
                                    <?php if($val['show_btn_video']==='yes'): ?>
                                        <a class="play-trigger main-btn btn-3 mt-30px before-gray<?php echo ' '.$val['bg_btn_video']; ?>" href="<?php if($val['link_video']['url']!= '') echo $val['link_video']['url']; ?>" <?php echo $target ?> data-lity><i class="fa fa-play mr-5px"></i><?php echo $val['btn_video_name'] ?></a>
                                    <?php endif; ?>

                                    <?php echo $val['add_infos']; ?>
                                </div>
                                <div class="col-md-6 text-center">
                                    <img alt="img" src="<?php if($val['image']['url']!= '') echo $val['image']['url']; ?>">
                                </div>
                            <?php } ?>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?> 
        <?php }elseif($settings['slider_style'] === '1-1') { ?>
            <?php foreach ($settings['slider_item'] as $key => $val) { ?>
                <div class="row sec-padding flex-center">
                    <div class="col-md-6 mb-50px z-index-1">
                        <h1 class="mb-20px"><?php echo $val['list_title'] ?></h1>
                        <p><?php echo $val['list_content'] ?></p>
                        <?php if($val['show_btn']==='yes'): ?>
                            <a class="main-btn btn-3 btn-green mt-30px mr-15px" href="<?php if($val['link']['url']!= '') echo $val['link']['url']; ?>" <?php echo $target ?>><?php echo $val['btn_name'] ?></a>
                        <?php endif; ?>
                        <?php if($val['show_btn_video']==='yes'): ?>
                            <a class="play-trigger main-btn btn-3 mt-30px before-gray<?php echo ' '.$val['bg_btn_video']; ?>" href="<?php if($val['link_video']['url']!= '') echo $val['link_video']['url']; ?>" <?php echo $target ?>><?php echo $val['btn_video_name'] ?></a>
                        <?php endif; ?>
                        <a class="main-btn btn-2 btn-green mt-10px mr-15px" href="<?php if($settings['link_btn_2']['url']!= '') echo $settings['link_btn_2']['url']; ?>" <?php echo $target ?>><?php echo $settings['btn_name_2']; ?></a>
                        
                        <?php echo $val['add_infos']; ?>

                        <span class="mt-25px d-block mb-10px">
                            <span class="mr-10px fs-16"><i class="fa fa-envelope color-green"></i> <a href="<?php echo $settings['link_gmail']['url']; ?>" <?php echo $target ?>><?php echo $settings['gmail']; ?> </a></span>
                            <span class="fs-16"><i class="fa fa-phone color-green"></i><?php echo ' '.$settings['phone'] ?></span>
                        </span>
                        <span><?php echo $settings['text'] ?>
                            <a href="<?php if($settings['link_fb']['url']!= '') echo $settings['link_fb']['url']; ?>" class="color-green color-blue-hvr mr-5px" <?php echo $target ?>><i class="fa fa-facebook"></i> </a> 
                            <a href="<?php if($settings['link_twitter']['url']!= '') echo $settings['link_twitter']['url']; ?>" class="color-green color-blue-hvr mr-5px" <?php echo $target ?>><i class="fa fa-twitter"></i> </a> 
                            <a href="<?php if($settings['link_behance']['url']!= '') echo $settings['link_behance']['url']; ?>" class="color-green color-blue-hvr mr-5px" <?php echo $target ?>><i class="fa fa-behance"></i> </a> 
                            <a href="<?php if($settings['link_rss']['url']!= '') echo $settings['link_rss']['url']; ?>" class="color-green color-blue-hvr mr-5px" <?php echo $target ?>><i class="fa fa-rss"></i> </a> 
                        </span>
                    </div>
                    <div class="col-md-6">
                        <img alt="img" src="<?php if($val['image']['url']!= '') echo $val['image']['url']; ?>">
                    </div>
                </div>
            <?php } ?>
        <?php }elseif($settings['slider_style'] === '2') { ?>
            <?php foreach ($settings['slider_item'] as $key => $val) { ?>
                <div class="full-width container">
                    <div class="row hero-slider-wrap-1 sec-padding flex-center text-center">
                        <div class="col-md-8  mb-50px z-index-1">
                            <h1 class="mb-20px"><?php echo $val['list_title'] ?></h1>
                            <p><?php echo $val['list_content'] ?></p>
                            <?php if($val['show_btn']==='yes'): ?>
                                <a class="main-btn btn-3 btn-green mt-30px mr-15px" href="<?php if($val['link']['url']!= '') echo $val['link']['url']; ?>" <?php echo $target ?>><?php echo $val['btn_name'] ?></a>
                            <?php endif; ?>
                            <?php if($val['show_btn_video']==='yes'): ?>
                                <a class="play-trigger main-btn btn-3 mt-30px before-gray<?php echo ' '.$val['bg_btn_video']; ?>" href="<?php if($val['link_video']['url']!= '') echo $val['link_video']['url']; ?>" <?php echo $target ?>><?php echo $val['btn_video_name'] ?></a>
                            <?php endif; ?>
                            <a class="main-btn btn-2 btn-green mt-10px mr-15px" href="<?php if($settings['link_btn_2']['url']!= '') echo $settings['link_btn_2']['url']; ?>" <?php echo $target ?>><?php echo $settings['btn_name_2']; ?></a>
                            <br>

                            <?php echo $val['add_infos']; ?>

                            <span class="mt-25px d-inline-block">
                                <span class="mr-20px d-inline-block mb-10px fs-16"><i class="fa fa-envelope color-green"></i> <a href="<?php echo $settings['link_gmail']['url']; ?>" <?php echo $target ?>><?php echo $settings['gmail']; ?></a> </span>
                                <span class="mr-20px d-inline-block mb-10px fs-16"><i class="fa fa-phone color-green"></i><?php echo ' '.$settings['phone'] ?></span>
                            </span>
                            <span><?php echo $settings['text'] ?>
                                <a href="<?php if($settings['link_fb']['url']!= '') echo $settings['link_fb']['url']; ?>" class="color-green color-blue-hvr mr-5px" <?php echo $target ?>><i class="fa fa-facebook"></i> </a> 
                                <a href="<?php if($settings['link_twitter']['url']!= '') echo $settings['link_twitter']['url']; ?>" class="color-green color-blue-hvr mr-5px" <?php echo $target ?>><i class="fa fa-twitter"></i> </a> 
                                <a href="<?php if($settings['link_behance']['url']!= '') echo $settings['link_behance']['url']; ?>" class="color-green color-blue-hvr mr-5px" <?php echo $target ?>><i class="fa fa-behance"></i> </a> 
                                <a href="<?php if($settings['link_rss']['url']!= '') echo $settings['link_rss']['url']; ?>" class="color-green color-blue-hvr mr-5px" <?php echo $target ?>><i class="fa fa-rss"></i> </a> 
                            </span>
                        </div>
                    </div>
                </div>

                <?php if($settings['bg_ball'] === 'yes') { ?>
                    <div class="shape-3 bg-gray p-absolute"></div>
                    <div class="shape-2 bg-gray p-absolute"></div>
                    <div class="shape-4 bg-gray p-absolute wow fadeInUp" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;"></div>
                    <div class="shape-5 bg-gray p-absolute wow fadeInUp" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;"></div>
                    <div class="shape-6 bg-gray p-absolute"></div>
                <?php } ?>
            <?php } ?>

        <?php }else { ?>
            <?php foreach ($settings['slider_item'] as $key => $val) { ?>
                <div class="hero-slider-wrap-2 container text-center">
                    <div class="welcome-text">
                        <h1 class="mb-20px color-fff"><?php echo $val['list_title'] ?></h1>
                        <p class="color-aaa"><?php echo $val['list_content'] ?></p>
                        <?php if($val['show_btn']==='yes'): ?>
                            <a class="main-btn btn-1 mt-10px mr-10px before-gray" href="<?php if($val['link']['url']!= '') echo $val['link']['url']; ?>" <?php echo $target ?>><?php echo $val['btn_name'] ?></a>
                        <?php endif; ?>
                        <?php if($val['show_btn_video']==='yes'): ?>
                            <a class="play-trigger main-btn btn-3 mt-10px before-gray<?php echo ' '.$val['bg_btn_video']; ?>" href="<?php if($val['link_video']['url']!= '') echo $val['link_video']['url']; ?>" <?php echo $target ?> data-lity=""><i class="fa fa-play mr-5px"></i><?php echo $val['btn_video_name'] ?></a>
                        <?php endif; ?>

                        <?php echo $val['add_infos']; ?>
                        
                    </div>
                </div>
            <?php } ?>

        <?php } ?>
        <?php
    }

    // protected function _content_template() {}
    // end _content_template



}
