<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */




function pxaas_addons_register_cpt_CTH_Testi() {
    
    $labels = array( 
        'name' => __( 'Testimonials', 'pxaas-add-ons' ),
        'singular_name' => __( 'Testimonial', 'pxaas-add-ons' ),
        'add_new' => __( 'Add New Testimonial', 'pxaas-add-ons' ),
        'add_new_item' => __( 'Add New Testimonial', 'pxaas-add-ons' ),
        'edit_item' => __( 'Edit Testimonial', 'pxaas-add-ons' ),
        'new_item' => __( 'New Testimonial', 'pxaas-add-ons' ),
        'view_item' => __( 'View Testimonial', 'pxaas-add-ons' ),
        'search_items' => __( 'Search Testimonials', 'pxaas-add-ons' ),
        'not_found' => __( 'No Testimonials found', 'pxaas-add-ons' ),
        'not_found_in_trash' => __( 'No Testimonials found in Trash', 'pxaas-add-ons' ),
        'parent_item_colon' => __( 'Parent Testimonial:', 'pxaas-add-ons' ),
        'menu_name' => __( 'PXaas Testimonials', 'pxaas-add-ons' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => false,
        'description' => __( 'List Testimonials', 'pxaas-add-ons' ),
        'supports' => array( 'title', 'editor', 'thumbnail'/*,'comments', 'post-formats'*/),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-format-chat', 
        'show_in_nav_menus' => false,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => false,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array( 'slug' => __('testimonial','pxaas-add-ons') ),
        'capability_type' => 'post'
    );

    register_post_type( 'cth_testi', $args );
}
// Register Service 
add_action( 'init', 'pxaas_addons_register_cpt_CTH_Testi' );

function pxaas_addons_cth_testi_columns_head($defaults) {
    $defaults['thumbnail'] = __( 'Thumbnail', 'pxaas-add-ons' );
    $defaults['rating'] = __( 'Rating', 'pxaas-add-ons' );
    $defaults['id'] = __( 'ID', 'pxaas-add-ons' );
    return $defaults;
}

// CUSTOM POSTS
function pxaas_addons_cth_testi_columns_content($column_name, $post_ID) {
    if ($column_name == 'id') {
        echo $post_ID;
    }
    if ($column_name == 'thumbnail') {
        echo get_the_post_thumbnail( $post_ID, 'thumbnail', array('style'=>'width:100px;height:auto;') );
    }
    if ($column_name == 'rating') {
        $rated = get_post_meta($post_ID, '_cth_testim_rate', true );
        if($rated != '' && $rated != 'no'){
            $ratedval = floatval($rated);
            echo '<ul class="star-rating">';
            for ($i=1; $i <= 5; $i++) { 
                if($i <= $ratedval){
                    echo '<li><i class="testimfa testimfa-star"></i></li>';
                }else{
                    if($i - 0.5 == $ratedval){
                        echo '<li><i class="testimfa testimfa-star-half-o"></i></li>';
                    }else{
                        echo '<li><i class="testimfa testimfa-star-o"></i></li>';
                    }
                }
                
            }
            echo '</ul>';
        }else{
            esc_html_e('Not Rated','pxaas-add-ons' );
        }
    }
}


add_filter('manage_cth_testi_posts_columns', 'pxaas_addons_cth_testi_columns_head', 10);
add_action('manage_cth_testi_posts_custom_column', 'pxaas_addons_cth_testi_columns_content', 10, 2);



function pxaas_addons_cth_testi_add_meta_box($post) {
    add_meta_box(
        'testi_socials',
        __( 'Socials', 'pxaas-add-ons' ),
        'pxaas_addons_cth_testi_meta_box_socials_callback',
        'cth_testi',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes_cth_testi', 'pxaas_addons_cth_testi_add_meta_box' );
function pxaas_addons_cth_testi_meta_box_socials_callback($post, $metabox){
    // Add a nonce field so we can check for it later.
    wp_nonce_field( 'addons-fields', '_cth_nonce' );

    $socials = get_post_meta( $post->ID, P_META_PREFIX.'socials', true );
    ?>
    <div class="custom-form">
        <div class="repeater-fields-wrap repeater-socials"  data-tmpl="tmpl-user-social">
            <div class="repeater-fields">
            <?php 
            if(!empty($socials)){
                foreach ($socials as $key => $social) {
                    pxaas_addons_get_template_part('templates-inner/social',false, array('index'=>$key,'name'=>$social['name'],'url'=>$social['url']));
                }
            }
            ?>
            </div>
            <button class="btn addfield" type="button"><?php  esc_html_e( 'Add Social','pxaas-add-ons' );?></button>
        </div>
    </div>
    <?php
}

/**
 * Save post metadata when a post is saved.
 *
 * @param int $post_id The post ID.
 * @param post $post The post object.
 * @param bool $update Whether this is an existing post being updated or not.
 */
function pxaas_addons_save_cth_testi_meta( $post_id, $post, $update ) {

    /*
     * We need to verify this came from our screen and with proper authorization,
     * because the save_post action can be triggered at other times.
     */

    // If this is just a revision, don't send the email.
    if ( wp_is_post_revision( $post_id ) )
        return;

    // Check if our nonce is set.
    if ( ! isset( $_POST['_cth_nonce'] ) ) {
        return;
    }

    // Verify that the nonce is valid.
    if ( ! wp_verify_nonce( $_POST['_cth_nonce'], 'addons-fields' ) ) {
        return;
    }

    // If this is an autosave, our form has not been submitted, so we don't want to do anything.
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    

    // Check the user's permissions.
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    if(isset($_POST['socials'])){
        update_post_meta( $post_id, P_META_PREFIX.'socials', $_POST['socials'] );
    }
}
add_action( 'save_post_cth_testi', 'pxaas_addons_save_cth_testi_meta', 10, 3 );

