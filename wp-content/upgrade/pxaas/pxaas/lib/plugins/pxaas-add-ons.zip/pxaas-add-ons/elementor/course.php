<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Course extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    
    */
    public function get_name() {
        return 'course';
    }

    // public function get_id() {
    //      return 'header-search';
    // }

    public function get_title() {
        return __( 'Course', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Process Grid', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'course_content',
            [
                'label' => __( 'Process Items', 'pxaas-add-ons' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [
                        'course_title' => __( 'Design', 'pxaas-add-ons' ),
                        'step' => '01',
                        'icon' => 'im im-edit',
                        'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore .',
                    ],
                    
                ],
                'fields' => [
                    [
                        'name' => 'step',
                        'label'   => __( 'Process step', 'pxaas-add-ons' ),
                        'type'    => Controls_Manager::TEXT,
                        'default' => '01',
                        // 'min'     => 1,
                        // 'step'    => 1,
                        // 'label_block' => false,
                    ],
                    
                    // [
                    //     'name' => 'icon',
                    //     'label'       => __( 'Icon from https://iconmonstr.com/iconicfont/ (ex: "im im-store")', 'pxaas-add-ons' ),
                    //     'type'        => Controls_Manager::TEXT,
                    //     'default'     => '',
                    //     'label_block' => true,
                    // ],
                    [
                        'name' => 'icon',
                        'label'       => __( 'Icon from https://iconmonstr.com/iconicfont/ (ex: "im im-store")', 'pxaas-add-ons' ),
                        'type'        => Controls_Manager::SELECT2,
                        'options' => pxaas_addons_get_icon_iconmonstr_select2(),
                        'default' => '',
                        'label_block' => true,
                    ],
                    [
                        'name' => 'list_title',
                        'label'       => __( 'Title', 'pxaas-add-ons' ),
                        'type'        => Controls_Manager::TEXT,
                        'default'     => 'Design',
                        'label_block' => true,
                    ],
                    [
                        'name' => 'content',
                        'label'     => __( 'Content', 'pxaas-add-ons' ),
                        'type'      => Controls_Manager::TEXTAREA, // WYSIWYG,
                        'default'   => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.',
                        // 'show_label' => false,
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );  

        
        $this->end_controls_section();



        $this->start_controls_section(
            'course_op',
            [
                'label' => __( 'Process Layout', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'course_col',
            [
                'label'   => __( 'Columns Layout', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'col-md-4 ',
                'options' => [
                    'col-md-12 '  => __( 'One Column', 'pxaas-add-ons' ),
                    'col-md-6 '   => __( 'Two Column', 'pxaas-add-ons' ),
                    'col-md-4 '   => __( 'Three Column', 'pxaas-add-ons' ),
                    'col-md-3 '   => __( 'Four Column', 'pxaas-add-ons' ),
                    'col-md-2 '   => __( 'Six Column', 'pxaas-add-ons' ),
                ],
            ]
        );
        $this->add_control(
            'view_course',
            [
                'label'   => __( 'Process Style', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    ''    => __( 'Style 1', 'pxaas-add-ons' ),
                    '2'   => __( 'Style 2', 'pxaas-add-ons' ),
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $content = $settings['course_content'];
        
        $css_classes = array(
            'text-center',
            'row',
        );

        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );

        if($settings['view_course'] !== '') {
            $css_class.= ' how-work-s2 course-element-'.$settings['view_course'];
        }else {
            $css_class.= ' how-work-s1 course-element';
        }

        ?>
        <div class="<?php echo esc_attr($css_class); ?>">
            <?php $number_order = 1; ?>
            <?php foreach ($settings['course_content'] as $key => $val) { ?>
                <?php if($settings['view_course'] === '') { // process style 1 ?>
                    <div class="<?php echo $settings['course_col']; ?> how-box text-center">
                        <div class="p-relative pr-15px pl-15px mt-25px mb-25px">
                            <div class="how-icon p-relative d-inline-block mb-25px">
                                <i class="<?php echo $val['icon']; ?> fs-35 p-relative color-blue radius-50 d-inline-block transition-3"></i>
                                <?php if(!empty($val['step'])): ?><h6 class="how-number p-absolute color-fff bg-blue radius-50"><?php echo $val['step']; ?></h6><?php endif; ?>
                            </div>
                            <?php if(!empty($val['list_title'])): ?><h4 class="proc-title"><?php echo $val['list_title']; ?></h4><?php endif; ?>
                            <?php if(!empty($val['content'])): ?><div class="process-desc"><?php echo $val['content']; ?></div><?php endif; ?>
                        </div>
                    </div>
                <?php }else { ?>
                    <div class="<?php echo $settings['course_col']; ?>course-item mt-25px mb-25px">
                        <span class="d-inline-block fs-30 fw-600 radius-10px mb-20px bg-orange-lh color-orange p-relative transition-3">
                            <?php if($number_order < 10) { echo '0'.$number_order; }else{ echo $number_order;} ?>
                        </span>
                        <h4 class="mb-10px"><?php echo $val['list_title']; ?></h4>
                        <p><?php echo $val['content']; ?></p>
                    </div>
                <?php } ?>
                <?php $number_order += 1; ?>
            <?php } ?>
        </div>
<?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

}


// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

