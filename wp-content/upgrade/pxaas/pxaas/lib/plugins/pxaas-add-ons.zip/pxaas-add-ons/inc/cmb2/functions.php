<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



/* cmb2 dependency field */
function pxaas_cmb2_admin_scripts() {
    // Adding custom admin scripts file
    wp_enqueue_script( 'pxaas_cmb2_admin', PXAAS_ADD_ONS_DIR_URL . 'inc/assets/depends_cmb2.js', array( 'jquery' ));

    // Registering and adding custom admin css
    wp_register_style( 'pxaas_cmb2_admin', PXAAS_ADD_ONS_DIR_URL . 'inc/assets/depends_cmb2.css', false, '1.0.0' );
    wp_enqueue_style( 'pxaas_cmb2_admin' ); 
}

add_action( 'admin_enqueue_scripts', 'pxaas_cmb2_admin_scripts' );





add_action( 'cmb2_admin_init', 'pxaas_cmb2_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 */
function pxaas_cmb2_sample_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = '_cth_';

    /**
     * Initiate Post metabox
     */
    $post_cmb = new_cmb2_box( array(
        'id'            => 'post_options',
        'title'         => esc_html__( 'Post Format Options', 'pxaas-add-ons' ),
        'object_types'  => array( 'post' ), // Post type
        'context'       => 'normal',// normal, side and advanced
        'priority'      => 'high',// default, high and low - core
        'show_names'    => true, // Show field names on the left
    ) );

    $post_cmb->add_field( array(
        'name' => esc_html__('Post Slider and Gallery Images', 'pxaas-add-ons' ),
        'id'   => $prefix . 'post_slider_images',
        'type' => 'file_list',
        'preview_size' => array( 150, 150 ), // Default: array( 50, 50 )
    ) );

    $post_cmb->add_field( array(
        'name' => esc_html__('Gallery Columns', 'pxaas-add-ons' ),
        'desc' => esc_html__('For Gallery post format only.','pxaas-add-ons'),
        'id'   => $prefix . 'gallery_cols',
        'type'    => 'select',
        'default'=>'three',
        'options' => array(
            'one' => esc_html__( 'One column', 'pxaas-add-ons' ),
            'two'   => esc_html__( 'Two columns', 'pxaas-add-ons' ),
            'three'   => esc_html__( 'Three columns', 'pxaas-add-ons' ),
            'four'   => esc_html__( 'Four columns', 'pxaas-add-ons' ),
            'five'   => esc_html__( 'Five columns', 'pxaas-add-ons' ),
            
        ),
    ) );

    $post_cmb->add_field( array(
        'name' => esc_html__('Single Image', 'pxaas-add-ons' ),
        'id'   => $prefix . 'single_image',
        'type' => 'file',
        'preview_size' => array( 150, 150 ), // Default: array( 50, 50 )
    ) );

    $post_cmb->add_field( array(
        'name' => esc_html__('Testimonial', 'pxaas-add-ons' ),
        'id'   => $prefix . 'quote_testimo',
        'type' => 'textarea_small',
    ) );


    $post_cmb->add_field( array(
        'name'       => esc_html__('Embed for Post Format', 'pxaas-add-ons' ),
        'desc'       => wp_kses(__('Enter a youtube, twitter, or instagram URL. Supports services listed at <a href="http://codex.wordpress.org/Embeds">http://codex.wordpress.org/Embeds</a>.', 'pxaas-add-ons' ),array('a'=>array('href'=>array()))),
        'id'   => $prefix . 'embed_video',
        'type' => 'oembed',
    ) );


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Initiate Page metabox
     */
    $page_cmb = new_cmb2_box( array(
        'id'            => 'des_header',
        'title'         => esc_html__('Page Layout Options - For normal page template only', 'pxaas-add-ons' ),
        'object_types'  => array( 'page', 'post', 'cth_member', 'cth_project'), // Post type
        'context'       => 'normal',// normal, side and advanced
        'priority'      => 'high',// default, high and low - core
        'show_names'    => true, // Show field names on the left
    ) );

    $page_cmb->add_field( array(
            'name' => esc_html__( 'Theme Color', 'pxaas-add-ons' ),
            'id' => $prefix . 'theme_color',
            'type'             => 'select',
            'show_option_none' => false,
            'default'          => 'theme-color',
            'options' => array(
                'theme-color'    => esc_html__( 'Theme Color', 'pxaas-add-ons' ),
                'orange-color'   => esc_html__( 'Orange Color', 'pxaas-add-ons' ),
                'green-color'    => esc_html__( 'Green Color', 'pxaas-add-ons' ),
            ),
        ) );

    $page_cmb->add_field( array(
        'name' => esc_html__( 'Header Style', 'pxaas-add-ons' ),
        'id' => $prefix . 'header_style',
        'type'             => 'select',
        'show_option_none' => false,
        'default'          => 'default',
        'options' => array(
            'hidden'    => esc_html__( 'Hidden', 'pxaas-add-ons' ),
            'default'   => esc_html__('Default Style', 'pxaas-add-ons'),
            'special'   => esc_html__('Special Style - The listings will be white.', 'pxaas-add-ons'),
            'special-transparent' => esc_html__('Special Style - The listings will be dark color and background transparent.', 'pxaas-add-ons'),
        ),
    ) );

    $page_cmb->add_field( array(
        'name' => esc_html__('Show Header Content', 'pxaas-add-ons' ),
        'id'   => $prefix . 'show_header_content',
        'type'    => 'radio_inline',
        'default' => 'yes',
        'options' => array(
            'yes' => esc_html__( 'Yes', 'pxaas-add-ons' ),
            'no'  => esc_html__( 'No', 'pxaas-add-ons' ),
            
        ),
    ) );

    $page_cmb->add_field( array(
        'name' => esc_html__('Show Breadcrumbs', 'pxaas-add-ons' ),
        'id'   => $prefix . 'show_breadcrumbs_blog',
        'type'    => 'radio_inline',
        'default' => 'yes',
        'options' => array(
            'customizer' => esc_html__( 'Customizer value', 'pxaas-add-ons' ),
            'yes'        => esc_html__( 'Yes', 'pxaas-add-ons' ),
            'no'         => esc_html__( 'No', 'pxaas-add-ons' ),
        ),
    ) );

    $page_cmb->add_field( array(
        'name' => esc_html__('Show details at the top of the content', 'pxaas-add-ons' ),
        'id'   => $prefix . 'show_page_header',
        'type'    => 'radio_inline',
        'default' => 'yes',
        'options' => array(
            'customizer' => esc_html__( 'Customizer value', 'pxaas-add-ons' ),
            'yes' => esc_html__( 'Yes', 'pxaas-add-ons' ),
            'no'  => esc_html__( 'No', 'pxaas-add-ons' ),
            
        ),
        "description"   => esc_html__("Include title, description and image.", 'pxaas-add-ons')
    ) );

    $page_cmb->add_field( array(
        'name' => esc_html__('Header Image Background', 'pxaas-add-ons' ),
        'id'   => $prefix . 'page_header_bg',
        'type'    => 'file',
        // Optional:
        'options' => array(
            'url' => true, // Hide the text input for the url
            
        ),
    ) );

    $page_cmb->add_field( array(
        'name' => esc_html__('Images bottom header', 'pxaas-add-ons' ),
        'id'   => $prefix . 'img_bt_header',
        'type'    => 'file',
        'options' => array(
            'url' => true, // Hide the text input for the url
            
        ),
        "description"   => esc_html__("The default image is bb.png.", 'pxaas-add-ons')
    ) );

    $page_cmb->add_field( array(
        'name' => esc_html__( 'Title Header', 'pxaas-add-ons' ),
        'id'   => $prefix . 'title_header',
        'type' => 'text',
        'dependency'  => array(
            'element' => $prefix . 'show_page_title',
            'value'   => 'yes',
            'not_empty' => false,
        ),
    ) );

    $page_cmb->add_field( array(
        'name' => esc_html__('Header Additional Info', 'pxaas-add-ons' ),
        'id'   => $prefix . 'page_header_intro',
        'type' => 'textarea_small'
    ) );

    $page_cmb->add_field( array(
        'name' => esc_html__('Show section top footer', 'pxaas-add-ons' ),
        'id'   => $prefix . 'show_section_top_footer',
        'type'    => 'radio_inline',
        'default'=>'yes',
        'options' => array(
            'yes' => esc_html__( 'Yes', 'pxaas-add-ons' ),
            'no'   => esc_html__( 'No', 'pxaas-add-ons' ),
        ),
    ) );

    $page_cmb->add_field( array(
        'name' => esc_html__( 'Footer Style', 'pxaas-add-ons' ),
        'id' => $prefix . 'footer_style',
        'type'             => 'select',
        'show_option_none' => false,
        'default'          => 'use_global',
        'options' => array(
            'hidden' => esc_html__( 'Hidden', 'pxaas-add-ons' ),
            'use_global' => esc_html__( 'Customizer Value', 'pxaas-add-ons' ),
            'default' => esc_html__('Default Style', 'pxaas-add-ons'),
            'special' => esc_html__('Special Style', 'pxaas-add-ons'),
        ),
    ) );
    

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    $member_cmb2 = new_cmb2_box( array(
        'id'            => 'member_additional_mtb',
        'title'         => esc_html__('Member Details', 'pxaas-add-ons' ),
        'object_types'  => array( 'cth_member'), // Post type
        'context'       => 'normal',// normal, side and advanced
        'priority'      => 'high',// default, high and low - core
        'show_names'    => true, // Show field names on the left
    ) );
    $member_cmb2->add_field( array(
        'name' => esc_html__( 'Member job', 'pxaas-add-ons' ),
        'id'   => $prefix . 'member_job',
        'type' => 'text',
        'default'=>'Web Designer',
    ) );

    $member_cmb2->add_field( array(
        'name' => esc_html__( 'Member phone', 'pxaas-add-ons' ),
        'id'   => $prefix . 'member_phone',
        'type' => 'text',
        'default'=>'+01 234 456 789',
    ) );

    $member_cmb2->add_field( array(
        'name' => esc_html__( 'Member Email', 'pxaas-add-ons' ),
        'id'   => $prefix . 'member_email',
        'type' => 'text',
        'default'=>'example@mail.com',
    ) );

    $member_cmb2->add_field( array(
        'name' => esc_html__( 'Facebook URL', 'pxaas-add-ons' ),
        'id'   => $prefix . 'facebookurl',
        'type' => 'text_url',
        'default'=>'#!',
    ) );

    $member_cmb2->add_field( array(
        'name' => esc_html__( 'Twitter URL', 'pxaas-add-ons' ),
        'id'   => $prefix . 'twitterurl',
        'type' => 'text_url',
        'default'=>'#!',
    ) );
    $member_cmb2->add_field( array(
       'name' => esc_html__( 'Linkedin URL', 'pxaas-add-ons' ),
        'id'   => $prefix . 'linkedinurl',
        'type' => 'text_url',
        'default'=>'#!',
    ) );
    $member_cmb2->add_field( array(
       'name' => esc_html__( 'Pinterest URL', 'pxaas-add-ons' ),
        'id'   => $prefix . 'pinteresturl',
        'type' => 'text_url',
        'default'=>'#!',
    ) );
    $member_cmb2->add_field( array(
        'name' => esc_html__( 'Google+ URL', 'pxaas-add-ons' ),
        'id'   => $prefix . 'googleplusurl',
        'type' => 'text_url',
    ) );
    $member_cmb2->add_field( array(
       'name' => esc_html__( 'Instagram URL', 'pxaas-add-ons' ),
        'id'   => $prefix . 'instagramurl',
        'type' => 'text_url',
    ) );
    $member_cmb2->add_field( array(
       'name' => esc_html__( 'Youtube URL', 'pxaas-add-ons' ),
        'id'   => $prefix . 'youtubeurl',
        'type' => 'text_url',
    ) );
    $member_cmb2->add_field( array(
       'name' => esc_html__( 'Tumblr URL', 'pxaas-add-ons' ),
        'id'   => $prefix . 'tumblrurl',
        'type' => 'text_url',
    ) );

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Initiate Resumes metabox
     */
    $resume_cmb = new_cmb2_box( array(
        'id'            => 'resumes_mtb',
        'title'         => esc_html__('Resume Options', 'pxaas-add-ons' ),
        'object_types'  => array( 'cth_resume'), // Post type
        'context'       => 'normal',// normal, side and advanced
        'priority'      => 'high',// default, high and low - core
        'show_names'    => true, // Show field names on the left
    ) );

    $resume_cmb->add_field( array(
        'name' => esc_html__( 'Resume Date', 'pxaas-add-ons' ),
        'id' => $prefix . 'resume_date',
        'type'             => 'text',
        'default'          => '2017',
        
    ) );

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Initiate Testimonials metabox
     */
    $testim_cmb = new_cmb2_box( array(
        'id'            => 'testimonial_mtb',
        'title'         => esc_html__('Testimonial Meta', 'pxaas-add-ons' ),
        'object_types'  => array( 'cth_testi'), // Post type
        'context'       => 'normal',// normal, side and advanced
        'priority'      => 'high',// default, high and low - core
        'show_names'    => true, // Show field names on the left
    ) );

    $testim_cmb->add_field( array(
        'name' => esc_html__( 'Job', 'pxaas-add-ons' ),
        'id' => $prefix . 'job',
        'type'             => 'text',
        'default'          => '',
        
    ) );

    $testim_cmb->add_field( array(
        'name' => esc_html__( 'Rating Stars', 'pxaas-add-ons' ),
       
        'id' => $prefix . 'testim_rate',
        'type'             => 'select',
        'show_option_none' => false,
        'default'          => 'five',
        'options' => array(
            'no' => esc_html__( 'Not Rate', 'pxaas-add-ons' ),
            '1' => esc_html__( '1 Star', 'pxaas-add-ons' ),
            '1.5' => esc_html__( '1.5 Stars', 'pxaas-add-ons' ),
            '2' => esc_html__( '2 Stars', 'pxaas-add-ons' ),
            '2.5' => esc_html__( '2.5 Stars', 'pxaas-add-ons' ),
            '3' => esc_html__( '3 Stars', 'pxaas-add-ons' ),
            '3.5' => esc_html__( '3.5 Stars', 'pxaas-add-ons' ),
            '4' => esc_html__( '4 Stars', 'pxaas-add-ons' ),
            '4.5' => esc_html__( '4.5 Stars', 'pxaas-add-ons' ),
            '5' => esc_html__( '5 Stars', 'pxaas-add-ons' ),
            
        ),
    ) );

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Initiate User Profile metabox
     */
    $user_cmb = new_cmb2_box( array(
        'id'         => 'user_edit',
        'title'      => esc_html__( 'User Profile Metabox', 'pxaas-add-ons' ),
        'object_types'  => array( 'user' ), // Tells CMB to use user_meta vs post_meta
        'context'       => 'normal',// normal, side and advanced
        'priority'      => 'core',// default, high and low - core
        'show_names'    => true, // Show field names on the left
    ) );

    
    $user_cmb->add_field( array(
        'name' => esc_html__('Show User Info Block', 'pxaas-add-ons' ),
        // 'desc' => esc_html__('Select an image for resume grid view','pxaas-add-ons'),
        'id'   => $prefix . 'show_user_info',
        'type'    => 'radio_inline',
        'default'=>'yes',
        'options' => array(
            'yes' => esc_html__( 'Yes', 'pxaas-add-ons' ),
            'no'   => esc_html__( 'No', 'pxaas-add-ons' ),
            
        ),
    ) );

    $user_cmb->add_field( array(
        'name' => esc_html__( 'Facebook URL', 'pxaas-add-ons' ),
      
        'id'   => $prefix . 'facebookurl',
        'type' => 'text_url',
        
    ) );

    $user_cmb->add_field( array(
        'name' => esc_html__( 'Twitter URL', 'pxaas-add-ons' ),
        
        'id'   => $prefix . 'twitterurl',
        'type' => 'text_url',
        
    ) );
    $user_cmb->add_field( array(
        'name' => esc_html__( 'Google+ URL', 'pxaas-add-ons' ),
        
        'id'   => $prefix . 'googleplusurl',
        'type' => 'text_url',
        
    ) );
    $user_cmb->add_field( array(
       'name' => esc_html__( 'Linkedin URL', 'pxaas-add-ons' ),
        
        'id'   => $prefix . 'linkedinurl',
        'type' => 'text_url',
        
    ) );
    $user_cmb->add_field( array(
       'name' => esc_html__( 'Instagram URL', 'pxaas-add-ons' ),
        
        'id'   => $prefix . 'instagramurl',
        'type' => 'text_url',
        
    ) );
    $user_cmb->add_field( array(
       'name' => esc_html__( 'Tumblr URL', 'pxaas-add-ons' ),
        
        'id'   => $prefix . 'tumblrurl',
        'type' => 'text_url',
        
    ) );

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
    * Initiate Plan metabox
    */
    $plan_cmb = new_cmb2_box( array(
        'id'            => 'lplan_fields',
        'title'         => esc_html__('Plan Options', 'pxaas-add-ons' ),
        'object_types'  => array( 'lplan'), // Post type
        'context'       => 'normal',// normal, side and advanced
        'priority'      => 'high',// default, high and low - core
        'show_names'    => true, // Show field names on the left
    ) );

    // $plan_cmb->add_field( array(
    //     'name'          => esc_html__('Subtitle', 'pxaas-add-ons' ),
    //     // 'desc'          => esc_html__('', 'pxaas-add-ons' ),
    //     'default'       => '',
    //     'id'            => $prefix . 'subtitle',
    //     'type'          => 'text'
    // ) );
    

    $plan_cmb->add_field( array(
        'name'          => esc_html__('Price', 'pxaas-add-ons' ),
        'desc'          => esc_html__('Value 0 for free.', 'pxaas-add-ons' ),
        'default'       => '49',
        'id'            => $prefix . 'price',
        'type'          => 'text_small',
        // 'before_field'  => '$',
    ) );

    $plan_cmb->add_field( array(
        'name'          => esc_html__( 'Period', 'pxaas-add-ons' ),
        'desc'          => esc_html__( 'Expired period', 'pxaas-add-ons' ),
        'id'            => $prefix . 'period',
        'type'             => 'select',
        'show_option_none' => false,
        'default'          => 'month',
        'options'       => pxaas_add_ons_get_subscription_duration_units(),
    ) );
    $plan_cmb->add_field( array(
        'name'          => esc_html__('Interval', 'pxaas-add-ons' ),
        'desc'          => esc_html__('Numbers of PERIOD value which listing will be expired', 'pxaas-add-ons' ),
        'default'       => '1',
        'id'            => $prefix . 'interval',
        'type'          => 'text_small'
    ) );
    $plan_cmb->add_field( array(
        'name'          => esc_html__('Price of a year', 'pxaas-add-ons' ),
        'default'       => '1050',
        'id'            => $prefix . 'price_year',
        'type'          => 'text_small',
    ) );
    $plan_cmb->add_field( array(
        'name'          => esc_html__( 'Period', 'pxaas-add-ons' ),
        'desc'          => esc_html__( 'Expired period', 'pxaas-add-ons' ),
        'id'            => $prefix . 'period_year',
        'type'             => 'select',
        'show_option_none' => false,
        'default'          => 'year',
        'options'       => pxaas_add_ons_get_subscription_duration_units(),
    ) );
    // $plan_cmb->add_field( array(
    //     'name'          => esc_html__('Price Reduction', 'pxaas-add-ons' ),
    //     'desc'          => esc_html__('Value 0% to 100%.', 'pxaas-add-ons' ),
    //     'default'       => '5',
    //     'id'            => $prefix . 'price_sale',
    //     'type'          => 'text_small',
    // ) );
    $plan_cmb->add_field( array(
        'name'          => esc_html__('Prcing Icon Class', 'pxaas-add-ons' ),
        'desc'          => esc_html__('Take the page access class icon : https://fontawesome.com/', 'pxaas-add-ons' ),
        'default'       => 'fal fa-plane-alt',
        'id'            => $prefix . 'price_icon',
        'type'          => 'text_small',
    ) );
    



    $plan_cmb->add_field( array(
        'name' => esc_html__( 'Purchase URL', 'pxaas-add-ons' ),
        'id'   => $prefix . 'purchase_url',
        'type' => 'text_url',
        'default'       => '',
        // 'protocols' => array( 'http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet' ), // Array of allowed protocols
    ) );

    // $plan_cmb->add_field( array(
    //     'name'          => esc_html__('No Expire', 'pxaas-add-ons' ),
    //     'desc'          => esc_html__('Check this if subscription never expire.', 'pxaas-add-ons' ),
    //     'default'       => '0',
    //     'id'            => $prefix . 'lnever_expire',
    //     'type'          => 'checkbox'
    // ) );

    // $plan_cmb->add_field( array(
    //     'name'          => esc_html__('Listing Submission Limit', 'pxaas-add-ons' ),
    //     'desc'          => esc_html__('Numbers of listing who subscribe for this plan can submit.', 'pxaas-add-ons' ),
    //     'default'       => '1',
    //     'id'            => $prefix . 'llimit',
    //     'type'          => 'text_small'
    // ) );

    // $plan_cmb->add_field( array(
    //     'name'          => esc_html__('Unlimited Listing Submission', 'pxaas-add-ons' ),
    //     'desc'          => esc_html__('Check this if this plan has unlimited listing submission.', 'pxaas-add-ons' ),
    //     'default'       => '0',
    //     'id'            => $prefix . 'lunlimited',
    //     'type'          => 'checkbox'
    // ) );

    // $plan_cmb->add_field( array(
    //     'name'          => esc_html__('Featured Listings', 'pxaas-add-ons' ),
    //     'desc'          => esc_html__('Numbers of featured listings for this plan.', 'pxaas-add-ons' ),
    //     'default'       => '1',
    //     'id'            => $prefix . 'lfeatured',
    //     'type'          => 'text_small'
    // ) );

    // $plan_cmb->add_field( array(
    //     'name'          => esc_html__('Is Recurring', 'pxaas-add-ons' ),
    //     'desc'          => esc_html__('Check this if this plan required recurring payment.', 'pxaas-add-ons' ),
    //     'default'       => '0',
    //     'id'            => $prefix . 'is_recurring',
    //     'type'          => 'checkbox'
    // ) );

    //////////////////////////////////////////////////////////////
    
    // $plan_recurring_cmb = new_cmb2_box( array(
    //     'id'            => 'lplan_recurring_fields',
    //     'title'         => esc_html__('Recurring Options', 'pxaas-add-ons' ),
    //     'object_types'  => array( 'lplan'), // Post type
    //     'context'       => 'normal',// normal, side and advanced
    //     'priority'      => 'high',// default, high and low - core
    //     'show_names'    => true, // Show field names on the left
    // ) );

    // $plan_recurring_cmb->add_field( array(
    //     'name'          => esc_html__('Trial Interval', 'pxaas-add-ons' ),
    //     'desc'          => esc_html__('Value O for disable.', 'pxaas-add-ons' ),
    //     'default'       => '0',
    //     'id'            => $prefix . 'trial_interval',
    //     'type'          => 'text_small'
    // ) );

    // $plan_recurring_cmb->add_field( array(
    //     'name'          => esc_html__( 'Trial Period', 'pxaas-add-ons' ),
    //     // 'desc'          => esc_html__( 'Trial Expired period', 'easybook-add-ons' ),
    //     'id'            => $prefix . 'trial_period',
    //     'type'             => 'select',
    //     'show_option_none' => false,
    //     'default'          => 'day',
    //     'options'       => pxaas_add_ons_get_subscription_duration_units(),
        
    // ) );
}