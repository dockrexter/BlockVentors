<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Feature_Box extends Widget_Base {
// Feature Box
    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'feature_box';
    }

    // public function get_id() {
    //      return 'header-search';
    // }

    public function get_title() {
        return __( 'Feature Box', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Items', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'sec_item',
            [
                'label' => __( 'Item Content', 'pxaas-add-ons' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [
                        'sec_title' => __( 'Feature #1', 'pxaas-add-ons' ),
                        'sec_content' => __( 'Feature Item content.', 'pxaas-add-ons' ),
                    ],
                ],
                'fields' => [
                    [
                        'name'  => 'type_icon',
                        'label'   => __( 'Type Icon', 'pxaas-add-ons' ),
                        'type'    => Controls_Manager::SELECT,
                        'default' => '',
                        'options' => [
                            ''             => __( 'None', 'pxaas-add-ons' ),
                            'iconmonstr'   => __( 'Iconmonstr', 'pxaas-add-ons' ),
                            'et_line'      => __( 'Et-line', 'pxaas-add-ons' ),
                            'font_aw'      => __( 'FontAwesome', 'pxaas-add-ons' ),
                        ],
                    ],
                    [
                        'name'  => 'icon_1',
                        'label' => __( 'Icon - Iconmonstr', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::SELECT2,
                        'options' => pxaas_addons_get_icon_iconmonstr_select2(),
                        'default' => '',
                        'label_block' => false,
                        'condition' => [
                            'type_icon' => 'iconmonstr',
                        ],
                    ],
                    [
                        'name'  => 'icon_2',
                        'label' => __( 'Icon - Et-line', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::SELECT2,
                        'options' => pxaas_addons_get_icon_et_line_select2(),
                        'default' => '',
                        'label_block' => false,
                        'condition' => [
                            'type_icon' => 'et_line',
                        ],
                    ],
                    [
                        'name'  => 'icon_3',
                        'label' => __( 'Icon - FontAwesome', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::ICON,
                        'default' => 'fa fa-check',
                        'label_block' => true,
                        'condition' => [
                            'type_icon' => 'font_aw',
                        ],
                    ],
                    [
                        'name'  => 'list_top_title',
                        'label' => __( 'Feature on the title', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => 'Pxsaas',
                        'label_block' => true,
                    ],
                    [
                        'name'  => 'list_title',
                        'label' => __( 'Title', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => 'OUR CUSTOMERS FEEDBACK',
                        'label_block' => true, 
                    ],
                    [
                        'name'  => 'list_content',
                        'label' => __( 'Excerpts', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXTAREA, // WYSIWYG,
                        'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                        // 'show_label' => false,
                    ],
                    
                    [
                        'name'  => 'ani_type',
                        'label' => __( 'Entrance Animation', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::SELECT,
                        'default' => '',
                        'options' => pxaas_addons_get_animation(),
                        'label_block' => false,
                        
                    ],
                    [
                        'name'  => 'ani_delay',
                        'label' => __( 'Animation Delay (s)', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::NUMBER,
                        'default' => __( '0' , 'pxaas-add-ons' ),
                        'min'     => 0,
                        'step'    => 1,
                        'label_block' => false,
                    ],
                    [
                        'name' => 'link',
                        'label' => __( 'URL', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::URL,
                        'default' => [
                            'url' => '#',
                            'is_external' => '',
                        ],
                        'show_external' => true, // Show the 'open in new tab' button.
                    ],
                    [
                        'name' => 'is_external',
                        'label' => __( 'Is External Links', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::SWITCHER,
                        'default' => 'yes',
                        'label_on' => __( 'Show', 'pxaas-add-ons' ),
                        'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                        'return_value' => 'yes',
                    ],
                    [
                        'name'  => 'list_class',
                        'label' => __( 'Css Class', 'pxaas-add-ons' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => '',
                        'label_block' => true,
                        
                    ],

                ],
            'title_field' => '{{{ list_title }}}',
            ]
        );  
        $this->end_controls_section();


        $this->start_controls_section(
            'section_op',
            [
                'label' => __( 'Option', 'pxaas-add-ons' ),
            ]
        );
        $this->add_control(
            'sec_col',
            [
                'label'   => __( 'Column', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    ''            => __( 'Default', 'pxaas-add-ons' ),  
                    'col-md-12 '  => __( 'One Column', 'pxaas-add-ons' ),
                    'col-md-6 '   => __( 'Two Column', 'pxaas-add-ons' ),
                    'col-md-4 '   => __( 'Three Column', 'pxaas-add-ons' ),
                    'col-md-3 '   => __( 'Four Column', 'pxaas-add-ons' ),
                    'col-md-2 '   => __( 'Six Column', 'pxaas-add-ons' ),
                ],
            ]
        );
        $this->add_control(
            'loca_sec',
            [
                'label'   => __( 'Location', 'pxaas-add-ons' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'feature-box-center',
                'options' => [
                    'feature-box-left'   => __( 'Left', 'pxaas-add-ons' ),
                    'feature-box-center' => __( 'Center', 'pxaas-add-ons' ),
                    'feature-box-right'  => __( 'Right', 'pxaas-add-ons' ),
                ],
            ]
        );
        
        $this->add_control(
            'show_icon',
            [
                'label' => __( 'Show Icon', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'sec_style_not_icon',
            [
                'label'       => __( 'Style - Not Used Icon', 'pxaas-add-ons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => '1',
                'options'     => [
                    '1'     => __( 'Style - 1', 'pxaas-add-ons' ),
                    '1-1'   => __( 'Style - 2', 'pxaas-add-ons' ),
                    '1-2'   => __( 'Style - 3', 'pxaas-add-ons' ),
                    '1-2-1' => __( 'Style - 3(1)', 'pxaas-add-ons' ),
                    '1-3'   => __( 'Style - 4', 'pxaas-add-ons' ),
                    '1-3-1' => __( 'Style - 4(1)', 'pxaas-add-ons' ),
                    '1-9'   => __( 'Style - (Box - White)', 'pxaas-add-ons' ),
                    '1-9-1' => __( 'Style - (Box - Green)', 'pxaas-add-ons' ),
                ],
            ]
        );

        $this->add_control(
            'sec_style',
            [
                'label'       => __( 'Style - Used Icon', 'pxaas-add-ons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => '',
                'options'     => [
                    ''    => __( 'Default', 'pxaas-add-ons' ),
                    '1'   => __( '(Icon-top),Style - 1', 'pxaas-add-ons' ),
                    '1-1' => __( '(Icon-top),Style - 1(1)', 'pxaas-add-ons' ),

                    '2'   => __( '(Icon-top),Style - 2', 'pxaas-add-ons' ),
                    '2-1' => __( '(Icon-top),Style - 2(1)', 'pxaas-add-ons' ),
                    '2-2' => __( '(Icon-top),Style - 2(2)', 'pxaas-add-ons' ),
                    '3'   => __( '(Icon-top),Style - 3(Box)', 'pxaas-add-ons' ),
                    '3-1' => __( '(Icon-top),Style - 3(1)(Box)', 'pxaas-add-ons' ),
                    '3-2' => __( '(Icon-top),Style - 3(2)(Box)', 'pxaas-add-ons' ),

                    '4'   => __( '(Icon-top),Style - 4', 'pxaas-add-ons' ),
                    '4-1' => __( '(Icon-top),Style - 4(1)', 'pxaas-add-ons' ),
                    '4-2' => __( '(Icon-top),Style - 4(2)', 'pxaas-add-ons' ),
                    
                    '5'   => __( '(Icon-top),Style - 5', 'pxaas-add-ons' ),
                    '6'   => __( '(Icon-top),Style - 6(Box)', 'pxaas-add-ons' ),

                    '7'   => __( '(Icon-top),Style - 7', 'pxaas-add-ons' ),
                    '7-1' => __( '(Icon-top),Style - 7(1)', 'pxaas-add-ons' ),
                    '7-2' => __( '(Icon-top),Style - 7(2)', 'pxaas-add-ons' ),

                    '8'   => __( '(Icon-left),Style - 8(Box)', 'pxaas-add-ons' ),
                    '9'   => __( '(Icon-left),Style - 9', 'pxaas-add-ons' ),
                    
                    '10'  => __( '(Icon-left),Style - 10', 'pxaas-add-ons' ),
                    '10-1'=> __( '(Icon-left),Style - 10(1)', 'pxaas-add-ons' ),
                    
                    '11'  => __( '(Icon-left),Style - 11', 'pxaas-add-ons' ),
                    '11-1'=> __( '(Icon-left),Style - 11(1)', 'pxaas-add-ons' ),
                ],
                'description' => __("Select the icon for items.", 'pxaas-add-ons'),
                'condition' => [
                    'show_icon' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $show_icon = $settings['show_icon'];
        $loca_sec = $settings['loca_sec'];

        $sec_style = $settings['sec_style_not_icon'];
        $sec_style_icon = $settings['sec_style'];

        $css_classes_wrap = array(
            'feature-box',
            $loca_sec,
        );
        $css_class_wrap = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes_wrap ) ) );

        
        if($show_icon === 'yes'){
            if($sec_style_icon !== '') {
                $css_class_wrap .= ' feature-type-'.$sec_style_icon;
            }else {
                $css_class_wrap .= '';
            }
        }else {
            if($sec_style !== '') {
                $css_class_wrap .= ' feature-type-not-icon-'.$sec_style;
            }else {
                $css_class_wrap .= '';
            }
        }
            
        $css_classes = array(
            'icon',
        );
        $css_class = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes ) ) );
        $css_h3 = "";
        if($show_icon === 'yes'){
            if($sec_style_icon === '1') {
                $css_class .= ' fs-35 radius-50 mb-20px transition-3 icon-w-h-80 color-blue bg-gray';
                $css_class_wrap .= " mt-25px mb-25px";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '1-1') {
                $css_class .= ' fs-40 radius-50 mb-25px transition-3 icon-w-h-80 color-blue bg-gray';
                $css_class_wrap .= " mt-25px mb-25px radius-10px bg-fff";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '2') {
                $css_class .= ' fs-25 mb-20px text-center radius-50 icon-w-h-60 color-blue bg-gray';
                $css_class_wrap .= " mt-25px";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '2-1') {
                $css_class .= ' fs-25 mb-20px text-center radius-50 icon-w-h-60 color-orange bg-orange-lh';
                $css_class_wrap .= " mt-25px";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '2-2') {
                $css_class .= ' fs-25 mb-20px text-center radius-50 icon-w-h-60 color-green bg-green-lh';
                $css_class_wrap .= " mt-25px";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '3') {
                $css_class .= ' fs-50 mb-25px color-blue';
                $css_class_wrap .= " mt-25px mb-25px bg-fff transition-3 radius-10px bg-blue-hvr";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '3-1') {
                $css_class .= ' color-blue bg-gray fs-40 radius-50 mb-25px icon-w-h-80 transition-3';
                $css_class_wrap .= " mt-25px mb-25px bg-fff radius-10px";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '3-2') {
                $css_class .= ' fs-50 mb-25px color-blue';
                $css_class_wrap .= " mt-25px mb-25px bg-fff transition-3 radius-10px bg-gray bg-blue-hvr";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '4') {
                $css_class .= ' fs-30 mb-15px color-blue';
                $css_class_wrap .= " mb-40px";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '4-1') {
                $css_class .= ' fs-35 mb-20px color-orange';
                $css_class_wrap .= " mb-30px";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '4-2') {
                $css_class .= ' fs-35 mb-20px color-green';
                $css_class_wrap .= "";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '5') {
                $css_class .= ' fs-30 mb-20px text-center radius-10px color-orange bg-orange-lh';
                $css_class_wrap .= " mt-25px mb-25px p-30px radius-10px transition-4 bg-fff";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '6') {
                $css_class .= ' fs-25 p-15px radius-50 mb-20px p-absolute transition-3 color-blue bg-gray';
                $css_class_wrap .= " p-relative mt-25px mb-25px p-30px";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '7') {
                $css_class .= ' p-absolute fs-35 text-center radius-50 mb-25px transition-2 color-blue bg-gray';
                $css_class_wrap .= " pl-30px pr-30px mt-25px mb-25px";
                $css_span_icon = "pl-15px pr-15px pt-5px pb-5px radius-50px fw-400 fs-14 color-blue bg-gray";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '7-1') {
                $css_class .= ' p-absolute fs-35 text-center radius-50 mb-25px transition-2 color-green bg-green-lh';
                $css_class_wrap .= " pl-30px pr-30px mt-25px mb-25px";
                $css_span_icon = "pl-15px pr-15px pt-5px pb-5px radius-50px fw-400 fs-14 color-green bg-green-lh";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '7-2') {
                $css_class .= ' fs-40 text-center radius-50 mb-15px transition-2 color-fff';
                $css_class_wrap .= " pl-30px pr-30px mt-25px mb-25px";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '8') {
                $css_class .= ' fs-25 p-absolute text-center radius-10px color-orange bg-orange-lh';
                $css_class_wrap .= " mt-25px mb-25px p-relative mb-20px p-20px radius-10px transition-3";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '9') {
                $css_class .= ' fs-35 p-absolute text-center radius-10px color-orange bg-orange-lh';
                $css_class_wrap .= " p-relative mt-25px mb-25px p-30px radius-10px bg-fff";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '10') {
                $css_class .= ' fs-24 p-absolute text-center radius-50 transition-3 color-blue bg-gray';
                $css_class_wrap .= " mt-15px mb-15px p-relative";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '10-1') {
                $css_class .= ' fs-30 p-absolute text-center radius-50 transition-3 color-green bg-green-lh';
                $css_class_wrap .= " mt-15px mb-15px p-relative";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '11') {
                $css_class .= ' fs-35 p-absolute color-blue';
                $css_class_wrap .= " mt-10px mb-10px p-relative";
                $css_h3 .= " ";
            }
            if($sec_style_icon === '11-1') {
                $css_class .= ' fs-24 mr-5px p-absolute color-blue';
                $css_class_wrap .= " p-30px radius-10px mb-25px p-relative bg-fff";
                $css_h3 .= " ";
            }
        }else {
            if($sec_style === '1') {
                $css_class_wrap .= " mt-25px mb-25px";
                $css_span = "color-blue fs-18 fw-500";
                $css_h3 .= " mt-10px mb-15px fw-600";
            }
            if($sec_style === '1-1') {
                $css_class_wrap .= " mt-25px mb-25px";
                $css_span = "fs-20 fw-400 color-blue";
                $css_h3 .= " mb-15px mt-10px";
            }
            if($sec_style === '1-2') {
                $css_class_wrap .= " mt-25px mb-25px";
                $css_span = "color-blue bg-gray radius-50px pt-5px pb-5px pl-15px pr-15px";
                $css_h3 .= " mt-15px mb-10px";
            }
            if($sec_style === '1-2-1') {
                $css_class_wrap .= " mt-25px mb-25px";
                $css_span = "color-orange bg-orange-lh radius-50px pt-5px pb-5px pl-15px pr-15px";
                $css_h3 .= " mt-20px mb-15px";
            }
            if($sec_style === '1-3') {
                $css_class_wrap .= " mt-25px mb-25px";
                $css_span = "fs-20 fw-400 pt-10px pb-10px pr-25px pl-25px radius-50px bg-gray color-blue";
                $css_h3 .= " mb-15px mt-20px";
            }
            if($sec_style === '1-3-1') {
                $css_class_wrap .= " mt-25px mb-25px";
                $css_span = "fs-20 fw-400 pt-10px pb-10px pr-25px pl-25px radius-50px bg-green-lh color-green";
                $css_h3 .= " mb-15px mt-20px";
            }
            if($sec_style === '1-9') {
                $css_class_wrap .= " mt-25px pt-50px pb-50px pr-15px pl-15px radius-5px transition-2";
                $css_span = "";
                $css_h3 .= " transition-2 mb-12px";
            }
            if($sec_style === '1-9-1') {
                $css_class_wrap .= " pt-50px pb-50px pr-15px pl-15px bg-green radius-5px";
                $css_span = "";
                $css_h3 .= " color-fff mb-12px";
            }
        }

        if($settings['sec_col'] !== '') {
            $css_col = "".$settings['sec_col'];
        }else {
            $css_col = "no-column";
        }
        ?>
        <?php if($settings['sec_col'] !== '') { ?>
        <div class="row">
        <?php } ?> 
            <?php foreach ($settings['sec_item'] as $key => $val) { ?>
            <div class="<?php echo $css_col; ?>">
                <div class="<?php echo esc_attr($css_class_wrap );?> <?php echo $val['ani_type'] ?>" data-wow-delay="<?php echo $val['ani_delay'].'s'; ?>">
                    
                    <?php if($show_icon === 'yes'): ?>
                        <?php if($val['type_icon'] === 'iconmonstr'){ ?>
                            <i class="<?php echo $val['icon_1']; ?> <?php echo esc_attr($css_class );?>"></i>
                        <?php }elseif($val['type_icon'] === 'et_line') { ?>
                            <i class="<?php echo $val['icon_2']; ?> <?php echo esc_attr($css_class );?>"></i>
                        <?php }elseif($val['type_icon'] === 'font_aw') { ?>
                            <i class="<?php echo $val['icon_3']; ?> <?php echo esc_attr($css_class );?>"></i>
                        <?php } ?>
                    <?php endif; ?>
                    
                        <div class="sec-content">
                            <?php if($show_icon !== 'yes'): ?>
                                <?php if($sec_style !== '1-9' && $sec_style !== '1-9-1') { ?>
                                    <span class="<?php echo $css_span; ?>"><?php echo $val['list_top_title']; ?></span>
                                <?php } ?>
                            <?php endif; ?>
                            
                            <?php if($show_icon !== 'yes') { ?>
                                <?php if($val['list_title']!= ''): ?>
                                    <a class="feature-title" href="<?php if($val['link']['url']!= '') echo $val['link']['url']; ?>" <?php if($val['is_external'] == 'yes') echo 'target="_blank"'; ?>>
                                        <h3 class="title-h<?php echo $css_h3; ?>"> <?php echo $val['list_title']; ?></h3>
                                    </a>
                                <?php endif; ?>
                            <?php }else { ?>
                                <?php if($val['list_title']!= ''): ?>
                                    <a class="feature-title" href="<?php if($val['link']['url']!= '') echo $val['link']['url']; ?>" <?php if($val['is_external'] == 'yes') echo 'target="_blank"'; ?>>
                                        <h3 class="title-h<?php echo $css_h3; ?>"> <?php echo $val['list_title']; ?></h3>
                                    </a>
                                <?php endif; ?>
                            <?php } ?>
                            
                            <?php if($show_icon === 'yes'): ?>
                                <?php if($sec_style_icon === '7' || $sec_style_icon === '7-1' ) { ?>
                                    <span class="<?php echo $css_span_icon; ?>"><?php echo $val['list_top_title']; ?></span>
                                <?php } ?>
                            <?php endif; ?>

                            <?php if($val['list_content']!=''): ?>
                                <!-- <div class="sec-desc"> -->
                                    <p class="title-p"><?php echo $val['list_content']; ?></p>
                                <!-- </div> -->
                            <?php endif; ?>

                        </div>
                </div>
            </div>
            <?php } ?>
        <?php if($settings['sec_col'] !== '') { ?>   
        </div>
        <?php } ?>  
        
        <?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

    // }

   
   

}

// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

