<?php
/**
 * @package PXaas Add-Ons
 * @description A custom plugin for PXaas - Saas & Software Landing Page Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date 23-09-2019
 * @version 1.0.6
 * @copyright Copyright ( C ) 2014 - 2019 cththemes.com . All rights reserved.
 * @license GNU General Public License version 3 or later; see LICENSE
 */



namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CTH_Project_Information extends Widget_Base {

    /**
    * Get widget name.
    *
    * Retrieve alert widget name.
    *
    * @since 1.0.0
    * @access public
    *
    * @return string Widget name.
    */
    public function get_name() {
        return 'project_information';
    }

    // public function get_id() {
    //    	return 'header-search';
    // }

    public function get_title() {
        return __( 'Project Information', 'pxaas-add-ons' );
    }

    public function get_icon() {
        // Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
        return 'fa fa-font';
    }

    /**
    * Get widget categories.
    *
    * Retrieve the widget categories.
    *
    * @since 1.0.0
    * @access public
    *
    * @return array Widget categories.
    */
    public function get_categories() {
        return [ 'pxaas-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'btn_content',
            [
                'label' => __( 'Content', 'pxaas-add-ons' ),
            ]
        );

        $this->add_control(
            'name',
            [
                'label' => __( 'Button Name', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Read more',
                'label_block' => true,
                
            ]
        );
        $this->add_control(
            'link',
            [
             'label' => __( 'URL', 'pxaas-add-ons' ),
             'type' => Controls_Manager::URL,
             'default' => [
                'url' => '#',
                'is_external' => '',
             ],
             'show_external' => true, // Show the 'open in new tab' button.
            ]
        );
        $this->add_control(
            'is_external',
            [
                'label' => __( 'Is External Links', 'pxaas-add-ons' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => __( 'Show', 'pxaas-add-ons' ),
                'label_off' => __( 'Hide', 'pxaas-add-ons' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'btn_style',
            [
                'label'       => __( 'Button Style', 'pxaas-add-ons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => '1',
                'options'     => [
                    '1'  => __( 'Style - 1', 'pxaas-add-ons' ),
                    '1-1'=> __( 'Style - 1(1)', 'pxaas-add-ons' ),
                    '1-2'=> __( 'Style - 1(2)', 'pxaas-add-ons' ),
                    '2'  => __( 'Style - 2', 'pxaas-add-ons' ),
                    '2-1'=> __( 'Style - 2(1)', 'pxaas-add-ons' ),
                    '2-2'=> __( 'Style - 2(2)', 'pxaas-add-ons' ),
                    '3'  => __( 'Style - 3', 'pxaas-add-ons' ),
                ],
            ]
        );
        $this->add_control(
            'margin',
            [
                'label'       => __( 'Top/Bottom Margin', 'pxaas-add-ons' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => '',
                'options'     => [
                    ''        => __( 'No Margin', 'pxaas-add-ons' ),
                    'mt-10px mb-10px' => __( 'Small Margin(10)', 'pxaas-add-ons' ),
                    'mt-15px mb-15px' => __( 'Medium Margin(15)', 'pxaas-add-ons' ),
                    'mt-25px' => __( 'Large Margin(25)', 'pxaas-add-ons' ),
                    'mt-50px' => __( 'XLarge Margin(50)', 'pxaas-add-ons' ),
                ],
            ]
        );
        $this->add_control(
            'class',
            [
                'label' => __( 'Css Class', 'pxaas-add-ons' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'label_block' => true,
                
            ]
        );
        $this->end_controls_section();

    }

    protected function render( ) {

        $settings = $this->get_settings();
        $link = $settings['link'];
        $target = $settings['is_external'] == 'yes'? ' target="_blank"':'';

        $css_classes_wrap = array(
            'main-btn',
        );
        $css_class_wrap = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $css_classes_wrap ) ) );

        
        ?>

        <div class="row prject-info">
			<div class="col-md-4 mb-25px">
				<h5 class="mb-5px"><?php esc_html_e( 'Date:', 'pxaas-add-ons' ) ?></h5>
				<p><?php the_date('j M, Y'); ?></p>
			</div>
			<div class="col-md-4 mb-25px">
				<h5 class="mb-5px"><?php esc_html_e( 'Client:', 'pxaas-add-ons' ) ?></h5>  
				<p>John Charles</p>
			</div>
			<div class="col-md-4 mb-25px">
				<h5 class="mb-5px"><?php esc_html_e( 'Tags:', 'pxaas-add-ons' ) ?></h5>
				<p><?php the_tags('' , ',  ' , '');?></p>
			</div>
		</div>
        
        <?php

    }

    // protected function _content_template() {
    //     
    //     <div class="section-title">
    //         <# if(settings.title){ #><h2>{{{settings.title}}}</h2><# } #>
    //         <# if(settings.over_title){ #><div class="section-subtitle">{{{settings.over_title}}}</div><# } #>
    //         <# if(settings.show_sep == 'yes'){ #><span class="section-separator"></span><# } #>
    //         {{{settings.sub_title}}}
    //     </div>
    //     <?php

    // }

   
   

}

// Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_Header_Search' );

// Plugin::$instance->elements_manager->create_element_instance

